/**
 * 
 */
package com.carefirst.nexus.memberenrollments.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author carefirst
 * This is a sample implementation of Entity class. Please delete this file or modify your entity classes as shown in the example below.
 * 
 * Use Lomboks @Data annotation: This combines @Getter, @Setter, @ToString, @EqualsAndHashCode, and @RequiredArgsConstructor into a single annotation.
 * Use @Builder for the Builder pattern: This makes it easier to create instances of the class.
 * Use @AllArgsConstructor and @NoArgsConstructor: These annotations generate constructors with and without parameters.
 **/

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class  MemberEnrollmentsApiModel {
   
    /** Your elements**/

}
