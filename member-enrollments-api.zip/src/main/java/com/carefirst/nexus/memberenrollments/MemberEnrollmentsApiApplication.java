package com.carefirst.nexus.memberenrollments;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author carefirst
 *
 */
@SpringBootApplication
@ComponentScan({"com.carefirst.nexus.memberenrollments",
	"com.carefirst.nexus.utils.web.error",
	"com.carefirst.nexus.utils.web.config.rest",
	"com.carefirst.nexus.utils.web.config.token",
	"com.carefirst.nexus.gen"})
@RestController
public class  MemberEnrollmentsApiApplication {

	
	public static void main(String[] args) {
		SpringApplication.run(MemberEnrollmentsApiApplication.class, args);
	}
}
