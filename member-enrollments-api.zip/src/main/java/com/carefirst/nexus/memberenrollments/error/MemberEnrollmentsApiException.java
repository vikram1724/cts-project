package com.carefirst.nexus.memberenrollments.error;

/**
 * @author carefirst
 *
 */
public class MemberEnrollmentsApiException extends Exception {

	private static final long serialVersionUID = 7488832108215025713L;

	public MemberEnrollmentsApiException(String message){
		super(message);
	}
	
}
