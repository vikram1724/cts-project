/**
 * 
 */
package com.carefirst.nexus.memberenrollments.service;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.exception.ExceptionUtils;

/**
 * @author carefirst
 *
 */
@Service
@Slf4j
public class MemberEnrollmentsApiApiService // implements MemberEnrollmentsApiApiDelegate
{
    // override and implement generated ApiDelegate here
    
    /*
    *    @Override
    *    public ResponseEntity testMethod(args..){
    *        try{
    *           log.info("testMethod >>");
    *        }catch(Exception e){
    *           log.error("Exception occured in method testMethod {}",e);
    *           log.error(ExceptionUtils.getStackTrace(e));
    *        }
    *    }
    ** /
}