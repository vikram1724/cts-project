package com.carefirst.nexus.memberenrollments.config;

import java.text.DateFormat;
import java.util.TimeZone;

import org.openapitools.RFC3339DateFormat;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

import com.carefirst.nexus.utils.web.config.rest.WebUtilsFilter;

@Configuration
public class WebClientConfig {
	@Value("${oauth2.client.registrationId}")
	String registrationId;

	// @Value("${api.basepath}")
	// private String basepath;
	
	private OAuth2AuthorizedClientManager authorizedClientManager;
	
	public WebClientConfig( OAuth2AuthorizedClientManager authorizedClientManager) {
		this.authorizedClientManager = authorizedClientManager;
	}

	WebUtilsFilter webUtil = new WebUtilsFilter(authorizedClientManager,registrationId);

	
	@Bean
	WebClient webClient(OAuth2AuthorizedClientManager authorizedClientManager) {
		ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2Client = new ServletOAuth2AuthorizedClientExchangeFilterFunction(
				authorizedClientManager);
		oauth2Client.setDefaultClientRegistrationId(registrationId);
		return WebClient.builder().filter(webUtil.guidFilter()).filter(webUtil.authTokenFilter())
				//.apply(oauth2Client.oauth2Configuration())
				.build();
	}

	public DateFormat createDefaultDateFormat() {
		DateFormat dateFormat = new RFC3339DateFormat();
		dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
		return dateFormat;
	}

	/*
	API Api(WebClient webClient) {
		ApiClient apiClient = new ApiClient(webClient, new ObjectMapper(), createDefaultDateFormat());
		apiClient.setBasePath(basepath);
		return new Api(apiClient);
	}
	*/
}