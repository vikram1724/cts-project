/**
 * 
 */
package com.carefirst.nexus.memberenrollments.error;

/**
 * @author carefirst
 *
 */
public interface MemberEnrollmentsApiErrorResponseCode {

	String ERROR_PORT_EXPECTED = "002.001";
	String ERROR_MISSING_HEADER_FIELD = "002.002";
	String ERROR_MISSING_BODY_ELEMENT = "002.003";
	String ERROR_DOMAIN_DATA_STORE_UNEXPECTED = "002.004";
	
}
