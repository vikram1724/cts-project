# Application Name

**Title:** Application Name

**Description:** This service serves the purpose of retrieving the ....

**Documentation:**
- **OpenAPI Definitions:**
  - [Swagger UI](https://nexus-deva.carefirst.com/<api>/swagger-ui/index.html)
  - [Microservice Spec](https://dev.azure.com/CareFirstCloud/nexus-foundations/_git/microservices-openapi?path=/<subdomain>/<spec>.yaml)
- **Jira:**
  - [Reference 1](https://carefirst.atlassian.net/browse/<JIRA TICKET>)
  - [Reference 2](https://carefirst.atlassian.net/browse/<JIRA TICKET>)

**Features:**
1. Get _____ info from _____ database based on the parameters __, __, ...
2. Updates ____ into _____ database 

**Backing systems:**
1. DDS
   - **DEVA:**
     - type: postgres/oracle/mssql/snowflake
     - table: 
     - spring.datasource.url: jdbc:postgresql://psql-nexus<domain>deva-dev-001.postgres.database.azure.com:5432/<dbname>
   - **SITA:**

   - **PIT:**

   - **UAT:**

   - **PROD:**
   
2. External Services: 
	- **Service Name:**
     - operation :
3. Nexus Services:
	- **Service Name:**
     - operation :
4. External SOAP API's:
 	- **Service Name:(wsdl url)**
     - operation :

**Setup and Configuration:** SpringBoot Maven Project with all dependencies added in Nexus parent Project.

**Solution Manager:**  LNAME,FNAME <email@carefirst.com>

**System Architect:**  LNAME,FNAME <email@carefirst.com>

**Domain SME:**  LNAME,FNAME <email@carefirst.com>

**Developer Lead:**  LNAME,FNAME <email@carefirst.com>

**Supporting DL:**  DLNAME <email@carefirst.com>