# Member Premium Api.

1.	<B>Title:</B> Nexus Member Premium API

2.	<B>Description:</B> This is CareFirst Member Premium API helps brokers to check the premium for a given subscriber and the members under the family for various products available for a group. The total premium will be returned along with the individual member premium.<br><br>
	API will calculate the premiums based on the effective date, group id, sub group id, benefit period and subscribers. Flexibility to retrieve premium at the member level, subscriber level, product level. The API has flexibility to calculate the premium based on the given criteria.<br>
	It provides the below main operations:<br>
  	
	<b>POST : /memberPremium: </b> To get member premium details <br>
    <b>Description:</b> Get member premium information based on effective date, group id, sub group id, benefit period and subscribers. Flexibility to retrieve premium at the member level, subscriber level, product level. The API has flexibility to calculate the premium based on the given criteria.

3.	<B>Documentation:</B> <br>
    a.	OpenAPI Definitions:<br>
		<a href="https://nexus-deva.carefirst.com/member-premium-api/swagger-ui/index.html">Swagger UI</a> <br>
		<a href="https://dev.azure.com/CareFirstCloud/nexus-member-benefits/_git/member-premium-api?path=/src/main/resources/yaml/member-premium-api.yaml"> Microservice Spec </a>    <br>            
   
	b.	Backing systems:<br>
    <a href="https://azl-pcft-t1.carefirst.com:8443/prweb/PRSOAPServlet/SOAP/CareFirstSalesIntMemberPremium/Services/?wsdl">SOAP service</a> <br>

3.	<B>Setup and Configuration:</B> 
                SpringBoot Maven Project with all dependencies added in Nexus parent Project.

        
4.  <B>Solution Manager: </B> Agarwal, Archana <Archana.Agarwal@carefirst.com>

6. <B>System Architect: </B> Mahadevappa, Chethan <Chethan.Mahadevappa@carefirst.com>  

7. <B>Domain SME: </B> Andhavarapu, Srinivasa <Srinivasa.Andhavarapu@carefirst.com>

8. <B>Developer Lead: </B> Prema, Alamelu <Alamelu.Prema@carefirst.com>,Shaik, Ajjad Basha <AjjadBasha.Shaik@carefirst.com>

9. <B> Supporting DL:  </B> Nexus Catalyst Team <Nexus.Catalyst.Team@carefirst.com>
