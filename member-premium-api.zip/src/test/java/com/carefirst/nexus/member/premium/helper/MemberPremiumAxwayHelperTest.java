package com.carefirst.nexus.member.premium.helper;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Errors;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.PremiumInfo;
import com.carefirst.nexus.member.premium.gen.ServicesType;
import com.carefirst.nexus.member.premium.gen.model.Member;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest;
import com.carefirst.nexus.member.premium.gen.model.MemberProduct;
import com.carefirst.nexus.member.premium.gen.model.SubscriberProduct;

import jakarta.validation.Valid;

@RunWith(MockitoJUnitRunner.class)
public class MemberPremiumAxwayHelperTest {

    @InjectMocks
    private MemberPremiumAxwayHelper classUnderTest;

    @Mock
    private JaxWsProxyFactoryBean servicesTypeProxy;

    @Mock
    private ServicesType servicesType;

    private GetCurrentMemberPremiumResponseType getCurrentMemberPremiumResponseType;

    private MemberPremiumRequest memberPremiumRequest;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(classUnderTest, "appId", "Retreive");
        this.setMockRequest();
        this.setMockData();
    }

    @Test
    public void testGetAxwayMemberPremium() {
        when(servicesTypeProxy.create()).thenReturn(servicesType);
        when(servicesType.getCurrentMemberPremium(Mockito.any())).thenReturn(getCurrentMemberPremiumResponseType);
        MemberPremiumResponse resp = classUnderTest.getAxwayCurrentMemberPremium(memberPremiumRequest);
        assertNotNull(resp);
    }

    private void setMockRequest() {
        memberPremiumRequest = new MemberPremiumRequest();
        List<com.carefirst.nexus.member.premium.gen.model.@Valid Subscriber> listSub = new ArrayList<>();
        com.carefirst.nexus.member.premium.gen.model.@Valid Subscriber subInfo = new com.carefirst.nexus.member.premium.gen.model.@Valid Subscriber();
        listSub.add(subInfo);
        List<SubscriberProduct> listSubPrdInfo = new ArrayList<>();
        SubscriberProduct subProdInfo = new SubscriberProduct();
        listSubPrdInfo.add(subProdInfo);
        subInfo.setProducts(listSubPrdInfo);
        List<@Valid Member> listMemberInfo = new ArrayList<>();
        Member memberInfo = new Member();
        listMemberInfo.add(memberInfo);
        List<MemberProduct> listMemberProduct = new ArrayList<>();
        Member memberProduct = new Member();
        memberInfo.setProducts(listMemberProduct);
        subInfo.setMembers(listMemberInfo);
        listMemberInfo.add(memberProduct);
        memberPremiumRequest.setSubscribers(listSub);
    }

    private void setMockData() {
        getCurrentMemberPremiumResponseType = new GetCurrentMemberPremiumResponseType();
        MemberPremiumResponse memberPremiumResponse = new MemberPremiumResponse();

        List<Errors> listError = new ArrayList<>();
        Errors error = new Errors();
        error.setErrorCode("001");
        error.setErrorDescription("Success");
        listError.add(error);
        memberPremiumResponse.getErrors().addAll(listError);

        List<Subscriber> listSubscriber = new ArrayList<>();
        Subscriber subscriber = new Subscriber();
        subscriber.setSubscriberId("926932112");
        subscriber.setFirstName("John");

        List<PremiumInfo> listPremiumInfo = new ArrayList<>();
        PremiumInfo premiumInfo = new PremiumInfo();
        premiumInfo.setProductIndicator("AAHDB01G");
        listPremiumInfo.add(premiumInfo);

        List<MemberInfo> listMembeInfo = new ArrayList<>();
        MemberInfo memberInfo = new MemberInfo();
        memberInfo.setFirstName("BROADY");
        listMembeInfo.add(memberInfo);

        List<com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo> premiumInfoList2 = new ArrayList<>();
        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo premiumInfo2 = new com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo();
        premiumInfo2.setClassId("0002");
        premiumInfoList2.add(premiumInfo2);
        memberInfo.getPremiumInfo().addAll(premiumInfoList2);

        subscriber.getPremiumInfo().addAll(listPremiumInfo);
        subscriber.getMemberInfo().addAll(listMembeInfo);
        listSubscriber.add(subscriber);
        memberPremiumResponse.getSubscriber().addAll(listSubscriber);
        getCurrentMemberPremiumResponseType.setMemberPremiumResponse(memberPremiumResponse);
    }
}
