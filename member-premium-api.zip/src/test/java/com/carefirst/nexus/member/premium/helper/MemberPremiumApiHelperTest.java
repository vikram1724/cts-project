package com.carefirst.nexus.member.premium.helper;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import java.util.ArrayList;
import java.util.List;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.test.util.ReflectionTestUtils;

import com.carefirst.nexus.member.premium.error.ExceptionHandler;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.PremiumInfo;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumDetailsResponse;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Errors;

@RunWith(MockitoJUnitRunner.class)
public class MemberPremiumApiHelperTest {

    @InjectMocks
    private MemberPremiumApiHelper classUnderTest;

    @Mock
    private MemberPremiumAxwayHelper memberPremiumAxwayHelper;

    @Mock
    private ExceptionHandler exceptionHandler;

    private MemberPremiumResponse memberPremiumResponse;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(this);
        this.mockData();
    }

    @Test
    public void testGetMemberPremiumDetails() {
        MemberPremiumRequest request = new MemberPremiumRequest();
        when(memberPremiumAxwayHelper.getAxwayCurrentMemberPremium(Mockito.any())).thenReturn(memberPremiumResponse);
        MemberPremiumDetailsResponse resp = classUnderTest.getMemberPremium(request);
        assertNotNull(resp);
    }
    @Test
    public void testGetMemberPremiumDetails1() {
        MemberPremiumRequest request = new MemberPremiumRequest();
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Errors errors=new Errors();
        errors.setErrorCode("123");
        memberPremiumResponse.setTotalPremium("12345");
        when(memberPremiumAxwayHelper.getAxwayCurrentMemberPremium(Mockito.any())).thenReturn(memberPremiumResponse);
        MemberPremiumDetailsResponse resp = classUnderTest.getMemberPremium(request);
        assertNotNull(resp);
    }

    @Test
    public void testGetMemberPremiumDetails2() {
        MemberPremiumRequest request = new MemberPremiumRequest();
        List<Errors> listError = new ArrayList<>();
        Errors error = new Errors();
        error.setErrorCode("100");
        error.setErrorDescription("Success");
        listError.add(error);
        memberPremiumResponse.getErrors().addAll(listError);

        when(memberPremiumAxwayHelper.getAxwayCurrentMemberPremium(Mockito.any())).thenReturn(memberPremiumResponse);
        when(exceptionHandler.getHttpStatus(any())).thenReturn(HttpStatus.BAD_REQUEST);
        MemberPremiumDetailsResponse resp = classUnderTest.getMemberPremium(request);
        assertNotNull(resp);
    }

    @Test
    public void testGetTotalPremium() {
        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber subscriber = new Subscriber();
        subscriber.setSubscriberId("123467");
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.PremiumInfo premiumInfo = new PremiumInfo();
        premiumInfo.setClassId("12346");
        premiumInfo.setIndividualPremium("12346");
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo memberInfo = new MemberInfo();
        memberInfo.setAge("25");
        memberInfo.setDateOfBirth("12-23-2019");
        memberInfo.setFirstName("qwer");
        subscriber.getPremiumInfo().add(premiumInfo);
        subscriber.getMemberInfo().add(memberInfo);
        ReflectionTestUtils.invokeMethod(classUnderTest, "getTotalPremium", subscriber);
        assertTrue(true);
    }
    @Test
    public void testGetTotalPremium1() {
        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber subscriber = new Subscriber();
        subscriber.setSubscriberId("123467");
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.PremiumInfo premiumInfo = new PremiumInfo();
        premiumInfo.setClassId("12346");
        premiumInfo.setIndividualPremium("12346");
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo memberInfo = new MemberInfo();
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo memberPremiumInfo= new GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo();
        memberPremiumInfo.setClassId("1234");
        memberPremiumInfo.setIndividualPremium("12345676");
        memberInfo.getPremiumInfo().add(memberPremiumInfo);
        memberInfo.setAge("25");
        memberInfo.setDateOfBirth("12-23-2019");
        memberInfo.setFirstName("qwer");
        subscriber.getPremiumInfo().add(premiumInfo);
        subscriber.getMemberInfo().add(memberInfo);
        ReflectionTestUtils.invokeMethod(classUnderTest, "getTotalPremium", subscriber);
        assertTrue(true);
    }
    @Test
    public void testGetTotalPremium2() {
        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber subscriber = new Subscriber();
        subscriber.setSubscriberId("123467");
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo memberInfo = new MemberInfo();
        GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo memberPremiumInfo= new GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo();
        memberPremiumInfo.setClassId("1234");
        memberPremiumInfo.setIndividualPremium("12345676");
        memberInfo.getPremiumInfo().add(memberPremiumInfo);
        memberInfo.setAge("25");
        memberInfo.setDateOfBirth("12-23-2019");
        memberInfo.setFirstName("qwer");
        subscriber.getMemberInfo().add(memberInfo);
        ReflectionTestUtils.invokeMethod(classUnderTest, "getTotalPremium", subscriber);
        assertTrue(true);
    }

    public void mockData() {
        memberPremiumResponse = new MemberPremiumResponse();

        List<Subscriber> listSubscriber = new ArrayList<>();
        Subscriber subscriber = new Subscriber();
        subscriber.setSubscriberId("926932112");
        subscriber.setFirstName("John");

        List<PremiumInfo> listPremiumInfo = new ArrayList<>();
        PremiumInfo premiumInfo = new PremiumInfo();
        premiumInfo.setProductIndicator("AAHDB01G");
        premiumInfo.setPremiumAmt("12.55");
        premiumInfo.setRateEffDt("20231012");
        premiumInfo.setRateTermDt("20231230");
        PremiumInfo premiumInfo1 = new PremiumInfo();
        premiumInfo1.setProductIndicator("AAHDB01G");
        premiumInfo1.setIndividualPremium("12.55");
        premiumInfo1.setPremiumAmt("12.55");
        premiumInfo1.setRateEffDt("20230912");
        premiumInfo1.setRateTermDt("20230130");
        listPremiumInfo.add(premiumInfo);
        listPremiumInfo.add(premiumInfo1);

        List<MemberInfo> listMembeInfo = new ArrayList<>();
        MemberInfo memberInfo = new MemberInfo();
        memberInfo.setFirstName("BROADY");
        listMembeInfo.add(memberInfo);

        List<com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo> premiumInfoList2 = new ArrayList<>();
        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo premiumInfo2 = new com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo();
        premiumInfo2.setClassId("0002");
        premiumInfo2.setIndividualPremium("12.55");
        premiumInfoList2.add(premiumInfo2);

        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo premiumInfo3 = new com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo.PremiumInfo();
        premiumInfo3.setClassId("0002");
        premiumInfo3.setIndividualPremium("12.55");
        premiumInfoList2.add(premiumInfo3);
        memberInfo.getPremiumInfo().addAll(premiumInfoList2);

        subscriber.getPremiumInfo().addAll(listPremiumInfo);
        subscriber.getMemberInfo().addAll(listMembeInfo);
        listSubscriber.add(subscriber);
        memberPremiumResponse.getSubscriber().addAll(listSubscriber);
    }
}
