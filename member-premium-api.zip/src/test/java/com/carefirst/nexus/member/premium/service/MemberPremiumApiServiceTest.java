package com.carefirst.nexus.member.premium.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;

import com.carefirst.nexus.member.premium.error.ExceptionHandler;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumDetailsInfo;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumDetailsResponse;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest;
import com.carefirst.nexus.member.premium.helper.MemberPremiumApiHelper;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.helpers.ResponseContextHelper;
import com.carefirst.nexus.utils.web.model.ErrorDetails;
import com.carefirst.nexus.utils.web.model.ErrorResponse;
import com.carefirst.nexus.utils.web.model.ResponseContext;

@RunWith(MockitoJUnitRunner.class)
public class MemberPremiumApiServiceTest {

    @InjectMocks
    private MemberPremiumApiService classUnderTest;

    @Mock
    private MemberPremiumApiHelper memberPremiumApiHelper;

    @Mock
    private ExceptionHandler exceptionHandler;

    @Before
    public void setup() {
        MockitoAnnotations.openMocks(classUnderTest);
    }

    @Test
    public void testGetMemberPremiumDetails() {
        MemberPremiumRequest request = new MemberPremiumRequest();
        when(memberPremiumApiHelper.getMemberPremium(Mockito.any())).thenReturn(getMockData("1001", HttpStatus.OK, false));
        assertEquals(200, classUnderTest.getMemberPremium(request).getStatusCode().value());
    }

    @Test
    public void testGetMemberPremiumDetails1() {
        MemberPremiumRequest request = new MemberPremiumRequest();

        when(memberPremiumApiHelper.getMemberPremium(Mockito.any())).thenReturn(getMockData("3001", HttpStatus.OK, true));
        when(exceptionHandler.getHttpStatus(any(ErrorResponse.class))).thenReturn(HttpStatus.OK);
        assertEquals(200, classUnderTest.getMemberPremium(request).getStatusCode().value());

        when(memberPremiumApiHelper.getMemberPremium(Mockito.any())).thenReturn(getMockData("2001", HttpStatus.BAD_REQUEST, true));
        when(exceptionHandler.getHttpStatus(any())).thenReturn(HttpStatus.BAD_REQUEST);
        assertEquals(400, classUnderTest.getMemberPremium(request).getStatusCode().value());

        when(memberPremiumApiHelper.getMemberPremium(Mockito.any())).thenReturn(getMockData("4001", HttpStatus.INTERNAL_SERVER_ERROR, true));
        when(exceptionHandler.getHttpStatus(any())).thenReturn(HttpStatus.INTERNAL_SERVER_ERROR);
        assertEquals(500, classUnderTest.getMemberPremium(request).getStatusCode().value());
    }

    @Test(expected = AppJSONException.class)
    public void testGetMemberPremiumDetailsExp1() {
        MemberPremiumRequest request = new MemberPremiumRequest();
        when(memberPremiumApiHelper.getMemberPremium(Mockito.any())).thenThrow(new AppJSONException("AppJSONExp test"));
        classUnderTest.getMemberPremium(request);
    }

    @Test(expected = AppJSONException.class)
    public void testGetMemberPremiumDetailsExp2() {
        MemberPremiumRequest request = new MemberPremiumRequest();
        RuntimeException re= new RuntimeException("Exp test");
        when(memberPremiumApiHelper.getMemberPremium(Mockito.any())).thenThrow(re);
        when(exceptionHandler.handleException(any(Exception.class))).thenReturn(new AppJSONException("Test"));
        classUnderTest.getMemberPremium(request);
    }

    private MemberPremiumDetailsResponse getMockData(String code, HttpStatus status, boolean flag) {
        MemberPremiumDetailsResponse memberPremiumDetailsResponse = new MemberPremiumDetailsResponse();
        List<com.carefirst.nexus.utils.web.model.ErrorDetails> listErrorDetails = new ArrayList<>();
        ErrorResponse er = new ErrorResponse();
        er.setMessage("Backend API Validation Error Messages");
        ErrorDetails errorDetails =new ErrorDetails(); 
        errorDetails.setKey(code);
        errorDetails.setValue("Test");
        listErrorDetails.add(errorDetails);
        er.setDetails(listErrorDetails);
        ResponseContext responseContext = null;
        if(flag){
            responseContext = ResponseContextHelper.createSuccessResponseContext(status);
            responseContext.setError(er);
        }else{
            responseContext = ResponseContextHelper.createSuccessResponseContext(HttpStatus.OK);
            memberPremiumDetailsResponse.setMemberPremium(new MemberPremiumDetailsInfo());
        }
        memberPremiumDetailsResponse.setResponseContext(responseContext);
        return memberPremiumDetailsResponse;
    }
}
