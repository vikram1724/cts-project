package com.carefirst.nexus.member.premium;

import org.junit.Test;

public class MemberPremiumApiApplicationTest {
    @Test
    public void testMain() {
        
    }
}
