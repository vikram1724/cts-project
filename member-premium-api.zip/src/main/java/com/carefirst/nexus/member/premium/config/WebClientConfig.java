package com.carefirst.nexus.member.premium.config;

import java.text.DateFormat;
import java.time.Duration;
import java.util.TimeZone;
import org.openapitools.RFC3339DateFormat;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ClientHttpConnector;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;
import com.carefirst.nexus.utils.web.config.rest.WebUtilsFilter;
import reactor.netty.http.client.HttpClient;
import reactor.netty.resources.ConnectionProvider;
@Configuration
public class WebClientConfig {
	
	@Value("${oauth2.client.registrationId}")
	String registrationId;
	
	@Value("${benefits.memberserach.basepath}")
	private String memberSearchApiBasepath;
	
	@Value("${application.client.readTimeout}")
	private int readtimeout;

	@Value("${application.client.idletime}")
	private int idletime;
	
	OAuth2AuthorizedClientManager authorizedClientManager;

	@Autowired
	public WebClientConfig(OAuth2AuthorizedClientManager authorizedClientManager) {
		this.authorizedClientManager = authorizedClientManager;
	}

	WebUtilsFilter webUtil = new WebUtilsFilter(authorizedClientManager, registrationId);

	@Bean
	WebClient webClient(OAuth2AuthorizedClientManager authorizedClientManager) {
		ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2Client = new ServletOAuth2AuthorizedClientExchangeFilterFunction(
				authorizedClientManager);
		oauth2Client.setDefaultClientRegistrationId(registrationId);
		return WebClient.builder().filter(webUtil.guidFilter()).filter(webUtil.authTokenFilter())
				.exchangeStrategies(ExchangeStrategies.builder()
						.codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024)).build())
				.clientConnector(clientHttpConnector())
				.build();
	}

	@Bean
	public ClientHttpConnector clientHttpConnector() {
		ConnectionProvider connectionProvider = ConnectionProvider.builder("nexus-http-client")
				.maxIdleTime(Duration.ofSeconds(idletime)).build();
		return new ReactorClientHttpConnector(
				HttpClient.create(connectionProvider).responseTimeout(Duration.ofMillis(readtimeout)));
	}

	public DateFormat createDefaultDateFormat() {
		DateFormat dateFormat = new RFC3339DateFormat();
		dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
		return dateFormat;
	}
}
