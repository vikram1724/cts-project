package com.carefirst.nexus.member.premium.helper;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.carefirst.nexus.member.premium.error.ExceptionHandler;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Errors;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.MemberInfo;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber.PremiumInfo;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumDetailsInfo;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumDetailsResponse;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest;
import com.carefirst.nexus.member.premium.gen.model.SubscriberInfo;
import com.carefirst.nexus.member.premium.gen.model.SubscriberPremiumInfo;
import com.carefirst.nexus.utils.web.helpers.ResponseContextHelper;
import com.carefirst.nexus.utils.web.model.ErrorDetails;
import com.carefirst.nexus.utils.web.model.ErrorResponse;
import com.carefirst.nexus.utils.web.model.ResponseContext;

import lombok.extern.slf4j.Slf4j;
/**
 * This premium api helper class for processing SOAP response and response mapping
 */
@Component
@Slf4j
public class MemberPremiumApiHelper {
    
    private MemberPremiumAxwayHelper memberPremiumAxwayHelper;
    private ExceptionHandler exceptionHandler;

    @Autowired
    public MemberPremiumApiHelper(MemberPremiumAxwayHelper memberPremiumAxwayHelper, ExceptionHandler exceptionHandler) {
        this.memberPremiumAxwayHelper = memberPremiumAxwayHelper;
        this.exceptionHandler = exceptionHandler;
    }

    /**
     * This methods get's SOAP response from MemberPremiumAxwayHelper by calling getAxwayCurrentMemberPremium
     * 
     * @param memberPremiumRequest
     * @return
     */
    public MemberPremiumDetailsResponse getMemberPremium(MemberPremiumRequest memberPremiumRequest) {
        log.info("> getMemberPremiumDetails");
        MemberPremiumDetailsResponse memberPremiumDetailsResponse = new MemberPremiumDetailsResponse();
        MemberPremiumResponse memberPremiumResponse = memberPremiumAxwayHelper.getAxwayCurrentMemberPremium(memberPremiumRequest);
        if(null != memberPremiumResponse) {
            memberPremiumDetailsResponse.setMemberPremium(mapMemberPremiumDetailsInfo(memberPremiumResponse));
            if(null != memberPremiumResponse.getErrors()){
                createResponseContext(memberPremiumDetailsResponse, memberPremiumResponse.getErrors());
            }
        }
        log.info("< getMemberPremiumDetails");
        return memberPremiumDetailsResponse;
    }

    /**
     * Processing SOAP response and mapping with nexus response
     * 
     * @param memberPremiumResponse
     * @return
     */
    private MemberPremiumDetailsInfo mapMemberPremiumDetailsInfo(MemberPremiumResponse memberPremiumResponse) {
        log.info("> mapMemberPremiumDetails");
        MemberPremiumDetailsInfo memberPremiumDetailsInfo = new MemberPremiumDetailsInfo();
        List<com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber> subscriberList = memberPremiumResponse.getSubscriber();
        memberPremiumDetailsInfo.setSubscribers(mapSubscriberDetails(subscriberList));
        log.info("< mapMemberPremiumDetails");
        return memberPremiumDetailsInfo;
    }

    /**
     * Creating ResponseContext as per SOAP response values
     * 
     * @param memberPremiumDetailsResponse
     * @param validationMessages
     */
    private void createResponseContext(MemberPremiumDetailsResponse memberPremiumDetailsResponse, List<Errors> validationMessages) {
        log.info("> createResponseContext");
        ErrorResponse er = getErrorMessage(validationMessages);
        if(null != er && !er.getDetails().isEmpty()) {
            ResponseContext responseContext = ResponseContextHelper.createSuccessResponseContext(exceptionHandler.getHttpStatus(er));
            responseContext.setError(er);
            memberPremiumDetailsResponse.setResponseContext(responseContext);
        }else{
            memberPremiumDetailsResponse.setResponseContext(ResponseContextHelper.createSuccessResponseContext(HttpStatus.OK));
        }
        log.info("< createResponseContext");
    }

    /**
     * Helper function to segregate SOPA error response 
     * 
     * @param validationMessages
     * @return
     */
    private ErrorResponse getErrorMessage(List<Errors> validationMessages) {
        log.info("> getErrorMessage");
        List<com.carefirst.nexus.utils.web.model.ErrorDetails> listErrorDetails = new ArrayList<>();
        ErrorResponse er = new ErrorResponse();
        er.setMessage("Backend API Validation Error Messages");
        if(!validationMessages.isEmpty()){
            validationMessages.stream().map(err -> {
                ErrorDetails errorDetails =new ErrorDetails(); 
                errorDetails.setKey(err.getErrorCode());
                errorDetails.setValue(err.getErrorDescription());
                return errorDetails;
            }).forEach(listErrorDetails::add);
        }
        er.setDetails(listErrorDetails);
        log.info("< getErrorMessage");
        return er;
    }

    /**
     * Subscriber mapping details setting and total premium value setting
     * 
     * @param subscriberList
     * @return
     */
    private List<SubscriberInfo> mapSubscriberDetails(List<com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber> subscriberList) {
        log.info("> mapSubscriberDetails");
        List<SubscriberInfo> subscriberInfoList = new ArrayList<>();
        if(null != subscriberList && !subscriberList.isEmpty()){
            for(com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber pcfSubscriber:subscriberList) {
                SubscriberInfo subscriberInfo = ModelMapperHelper.getModelMapper().map(pcfSubscriber, SubscriberInfo.class);
                subscriberInfo.setPremiumInfo(getSubscriberPremiumInfo(pcfSubscriber.getPremiumInfo()));
                subscriberInfo.setTotalPremium(getTotalPremium(pcfSubscriber));
                subscriberInfoList.add(subscriberInfo);
            }
        }
        log.info("< mapSubscriberDetails");
        return subscriberInfoList;
    }

    /**
     * Mapping subscriber premium details
     * 
     * @param premiumInfo
     * @return
     */
    private List<SubscriberPremiumInfo> getSubscriberPremiumInfo(List<PremiumInfo> premiumInfo) {
        log.info("> getPremiumInfo");
        List<SubscriberPremiumInfo> subscriberPremiumInfoList = new ArrayList<>();
        if(!Objects.isNull(premiumInfo)){
            premiumInfo.stream()
            .filter(pre -> !Objects.isNull(pre))
            .map(pre -> {
                SubscriberPremiumInfo subPremiumInfo = new SubscriberPremiumInfo();
                subPremiumInfo.setClassId(pre.getClassId());
                subPremiumInfo.setClassPlanId(pre.getClassPlanId());
                subPremiumInfo.setProductIndicator(pre.getProductIndicator());
                subPremiumInfo.setIndividualPremium(pre.getIndividualPremium());
                subPremiumInfo.setRateEffectiveDate(formateDate(pre.getRateEffDt()));
                subPremiumInfo.setRateTermDate(formateDate(pre.getRateTermDt()));
                subPremiumInfo.setCoverageLevel(pre.getCoverageLevel());
                subPremiumInfo.setRatingMethod(pre.getRatingMethod());
                subPremiumInfo.setPremiumAmt(pre.getPremiumAmt());
                return subPremiumInfo;
            }).forEach(subscriberPremiumInfoList::add);
        }
        return subscriberPremiumInfoList;
    }
    /**
     * Calculating total premium of subscriber & dependents
     * 
     * @param subscriber
     * @return
     */
    private String getTotalPremium(com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber subscriber) {
        log.info("> getTotalPremium");
        BigDecimal totalPremium = null;
        if(null != subscriber) {
            BigDecimal subscriberPremiumSum = getSubscriberPremiumSum(subscriber);
            BigDecimal memberPremiumSum = getMemberPremiumSum(subscriber);

            if(null != subscriberPremiumSum && null != memberPremiumSum) {
                totalPremium = subscriberPremiumSum.add(memberPremiumSum);
            } else if(null != subscriberPremiumSum){
                totalPremium = subscriberPremiumSum;
            } else if(null != memberPremiumSum){
                totalPremium = memberPremiumSum;
            }
            log.info("total premium {} ", totalPremium);
        }
        log.info("< getTotalPremium");
        return Objects.nonNull(totalPremium) ? totalPremium.toString() : null;
    }

    /**
     * Summing subscriber premium
     * 
     * @param subscriber
     * @return
     */
    private BigDecimal getSubscriberPremiumSum(com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber subscriber) {
        log.info("> getSubscriberPremiumSum");
        BigDecimal subscriberPremiumSum = null;
        if(null != subscriber.getPremiumInfo() && !subscriber.getPremiumInfo().isEmpty()){
            subscriberPremiumSum = subscriber.getPremiumInfo().stream()
            .filter(subPre -> StringUtils.hasText(subPre.getIndividualPremium()) || StringUtils.hasText(subPre.getPremiumAmt()))
            .map(pre -> determinePremium(pre.getIndividualPremium(), pre.getPremiumAmt()))
            .reduce(BigDecimal::add).orElse(null);
        }
        log.info("< getSubscriberPremiumSum");
        return subscriberPremiumSum;
    }

    /**
     * Summing dependents premium
     * 
     * @param subscriber
     * @return
     */
    private BigDecimal getMemberPremiumSum(com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse.Subscriber subscriber) {
        log.info("> getMemberPremiumSum");
        BigDecimal memberPremiumSum = null;
        if(null != subscriber.getMemberInfo() && !subscriber.getMemberInfo().isEmpty()){
            memberPremiumSum = subscriber.getMemberInfo().stream()
            .filter(mbr -> Objects.nonNull(mbr.getPremiumInfo()))
            .map(MemberInfo::getPremiumInfo)
            .flatMap(Collection::stream)
            .filter(mbrPre -> StringUtils.hasText(mbrPre.getIndividualPremium()))
            .map(pre -> BigDecimal.valueOf(Double.valueOf(pre.getIndividualPremium())))
            .reduce(BigDecimal::add).orElse(null);
        }
        log.info("< getMemberPremiumSum");
        return memberPremiumSum;
    }

    /**
     * Helper method to determine individual or premium value
     * 
     * @param indiPremium
     * @param premium
     * @return
     */
    private BigDecimal determinePremium(String indiPremium, String premium) {
        log.info("> determinePremium");
        String reqPremium = null;
        if(StringUtils.hasText(indiPremium) && StringUtils.hasText(premium)){
            reqPremium = premium;
        }else if(StringUtils.hasText(indiPremium)) {
            reqPremium = indiPremium;
        }else if(StringUtils.hasText(premium)) {
            reqPremium = premium;
        }
        log.info("< determinePremium");
        return BigDecimal.valueOf(Double.valueOf(reqPremium));
    }

    /**
     * Formating date pattern
     * 
	 * @param date
	 * @return
	*/
	public String formateDate(String date) {
        log.info("> formateDate");
		String formatedDate = null;
		if(StringUtils.hasText(date)) {
			LocalDate ld = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyyMMdd"));
			formatedDate = ld.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
		}
        log.info("< formateDate");
		return formatedDate;
	}
}