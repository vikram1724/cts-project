package com.carefirst.nexus.member.premium.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.carefirst.nexus.utils.web.filters.CommonLogThreadContextFilter;
import com.carefirst.nexus.utils.web.filters.UserAuthFilter;

/**
 * @author aad3696
 *
 */
@Configuration
public class ApplicationFilterConfig {

	@Value("${application.log-thread-context-filter.filter-order}")
    private int logThreadContextFilterOrder;
	
	@Value("${application.user-auth-filter.filter-order}")
    private int userAuthFilterOrder;
		
	@Bean
	public FilterRegistrationBean<CommonLogThreadContextFilter> commonLogThreadContextFilter(){
	    FilterRegistrationBean<CommonLogThreadContextFilter> commonLogThreadContextFilterRegBean = new FilterRegistrationBean<>();
	    commonLogThreadContextFilterRegBean.setFilter(new CommonLogThreadContextFilter());
	    commonLogThreadContextFilterRegBean.setOrder(logThreadContextFilterOrder);
	    commonLogThreadContextFilterRegBean.addUrlPatterns("/*");
	    return commonLogThreadContextFilterRegBean;
	}
		
	@Bean
	public FilterRegistrationBean<UserAuthFilter> userAuthFilter(){
	    FilterRegistrationBean<UserAuthFilter> userAuthFilterRegBean = new FilterRegistrationBean<>();
	    userAuthFilterRegBean.setFilter(new UserAuthFilter());
	    userAuthFilterRegBean.setOrder(userAuthFilterOrder);
	    userAuthFilterRegBean.addUrlPatterns("/*");
	    return userAuthFilterRegBean;
	}
}