package com.carefirst.nexus.member.premium.error;

import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.util.ObjectUtils;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponse;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;
/**
 * Generic exception handler for nexus services
 */
@Slf4j
@Component
public class ExceptionHandler {

	/**
	 * Processing the exception and creating AppJSONException
	 * 
	 * @param e
	 */
	public AppJSONException handleException(Exception e) {
		AppJSONException appJsonExp = null;
		if (e instanceof WebClientResponseException expResp) {
			appJsonExp = getAppJsonException(expResp.getResponseBodyAsString(), expResp.getStatusCode());
		} else if (e instanceof WebClientRequestException expReq) {
			appJsonExp = getAppJsonException(expReq.getCause().toString(), HttpStatus.INTERNAL_SERVER_ERROR);
		} else {
			appJsonExp = getAppJsonException(e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return appJsonExp;
	}

	/**
	 * Useful for generating validation exception as AppJSONException
	 * 
	 * @param validationMessage
	 */
	public void handleException(String validationMessage) {
		if(!Objects.isNull(validationMessage)){
			handleValidation(validationMessage);
		}
	}

	/**
	 * Helper method for creating AppJSONException
	 * 
	 * @param message
	 * @param httpStatus
	 * @return
	 */
	private AppJSONException getAppJsonException(String message, HttpStatusCode httpStatus) {
		AppJSONException appExp = new AppJSONException(ErrorResponseCode.ERROR_UNEXPECTED_ERROR);
		appExp.setMoreInfo(getErrorMessage(message));
		appExp.setStatus(HttpStatus.valueOf(httpStatus.value()));
		return appExp;
	}

	/**
	 * Helper method for retrieve exception error message
	 * 
	 * @param message
	 * @return
	 */
	public String getErrorMessage(String message) {
		String errorMessage = null;
		try {
			if (StringUtils.isNotEmpty(message)) {
				if(StringUtils.contains(message, "error")){
					JSONObject jsonObj = new JSONObject(message);
					ObjectMapper mapper = new ObjectMapper();
					ErrorResponse error = mapper.readValue(jsonObj.get("error").toString(), ErrorResponse.class);
					errorMessage = error.getMoreInfo();
				}else{
					errorMessage = message;
				}
			}
		} catch (JsonProcessingException e) {
			log.error("Occred JsonProcessingException");
		}
		return errorMessage;
	}

	/**
	 * Helper method for creating validation AppJSONException
	 * 
	 * @param validationMessage
	 * @return
	 */
	private AppJSONException handleValidation(String validationMessage) {
		log.info("> handleValidation");
		log.error(validationMessage);
		AppJSONException appExp = new AppJSONException(ErrorResponseCode.ERROR_INVALID_SEARCH_CRITERIA,
		new String[]{validationMessage});
		appExp.setMoreInfo(validationMessage);
		appExp.setStatus(HttpStatus.BAD_REQUEST);
		return appExp;
	}

	/**
	 * Helper method for segregating soap errors
	 * 
	 * @param errorResponse
	 * @return
	 */
	public HttpStatus getHttpStatus(ErrorResponse errorResponse){
		HttpStatus httpstatus[] = new HttpStatus[1];
		httpstatus[0] = HttpStatus.OK;
		if(null != errorResponse && !ObjectUtils.isEmpty(errorResponse.getDetails())){
			Optional<HttpStatus> res = errorResponse.getDetails().stream()
			.map(e -> {
				httpstatus[0] = HttpStatus.INTERNAL_SERVER_ERROR;
				if(e.getKey().startsWith("20")){
					httpstatus[0] = HttpStatus.BAD_REQUEST;
				}
				if(e.getKey().startsWith("30")){
					httpstatus[0] = HttpStatus.OK;
				}
				return httpstatus[0];
			}).findFirst();
			httpstatus[0] = res.isPresent() ? res.get() : null;
		}
		return httpstatus[0];
	}
}