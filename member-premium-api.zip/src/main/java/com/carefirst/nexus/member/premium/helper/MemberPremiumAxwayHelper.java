package com.carefirst.nexus.member.premium.helper;

import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest.Subscriber;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest.Subscriber.MemberInfo;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest.Subscriber.ProductInfo;
import com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType;
import com.carefirst.nexus.member.premium.gen.ServicesType;
import com.carefirst.nexus.member.premium.gen.model.Member;
import com.carefirst.nexus.member.premium.gen.model.MemberProduct;
import com.carefirst.nexus.member.premium.gen.model.SubscriberProduct;

import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

@Component
@Slf4j
public class MemberPremiumAxwayHelper {
    
    @Value("${application.client.axway.premium.appId}")
	private String appId;

	private JaxWsProxyFactoryBean servicesTypeProxy;

	@Autowired
    public MemberPremiumAxwayHelper(@Qualifier("memberPremium") JaxWsProxyFactoryBean servicesTypeProxy) {
        this.servicesTypeProxy = servicesTypeProxy;
    }

	public ServicesType getServicesType() {
		return (ServicesType) servicesTypeProxy.create();
	}

    /**
     * Actual SOAP call invoke from here
     * 
     * @param memberPremiumRequest
     * @return
     */
    public com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse getAxwayCurrentMemberPremium(com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest memberPremiumRequest) {
        log.info("> getAxwayMemberPremium");
        com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumResponseType.MemberPremiumResponse memberPremiumResponse = null;
        GetCurrentMemberPremiumResponseType resp = getServicesType().getCurrentMemberPremium(createMemberCurrentPremiumRequest(memberPremiumRequest));
        if(null != resp && null != resp.getMemberPremiumResponse()){
            memberPremiumResponse = resp.getMemberPremiumResponse();
        }
        return memberPremiumResponse;
    }

    /**
     * Creating SOAP request to invoke actual SOAP endpoint, mapping nexus POST request to SOAP request request
     * 
     * @param memberPremiumRequest
     * @return
     */
    private GetCurrentMemberPremiumRequestType createMemberCurrentPremiumRequest(com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest memberPremiumRequest) {
        log.info("> createMemberPremiumRequest");
        GetCurrentMemberPremiumRequestType request = new GetCurrentMemberPremiumRequestType();
        MemberPremiumRequest soapMemberPremiumRequest = new com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest();

        soapMemberPremiumRequest.setAppId(appId);
        soapMemberPremiumRequest.setEffectiveDate(memberPremiumRequest.getEffectiveDate());
        soapMemberPremiumRequest.setGrpId(memberPremiumRequest.getGroupId());
        soapMemberPremiumRequest.setBenefitPeriod(memberPremiumRequest.getBenefitPeriod());

        @Valid List<com.carefirst.nexus.member.premium.gen.model.@Valid Subscriber> listSubscriberInfo = memberPremiumRequest.getSubscribers();
        List<Subscriber> subscriberList = new ArrayList<>();
        List<ProductInfo> productInfoList = new ArrayList<>();
        List<MemberInfo> memberInfoList = new ArrayList<>();
        List<com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest.Subscriber.MemberInfo.ProductInfo> memberProductInfoList = new ArrayList<>();
        if(null != listSubscriberInfo) {
            listSubscriberInfo.stream().map(sub -> {
                Subscriber subscriber = ModelMapperHelper.getModelMapper().map(sub, Subscriber.class);
               
                @Valid List<@Valid SubscriberProduct>  ListSubscriberProductInfo = sub.getProducts();
                if(null != ListSubscriberProductInfo) {
                    ListSubscriberProductInfo.stream()
                    .map(productInfo -> ModelMapperHelper.getModelMapper().map(productInfo, ProductInfo.class))
                    .forEach(productInfoList::add);
                }
                subscriber.getProductInfo().addAll(productInfoList);
                productInfoList.clear();
                @Valid List<@Valid Member> listDependentInfo = sub.getMembers();
                if(null != listDependentInfo){
                    listDependentInfo.stream().map(member -> {
                        MemberInfo memberInfo = ModelMapperHelper.getModelMapper().map(member, MemberInfo.class);
                        @Valid List<@Valid MemberProduct> listDependentProductInfo = member.getProducts();
                        if(null != listDependentProductInfo){
                            listDependentProductInfo.stream()
                            .map(mbrProduct -> ModelMapperHelper.getModelMapper().map(mbrProduct, com.carefirst.nexus.member.premium.gen.GetCurrentMemberPremiumRequestType.MemberPremiumRequest.Subscriber.MemberInfo.ProductInfo.class))
                            .forEach(memberProductInfoList::add);
                        }
                        memberInfo.getProductInfo().addAll(memberProductInfoList);
                        memberProductInfoList.clear();
                        return memberInfo;
                    }).forEach(memberInfoList::add);
                }
                subscriber.getMemberInfo().addAll(memberInfoList);
                memberInfoList.clear();
                return subscriber;
            }).forEach(subscriberList::add);
        }
        
        soapMemberPremiumRequest.getSubscriber().addAll(subscriberList);
        request.setMemberPremiumRequest(soapMemberPremiumRequest);

        return request;
    }
}
