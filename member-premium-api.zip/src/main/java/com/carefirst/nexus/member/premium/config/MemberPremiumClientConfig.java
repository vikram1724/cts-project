package com.carefirst.nexus.member.premium.config;

import java.util.ArrayList;
import java.util.List;
import javax.xml.namespace.QName;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.binding.soap.saaj.SAAJOutInterceptor;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import com.carefirst.nexus.member.premium.gen.ServicesType;
import com.carefirst.nexus.utils.jaxws.SoapRequestResponseLoggingHandler;
import jakarta.xml.ws.handler.Handler;
import lombok.extern.slf4j.Slf4j;

/**
 * member premium client configuration.
 *
 */
@Configuration
@Slf4j
public class MemberPremiumClientConfig {

	private static final QName WS_NAMESPACE = new QName("urn:PegaRULES:SOAP:CareFirstSalesIntMemberPremium:Services",
			"ServicesService");

	private static final QName WS_ENDPOINTNAME = new QName("urn:PegaRULES:SOAP:CareFirstSalesIntMemberPremium:Services",
			"ServicesPortSOAP");

	@Value("${application.client.axway.premium.uri}")
	private String endPoint;

	@Value("${application.client.axway.premium.timeout}")
	private String timeout;
	@Value("${application.client.axway.premium.username}")
	private String username;
	@Value("${application.client.axway.premium.password}")
	private String password;

	@Bean(name = "memberPremium")
	public JaxWsProxyFactoryBean memberPremiumProxy() {
		JaxWsProxyFactoryBean portBean = new JaxWsProxyFactoryBean();
		try {
			portBean.setWsdlURL("wsdl/member-premium.wsdl");
			portBean.setServiceClass(ServicesType.class);
			portBean.setAddress(endPoint);
			portBean.setServiceName(WS_NAMESPACE);
			portBean.setEndpointName(WS_ENDPOINTNAME);
			portBean.setUsername(username);
			portBean.setPassword(password);
			// To set the Timeouts using CXF recommended way.
			ServicesType client = (ServicesType) portBean.create();
			Client proxy = ClientProxy.getClient(client);
			HTTPConduit http = (HTTPConduit) proxy.getConduit();
			HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
			httpClientPolicy.setConnectionTimeout(Integer.parseInt(timeout));
			httpClientPolicy.setReceiveTimeout(Integer.parseInt(timeout));
			http.setClient(httpClientPolicy);
			http.getClient().setReceiveTimeout(Integer.parseInt(timeout));

			@SuppressWarnings("rawtypes")
			List<Handler> handlers = new ArrayList<>();
			SoapRequestResponseLoggingHandler soapReqRespLogHandler = new SoapRequestResponseLoggingHandler();
			handlers.add(soapReqRespLogHandler);
			portBean.setHandlers(handlers);

			portBean.getOutInterceptors().add(new SAAJOutInterceptor());
			portBean.getInInterceptors().add(new SAAJInInterceptor());
		} catch (Exception e) {
			log.info("Exception", e.getMessage());
		}
		return portBean;
	}
}
