package com.carefirst.nexus.member.premium.model;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class MemberPremiumDetailsRequest {
    private String effectiveDate;
    private String groupId;
    private String benefitPeriod;
    private String subscriberId;
    private String dateOfBirth;
    private String firstName;
    private String lastName;
    private String sexCode;
    private String relationshipCode;
    private String tobaccoUsage;
    private String productIndicator;
    private String classId;
    private String memberDob;
    private String memberFirstName;
    private String memberLastName;
    private String memberRelationshipCode;
    private String memberTobaccoUsage;
    private String memberEffectiveDate;
    private String memberSexCode;
    private String memberProductIndicator;
    private String memberClassId;
}
