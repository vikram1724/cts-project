package com.carefirst.nexus.member.premium;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

/**
 * @author aad3696
 *
 */
@SpringBootApplication
@ComponentScan({"com.carefirst.nexus.member.premium",
	"com.carefirst.nexus.utils.web.error",
	"com.carefirst.nexus.utils.web.config.rest",
	"com.carefirst.nexus.utils.web.config.token",
	"com.carefirst.nexus.member.premium.gen"})
public class MemberPremiumApiApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MemberPremiumApiApplication.class, args);
	}
}
