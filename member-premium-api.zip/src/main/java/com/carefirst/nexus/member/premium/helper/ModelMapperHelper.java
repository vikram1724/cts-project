package com.carefirst.nexus.member.premium.helper;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;

public class ModelMapperHelper {

    private ModelMapperHelper() {
        super();
    }
    /**
	 * Factory methode return the modelMapper instance
	 * 
	 * @return modelMapper
	 */
	public static ModelMapper getModelMapper() {
		ModelMapper modelMapper = new ModelMapper();
		modelMapper.getConfiguration().setFieldMatchingEnabled(true).setMatchingStrategy(MatchingStrategies.STRICT)
				.setSkipNullEnabled(true);
		return modelMapper;
	}
}
