/**
 * 
 */
package com.carefirst.nexus.member.premium.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.carefirst.nexus.member.premium.error.ExceptionHandler;
import com.carefirst.nexus.member.premium.gen.api.MemberPremiumApiDelegate;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumDetailsResponse;
import com.carefirst.nexus.member.premium.gen.model.MemberPremiumRequest;
import com.carefirst.nexus.member.premium.helper.MemberPremiumApiHelper;
import com.carefirst.nexus.utils.web.error.AppJSONException;

import lombok.extern.slf4j.Slf4j;

/**
 * Delegate service having post end point implementaion
 * @author aad3696
 */
@Service
@Slf4j
public class MemberPremiumApiService implements MemberPremiumApiDelegate {

    private MemberPremiumApiHelper memberPremiumApiHelper;

    private ExceptionHandler exceptionHandler;

    @Autowired
    public MemberPremiumApiService(MemberPremiumApiHelper memberPremiumApiHelper, ExceptionHandler exceptionHandler) {
        this.memberPremiumApiHelper = memberPremiumApiHelper;
        this.exceptionHandler = exceptionHandler;
    }

    /**
     * To get member premium details for requested subscriber and dependentes
     *
     * @param memberPremiumRequest Get member premium information based on effective date, group id, sub group id, benefit period and subscribers. Flexibility to retrieve premium at the member level, subscriber level, product level. The API has flexibility to calculate the premium based on the given criteria. (required)
     * @return Success (status code 200)
     *         or Forbidden - unauthorized access (status code 403)
     *         or Invalid Input (status code 405)
     *         or Unauthorized (status code 401)
     *         or Resource not found. (status code 404)
     *         or Request timed out (status code 408)
     *         or Unexpected server (status code 500)
     */
    @Override
    public ResponseEntity<MemberPremiumDetailsResponse> getMemberPremium(MemberPremiumRequest memberPremiumRequest) {
            log.info("> getMemberPremiumDetails");
            log.info("> memberPremiumRequest {}", memberPremiumRequest);
            MemberPremiumDetailsResponse memberPremiumDetailsResponse = null;
            HttpStatus httpStatus = null;
            try{
                memberPremiumDetailsResponse = memberPremiumApiHelper.getMemberPremium(memberPremiumRequest);
                if(null != memberPremiumDetailsResponse && null != memberPremiumDetailsResponse.getResponseContext()){
                    if(null != memberPremiumDetailsResponse.getResponseContext().getError()) {
                        httpStatus = exceptionHandler.getHttpStatus(memberPremiumDetailsResponse.getResponseContext().getError());
                    }else{
                        httpStatus = HttpStatus.OK;
                    }
                }
            } catch (AppJSONException e) {
                log.error("AppJSONException caught");
                throw e;
            } catch(Exception e){
                throw exceptionHandler.handleException(e);
            }
            return new ResponseEntity<>(memberPremiumDetailsResponse, httpStatus);
        }
}
