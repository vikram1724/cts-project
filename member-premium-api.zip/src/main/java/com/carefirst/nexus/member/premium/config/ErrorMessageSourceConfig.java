package com.carefirst.nexus.member.premium.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;

/**
 * @author aad3696
 *
 */
@Configuration
public class ErrorMessageSourceConfig {

	private static final Logger LOG = LogManager.getLogger(ErrorMessageSourceConfig.class);
	
	@Value("${application.error-message-sources}")
    private String errorMessageSources;
	
	@Bean
	public ResourceBundleMessageSource messageSource() {
		LOG.debug("Configuring error message sources {} ",errorMessageSources);
		ResourceBundleMessageSource ms = new ResourceBundleMessageSource();
		ms.setBasenames(errorMessageSources.split(","));
		return ms;
	}
	
}
