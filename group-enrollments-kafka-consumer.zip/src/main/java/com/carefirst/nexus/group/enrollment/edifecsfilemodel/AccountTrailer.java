package com.carefirst.nexus.group.enrollment.edifecsfilemodel;


import lombok.Data;

@Data
public class AccountTrailer implements java.io.Serializable {
    private String fileType;
	private String holdField;
	private String recordType;
    private String detailEmployeeRecordCount;
}
