package com.carefirst.nexus.group.enrollment.models;

import lombok.Data;

@Data
public class UpdateAE2Transaction {

    private String file834Content;
    
}
