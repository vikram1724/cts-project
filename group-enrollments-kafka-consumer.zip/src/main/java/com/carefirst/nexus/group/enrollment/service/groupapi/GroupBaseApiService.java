package com.carefirst.nexus.group.enrollment.service.groupapi;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.carefirst.nexus.group.gen.api.GroupDetailsApi;
import com.carefirst.nexus.group.gen.model.Group;
import com.carefirst.nexus.group.gen.model.GroupResponse;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.carefirst.nexus.utils.web.model.ErrorResponseCode;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class GroupBaseApiService {

	private static final Logger LOG = LogManager.getLogger(GroupBaseApiService.class);

	private GroupDetailsApi groupOperationsApi;

	public GroupBaseApiService(GroupDetailsApi groupOperationsApi) {
		this.groupOperationsApi = groupOperationsApi;
	}

	public Group getGroupDetailsByGroupId(String groupId) {
		LOG.info("GroupBaseApiService | getGroupDetailsByGroupId | start");
		GroupResponse groupSearchResponse = null;
		Group group = null;
		try {
			Mono<GroupResponse> monoReponse = groupOperationsApi.getGroup(groupId);
			if (null != monoReponse) {
				groupSearchResponse = monoReponse.block();
			}
			if (null != groupSearchResponse && groupSearchResponse.getGroup() != null) {
				group = groupSearchResponse.getGroup();
			} else {
				AppJSONException appExp = new AppJSONException(ErrorResponseCode.ERROR_INVALID_SEARCH_CRITERIA,
						new String[] { "Group Not Found With given criteria" });
				appExp.setStatus(HttpStatus.NOT_FOUND);
				LOG.error("Group Not Found With given Criteria : {} " + appExp);
				throw appExp;
			}
			LOG.info("getGroupDetails Retrieval Complete");
		} catch (Exception e) {
			LOG.info("GroupBaseApiService | getGroupDetailsByGroupId | Exception : " + e);
			throw e;
		}
		LOG.info("GroupBaseApiService | getGroupDetailsByGroupId | GroupResp : {} " + group);
		LOG.info("GroupBaseApiService | getGroupDetailsByGroupId | End ");
		return group;
	}

}