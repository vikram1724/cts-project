package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class KeyDemographicDataLg implements java.io.Serializable{
    private String sex;
    private String lastName;
    private String firstName;
    private String dateofBirth;
    private String employeeSSN;
    private String middleInitial;
    private String suffixOrTitle;
    private String relationshipCode;
    private String memberEntityID;
    private String maritalStatus;
    
}
