package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class MedicalCoverageDataLg implements java.io.Serializable{
    private String homePlanCode;
    private String controlPlanCode;
    private String medicalProductID;
    private String medicalCoverageLevel;
    private String departmentNumberOrClassID;
    private String medicalGroupOrSectionNumber;
    private String medicalCoverageEffectiveDate;
    private String medicalCoverageTerminationCode;
    private String medicalCoverageTerminationDate;
    private String medicalSubGroupNumberOrPackageCode;
}
