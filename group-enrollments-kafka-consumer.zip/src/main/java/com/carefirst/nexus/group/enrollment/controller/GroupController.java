package com.carefirst.nexus.group.enrollment.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.carefirst.nexus.group.enrollment.service.groupapi.GroupBaseApiService;
import com.carefirst.nexus.group.gen.model.Group;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class GroupController {

    private GroupBaseApiService groupApi;

    public GroupController(GroupBaseApiService groupApi) {
        this.groupApi = groupApi;
    }

	@GetMapping("/{groupId}")
    public ResponseEntity<Group> getGroup(@PathVariable("groupId") String groupId) {
		log.info("GroupController | getGroupDetailsByGroupId | start");
        Group group = groupApi.getGroupDetailsByGroupId(groupId);
		log.info("GroupController | getGroupDetailsByGroupId | Group Response: {} " + group);
		log.info("GroupController | getGroupDetailsByGroupId | end");
        return ResponseEntity.status(HttpStatus.OK).body(group);
    }
}
