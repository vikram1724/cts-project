package com.carefirst.nexus.group.enrollment;

/**
 * @author carefirst
 * 
 * This is CareFirst Member Enrollment API helps consumers for submitting member enrollment applications<br><br>This Application or Enrollment Submission client API is a standard intake enrollment api from  all the consumer to put the enrollment application data captured as part of the enrollment submission workflow to the enrollment target system. <br><br> Consumer send the  daily enrollment application files to Carefirst Member Enrollment API. Once the application intake is done,Member Enrollment API process those application and send it to corresponding consumer based upon the line of business. <br><br>Member Enrollment API supports enrollment submissions for MAPD, Individual, all market segments which includes small market, mid market and large group and all FSPs.<br><br><b> It is covering below  operations. </b> <br> * post: application - operation to submit member enrollment application.<br>  * get: application - operation to get the member enrollment application details.<br>  * patch: application - operation to update member enrollment application.<br>  * get: application/status - operation to get the member enrollment application current status.<br><br>
Kafka Connector KSQL will send the Application Request with PENDING status to topic member.enrollment.domaincdc.<<env>>.application. <br>It will be consumed by group-enrollments-kafka-consumer to generate the processor payload. <br>And that processor payload will be read by enrollments-edifecs-sb to generate the 1350 file.<br> And enrollments-edifecs-sb will upload the 1350 file to Azure blob. <br> And it will be pickup by Edifecs for actual enrollment processing 

And group-enrollments-kafka-consumer will process those pending request and generate 
 *
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@ComponentScan({ "com.carefirst.kafka.consumer", "com.carefirst.nexus.group.enrollment",
		"com.carefirst.nexus.utils.web.config.token", "com.carefirst.nexus.utils.web.error",
		"com.carefirst.nexus.utils.web.config.rest" })
@EnableKafka
@SpringBootApplication
@RestController
public class GroupEnrollmentKafkaConsumerApplication {

	@GetMapping("/pub/healthcheck")
	public String healthCheck() {
		return "OK";
	}

	public static void main(String[] args) {
		SpringApplication.run(GroupEnrollmentKafkaConsumerApplication.class, args);
	}
}
