package com.carefirst.nexus.group.enrollment.listener;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.group.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.group.enrollment.service.EnrollmentTransactionProcessService;

import lombok.extern.slf4j.Slf4j;

/**
 * Kafka Connector KSQL will send the Application Request with PENDING status to
 * topic member.enrollment.domaincdc.<<env>>.application. <br>
 * It will be consumed by group-enrollments-kafka-consumer to generate the
 * processor payload. <br>
 * And that processor payload will be read by enrollments-edifecs-sb to generate
 * the 1350 file.<br>
 * And enrollments-edifecs-sb will upload the 1350 file to Azure blob. <br>
 * And it will be pickup by Edifecs for actual enrollment processing
 * 
 * @author AAA7179
 *
 */
@Service
@Slf4j
public class EnrollmentTransactionsListener {

	private EnrollmentTransactionProcessService enrollmentTransactionProcessService;

	public EnrollmentTransactionsListener(EnrollmentTransactionProcessService enrollmentTransactionProcessService) {
		this.enrollmentTransactionProcessService = enrollmentTransactionProcessService;
	}

	/**
	 * Kafka Connector KSQL will send the Application Request with PENDING
	 * status to topic member.enrollment.domaincdc.<<env>>.application. <br>
	 * It will be consumed by group-enrollments-kafka-consumer to generate the
	 * processor payload. <br>
	 * And that processor payload will be read by enrollments-edifecs-sb to
	 * generate the 1350 file.<br>
	 * And enrollments-edifecs-sb will upload the 1350 file to Azure blob. <br>
	 * And it will be pickup by Edifecs for actual enrollment processing
	 * 
	 * @param consumerRecord
	 * @param ack
	 * @throws RecoverableMessageException
	 * @throws UnrecoverableMessageException 
	 */
	@KafkaListener(id = "transactions", topics = {
			"${application.kafka.listeners.transactions.consumer.topic}" }, groupId = "${application.kafka.listeners.transactions.consumer.properties.group.id}", containerFactory = "transactions_ContainerFactory")
	public void enrollmentTransactionListener(
			@Payload ConsumerRecord<String, TransactionListenerPayload> consumerRecord, Acknowledgment ack)
			throws RecoverableMessageException, UnrecoverableMessageException {
		log.info("EnrollmentTransactionsListener | enrollmentTransactionListener | Message received:{} ",
				consumerRecord.value());
		try {
			enrollmentTransactionProcessService.processPayload(consumerRecord.value());
		} catch (UnrecoverableMessageException e) {
			log.error("Caught UnrecoverableMessageException", e);
			throw e;
		} catch (RecoverableMessageException e) {
			log.error("Caught RecoverableMessageException", e);
			throw e;
		} catch (Exception e) {
			log.error("Caught Exception", e);
			throw new UnrecoverableMessageException("Unhandled error caught", e);
		}
		log.info("enrollmentTransactionListener : End ");
		ack.acknowledge();
	}

	/**
	 * Kafka Connector KSQL will send the Application Request with PENDING
	 * status to topic member.enrollment.domaincdc.<<env>>.application. <br>
	 * It will be consumed by group-enrollments-kafka-consumer to generate the
	 * processor payload. <br>
	 * And that processor payload will be read by enrollments-edifecs-sb to
	 * generate the 1350 file.<br>
	 * And enrollments-edifecs-sb will upload the 1350 file to Azure blob. <br>
	 * And it will be pickup by Edifecs for actual enrollment processing
	 * 
	 * @param consumerRecord
	 * @param ack
	 * @throws RecoverableMessageException
		 * @throws UnrecoverableMessageException 
		 */
		@KafkaListener(id = "transactions-retry-1", topics = {
				"${application.kafka.listeners.transactions-retry-1.consumer.topic}" }, groupId = "${application.kafka.listeners.transactions-retry-1.consumer.properties.group.id}", containerFactory = "transactions-retry-1_ContainerFactory", autoStartup = "false")
		public void enrollmentTransactionListenerRetry1(
				@Payload ConsumerRecord<String, TransactionListenerPayload> consumerRecord, Acknowledgment ack)
				throws RecoverableMessageException, UnrecoverableMessageException {
		log.info("EnrollmentTransactionsListener | enrollmentTransactionListenerRetry1 | Message received:{} ",
				consumerRecord.value());
		try {
			enrollmentTransactionProcessService.processPayload(consumerRecord.value());
		} catch (Exception e) {
			log.error("Caught UnrecoverableMessageException", e);
			throw new UnrecoverableMessageException("caught unrecoverable Exception " + e.getMessage(), e);
		}
		log.info("enrollmentTransactionListenerRetry1 : End ");
		ack.acknowledge();
	}
}
