package com.carefirst.nexus.group.enrollment.util;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import com.azure.identity.DefaultAzureCredential;
import com.azure.identity.DefaultAzureCredentialBuilder;
import com.azure.storage.blob.BlobClient;
import com.azure.storage.blob.BlobContainerClient;
import com.azure.storage.blob.BlobServiceClient;
import com.azure.storage.blob.BlobServiceClientBuilder;
import com.azure.storage.blob.models.BlobStorageException;
import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.group.enrollment.constants.EdifecsFileConstants;

import lombok.extern.slf4j.Slf4j;

@Configuration
@Slf4j
public class BlobFileUtils {
    @Value("${spring.cloud.azure.storage.blob.container-name}")
    String containerName;
    @Value("${spring.cloud.azure.storage.blob.credential.client-id}")
    String clientId;
    @Value("${spring.cloud.azure.storage.blob.endpoint}")
    String endpoint;
    @Value("${blobProperties.enrollments}")
    private String enrollmentsBlobPath;

    public String fileUploadtoBlobStorage(String edifecs1350FileContent,String transactionNumber) throws RecoverableMessageException {
        log.info("BlobFileUtils | fileUploadtoBlobStorage | start");
        String fileName = null;
        BlobContainerClient container;
        String blobUploadedStatus = EdifecsFileConstants.BLOB_FAILURE;
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = dateFormat.format(new Date());
        fileName = EdifecsFileConstants.SMMD + EdifecsFileConstants.UNDERSCORE + EdifecsFileConstants.EMPRL
                + EdifecsFileConstants.UNDERSCORE + EdifecsFileConstants.THIRTEENFIFTY + EdifecsFileConstants.UNDERSCORE
                + transactionNumber + EdifecsFileConstants.UNDERSCORE+ timestamp + EdifecsFileConstants.TXT;
        try {
            String uploadFileName = enrollmentsBlobPath + fileName;
            container = getBlobServiceClientTokenCredential().getBlobContainerClient(containerName);
            BlobClient client = container.getBlobClient(uploadFileName);
            ByteArrayInputStream dataStream = new ByteArrayInputStream(edifecs1350FileContent.getBytes());
            client.upload(dataStream, edifecs1350FileContent.length());
            log.info(EdifecsFileConstants.UPLOAD_CARFIRST_SUCCESS + uploadFileName);
            blobUploadedStatus = EdifecsFileConstants.BLOB_SUCCESS;
            log.info("blobUploadedStatus1 :"+ blobUploadedStatus);
        } catch (BlobStorageException e) {
            log.error("BlobFileUtils | fileUploadtoBlobStorage | upload to Carefirst  was failed {} ", e.getMessage());
            throw new RecoverableMessageException("error occured while uploading file to azure blob with BlobStorageException " +e.getMessage(), e);
        } catch (Exception e) {
            log.error("BlobFileUtils | fileUploadtoBlobStorage | error occured while uploading file to Blob");
            throw new RecoverableMessageException("error occured while uploading file to azure blob " +e.getMessage(), e);
        }
        log.info("BlobFileUtils | fileUploadtoBlobStorage | end");
        log.info("blobUploadedStatus2 :"+ blobUploadedStatus);
        return blobUploadedStatus;
    }

    private BlobServiceClient getBlobServiceClientTokenCredential() {
        DefaultAzureCredential defaultCredential = new DefaultAzureCredentialBuilder().managedIdentityClientId(clientId)
                .build();
        return new BlobServiceClientBuilder().credential(defaultCredential).endpoint(endpoint).buildClient();
    }

}
