package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class VisionProductDataLg implements java.io.Serializable{
	private String visionProductID;
	private String visionGroupNumber;
	private String visionCoverageLevel;
	private String visionCoverageEffectiveDate;
    private String visionCoverageTerminationCode;
    private String visionCoverageTerminationDate;
    private String visionSubGroupNumberOrPackageCode;
    private String visionContractCodeOrDepartNumberOrClassID;

}
