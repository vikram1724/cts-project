package com.carefirst.nexus.group.enrollment.models;

import lombok.Data;

@Data
public class UpdateTransaction {

    private String file1350Content;
    
}
