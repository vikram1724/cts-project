package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class MedicareInsuranceInfoLg implements java.io.Serializable{
    private String hicNumber;
	private String rateModifier;
	private String crossReferenceSSN;
    private String medicareAEffectiveDate;
	private String medicareBEffectiveDate;
    private String medicareATerminationDate;
    private String medicareBTerminationDate;
	private String medicareEligibilityIndicator;
    private String memberEntityID;
}
