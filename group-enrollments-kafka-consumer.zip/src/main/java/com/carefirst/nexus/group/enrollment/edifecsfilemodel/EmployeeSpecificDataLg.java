package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class EmployeeSpecificDataLg implements java.io.Serializable{
	private String marriageDate;
    private String maritalStatus;
    private String employeeNumber;
	private String statusIndicator;
    private String employeeLocation;
	private String employmentHireDate;
    private String employeeSalaryAmount;
    private String employeeSalaryEffectiveDate;
    private String memberEntityId;
    
}
