 package com.carefirst.nexus.group.enrollment.repo;

import java.io.Serializable;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.carefirst.nexus.group.enrollment.entity.EnrollApplEntity;

@Repository
public interface EnrollApplRepo extends JpaRepository<EnrollApplEntity, Serializable> {

    Optional<EnrollApplEntity> findBySubmitterApplicationId(String  submitterApplicationId);

}
 