package com.carefirst.nexus.group.enrollment.util;

import java.io.StringWriter;
import java.util.HashMap;
import java.util.Map;

import javax.jms.TextMessage;
import javax.jms.DeliveryMode;
import com.tibco.tibjms.TibjmsQueue;

import org.apache.cxf.BusFactory;
import org.apache.cxf.common.jaxb.JAXBUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jms.core.JmsTemplate;
import org.apache.commons.lang.StringUtils;
import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.group.enrollment.models.UpdateAE2Transaction;
import com.carefirst.nexus.group.enrollment.service.EnrollPortalIntegrationService;
import com.nimbusds.jose.shaded.gson.Gson;
import com.nimbusds.jose.shaded.gson.GsonBuilder;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class AE2ProcessorPayload {

    @Value("${ae2.enrollment.jms.queue.name}")
    private String queueName;

    @Value("${jmsmsg}")
    private String jmsmsg;

    @Value("${soapaction}")
    private String soapAction;

    private EnrollPortalIntegrationService enrollPortalIntegrationService;

    private JmsTemplate jmsTemplate;

    public AE2ProcessorPayload(EnrollPortalIntegrationService enrollPortalIntegrationService,
            JmsTemplate jmsTemplate) {
        this.enrollPortalIntegrationService = enrollPortalIntegrationService;
        this.jmsTemplate = jmsTemplate;
    }

    public String generateAE2ProcessorPayload(MemberEnrollmentApplication transactionSubmitterPayload,
            String submittrApplicationId)
            throws RecoverableMessageException, UnrecoverableMessageException, JAXBException {
        try {
            String processorPayLoad;
            EnrollmentData ae2Payload = enrollPortalIntegrationService.enrollEmpoyeePortal(transactionSubmitterPayload,
                    submittrApplicationId);
            JAXBContext jaxbContext = JAXBContext.newInstance(EnrollmentData.class);
            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
            StringWriter sw = new StringWriter();
            Map<String, String> namespaceMap = new HashMap<>();
            namespaceMap.put(
                    "http://www.tibco.com/schemas/cf-ae2-EP-svc/SharedResources/SchemaDefinitions/EmployerPortalSchema/EmployerPortal.xsd",
                    "ns0");
            namespaceMap.put("http://www.w3.org/2003/05/soap-envelope", "SOAP-ENV");
            JAXBUtils.setNamespaceMapper(BusFactory.getDefaultBus(), namespaceMap, jaxbMarshaller);
            jaxbMarshaller.marshal(ae2Payload, sw);
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            String ae2Paylod = sendPayloadtoJMS(sw.toString());
            UpdateAE2Transaction updateAE2Transaction = new UpdateAE2Transaction();
            updateAE2Transaction.setFile834Content(ae2Paylod);
            processorPayLoad = gson.toJson(updateAE2Transaction);
            return processorPayLoad;
        } catch (Exception e) {
            throw new RecoverableMessageException(
                    "error occured while generating ae2 processor payload " + e.getMessage(), e);
        }
    }

    private String sendPayloadtoJMS(String processorPayLoad) throws RecoverableMessageException {
            try {
                    String ae2Paylaod = ae2Paylaod(processorPayLoad);
                    jmsTemplate.send(queueName, session -> {
                            TextMessage message = session
                                            .createTextMessage(ae2Paylaod);
                            message.setStringProperty("SOAPAction",
                                            soapAction);
                            message.setStringProperty("Content_Type",
                                            "application/soap+xml");
                            message.setStringProperty("Mime_Version",
                                            "1.0");

                            message.setJMSDeliveryMode(DeliveryMode.PERSISTENT);
                            message.setJMSReplyTo(new TibjmsQueue("TIBEMSQ.AE2.EP.TRXCOMPLETE.RESPONSE"));
                            return message;
                    });
                    log.info("AE2 Payload : {}", ae2Paylaod);
                    log.info("File [834] content send to queue successfully!!");
                    return ae2Paylaod;
            } catch (Exception e) {
                    log.error("ProcessorPayloadGeneratorService | sendPayloadtoJMS| exception ", e);
                    throw new RecoverableMessageException(
                                    "error occured while sending payload to jms queue " + e.getMessage(),
                                    e);
            }
    }

private String ae2Paylaod(String processorPayLoad) {
        return StringUtils.isNotEmpty(jmsmsg) ? genearteFormatedPayalod(jmsmsg)
                : genearteFormatedPayalod(processorPayLoad);
}

private String genearteFormatedPayalod(String processorPayLoad) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?><SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://www.w3.org/2003/05/soap-envelope\"><SOAP-ENV:Body>"
                + processorPayLoad.replace("\n", "").replace("\r", "")
                        .replace("  ", "").replace(
                                "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>",
                                "")
                + "</SOAP-ENV:Body></SOAP-ENV:Envelope>";
}

}
