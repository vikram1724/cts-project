package com.carefirst.nexus.group.enrollment.util;

import java.util.ArrayList;
import java.util.List;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.ProcessorPayload1;
import com.carefirst.nexus.group.enrollment.helper.Custom1350LayoutGenerator;
import com.carefirst.nexus.group.enrollment.helper.ProcessorPayloadHelper;
import com.carefirst.nexus.group.enrollment.models.UpdateTransaction;
import com.nimbusds.jose.shaded.gson.Gson;
import com.nimbusds.jose.shaded.gson.GsonBuilder;
import org.springframework.stereotype.Component;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class EdifecsProcessorPayload {

    private Custom1350LayoutGenerator custom1350LayoutGenerator;

    private BlobFileUtils blob;

    private ProcessorPayloadHelper processorPayloadHelper;

    public EdifecsProcessorPayload(Custom1350LayoutGenerator custom1350LayoutGenerator,
            BlobFileUtils blob, ProcessorPayloadHelper processorPayloadHelper) {
        this.custom1350LayoutGenerator = custom1350LayoutGenerator;
        this.blob = blob;
        this.processorPayloadHelper = processorPayloadHelper;
    }

    public String generateEdifecsProcessorPayload(String processorPayLoad,
            MemberEnrollmentApplication transactionSubmitterPayload) throws RecoverableMessageException {
        try {
            ProcessorPayload1 edifecsProcessorPayload = populateEmployeeTransactionData(
                    transactionSubmitterPayload);
            String formated1350SubmitterPayLoad = custom1350LayoutGenerator
                    .formatEmplyeeTransactionData(edifecsProcessorPayload);
            log.info("ProcessorPayloadGeneratorService | formatProcessorPayLoadData : ");
            blob.fileUploadtoBlobStorage(formated1350SubmitterPayLoad,
                    transactionSubmitterPayload.getApplication().getApplicationId());
            if (formated1350SubmitterPayLoad != null && !formated1350SubmitterPayLoad.isEmpty()) {
                processorPayLoad = getJsonPayLoad(formated1350SubmitterPayLoad);
            }
        } catch (Exception e) {
            log.error("edifecsProcessorPayload | generateEdifecsProcessorPayload | Exception", e);
            throw new RecoverableMessageException(
                    "error occured while generateEdifecsProcessorPayload " + e.getMessage(), e);
        }
        return processorPayLoad;
    }

    private ProcessorPayload1 populateEmployeeTransactionData(
            MemberEnrollmentApplication transactionSubmitterPayload) {
        log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | START");
        int detailsRecordsCount = transactionSubmitterPayload.getMembers().size();
        String detailsRecords = Integer.toString(detailsRecordsCount);
        List<EmployeeTransactionData> empTranDataLst = new ArrayList<>();
        ProcessorPayload1 pcrPayload = new ProcessorPayload1();
        if (transactionSubmitterPayload != null) {
            pcrPayload.setFileHeader(processorPayloadHelper.populateFileHeader(transactionSubmitterPayload));
            pcrPayload.setAccountHeader(processorPayloadHelper.populateAccountHeader(transactionSubmitterPayload));
            empTranDataLst.add(processorPayloadHelper.populteEmpTransactioData(transactionSubmitterPayload));
            pcrPayload.setEmployeeTransactionDatas(empTranDataLst);
            pcrPayload.setAccountTrailer(processorPayloadHelper.populateAccountTrailer(detailsRecords));
            pcrPayload.setFileTrailer(processorPayloadHelper.populteFileTrailer(detailsRecords));
            log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | pcrPayload : " + pcrPayload);
        }
        log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | START");
        return pcrPayload;
    }

    private String getJsonPayLoad(String formated1350ProcessorPayLoad) throws RecoverableMessageException {
        log.info("ProcessorPayloadGeneratorService | getJsonPayLoad| start ");
        String jsonbData = null;
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        UpdateTransaction updateTransaction = new UpdateTransaction();
        updateTransaction.setFile1350Content(formated1350ProcessorPayLoad);
        jsonbData = gson.toJson(updateTransaction);
        log.info("ProcessorPayloadGeneratorService | getJsonPayLoad| end ");
        return jsonbData;
    }

}
