package com.carefirst.nexus.group.enrollment.config;

import javax.jms.JMSException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.core.JmsTemplate;

import com.tibco.tibjms.TibjmsConnectionFactory;

import javax.jms.ConnectionFactory;

@Configuration
public class TibcoJmsConfig {

    @Value("${spring.activemq.broker-url}")
    private String brokerUrl;

    @Value("${spring.activemq.username}")
    private String username;

    @Value("${spring.activemq.password}")
    private String password;

    @Bean
    public ConnectionFactory connectionFactory() throws JMSException {
        TibjmsConnectionFactory factory = new TibjmsConnectionFactory();
        factory.setServerUrl(brokerUrl);
        factory.setUserName(username);
        factory.setUserPassword(password);
        return factory;
    }

    @Bean
    public JmsTemplate jmsTemplate(ConnectionFactory connectionFactory) {
        return new JmsTemplate(connectionFactory);
    }
}
