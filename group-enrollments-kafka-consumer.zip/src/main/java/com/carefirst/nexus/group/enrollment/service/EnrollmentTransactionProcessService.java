package com.carefirst.nexus.group.enrollment.service;

import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.group.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.utils.web.error.AppJSONException;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EnrollmentTransactionProcessService {

	private ProcessorPayloadGeneratorService processorPayloadGeneratorService;

	public EnrollmentTransactionProcessService(
			ProcessorPayloadGeneratorService processorPayloadGeneratorService) {
		this.processorPayloadGeneratorService = processorPayloadGeneratorService;

	}

	public void processPayload(TransactionListenerPayload transactionListenerPayload)
			throws RecoverableMessageException, UnrecoverableMessageException {
		log.info("EnrollmentTransactionProcessService | processPayload | START");
		try {
			String submitterappId = transactionListenerPayload.getSubmitterApplicationId();
			if (transactionListenerPayload != null && submitterappId != null && !submitterappId.isEmpty()) {
				processorPayloadGeneratorService.generateProcessorPaylod(transactionListenerPayload);
			} else {
				throw new UnrecoverableMessageException(
						"The submitterApplicationId : " + submitterappId + " and submitterpayload : "
								+ transactionListenerPayload + " should not be Null.", 
								new RuntimeException("The submitterApplicationId or submitterpayload should not be Null."));
			}
		} catch (AppJSONException | UnrecoverableMessageException e) {
			log.error("EnrollmentTransactionProcessService | processPayload| exception ", e);
			throw new UnrecoverableMessageException("Error occured in while processing submitter payload " + e.getMessage(), e);
		}catch (Exception e) {
			log.error("EnrollmentTransactionProcessService | processPayload| exception ", e);
			throw new RecoverableMessageException("Error occured in while processing submitter payload " + e.getMessage(), e);
		}
		log.info("EnrollmentTransactionProcessService | processPayload | END");
	}

}
