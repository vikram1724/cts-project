package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class OtherInsuranceInfomationLg implements java.io.Serializable{
	private String cobEmployerName;
    private String cobPolicyNumber;
	private String cobEffectiveDate;
	private String cobPolicyHolderID;
	private String cobPolicyHolderDOB;
	private String cobPolicyHolderSSN;
	private String cobTerminationDate;
    private String membersCOBMemberID;
    private String cobPolicyHolderName;
	private String cobInsuranceCompanyName;
}
