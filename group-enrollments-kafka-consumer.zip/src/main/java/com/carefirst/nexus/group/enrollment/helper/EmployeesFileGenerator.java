package com.carefirst.nexus.group.enrollment.helper;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Component;

@Component
public class EmployeesFileGenerator {
    private EmployeesFileGenerator() {
	}

	public static String padRight(String value, Integer fieldLength) {
		if (StringUtils.isNotEmpty(value)) {
			if (value.length() > fieldLength) {
				return value.substring(0, fieldLength);
			} else if (value.length() < fieldLength) {
				return StringUtils.rightPad(value, fieldLength, " ");
			} else if (value.length() == fieldLength) {
				return value;
			}
		}
		return StringUtils.rightPad("", fieldLength, " ");
	}
}
