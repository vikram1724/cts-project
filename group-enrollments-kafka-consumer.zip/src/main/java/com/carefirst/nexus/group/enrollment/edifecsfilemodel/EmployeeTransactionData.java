package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import java.util.List;

import com.carefirst.nexus.enrollments.gen.model.Broker;
import com.carefirst.nexus.enrollments.gen.model.Application;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmployeeTransactionData{
    private String recordType="20";
    private String transactionId;
    private String transactionCode;
    @JsonProperty(value = "members")
    private List<Member> members;
    @JsonProperty(value = "application")
    private Application application;
    @JsonProperty(value = "broker")
    private List<Broker> brokers;
    @JsonProperty(value = "employeeSpecificData")
    private EmployeeSpecificDataLg employeeSpecificDatalg;
    

   
	
    
}
