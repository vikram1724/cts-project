package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class FileTrailer implements java.io.Serializable{
    private String holdField;
    private String recordType;
    private String totalrecordCount;
    private String totalAccountorGroupCount;
}
