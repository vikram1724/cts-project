package com.carefirst.nexus.group.enrollment.models;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class TransactionListenerPayload {

    @JsonProperty(value = "SUBMITTER_APPLICATION_ID")
    private String submitterApplicationId;

    @JsonProperty(value = "SOURCE")
    private String source;

    @JsonProperty(value = "PROCESSOR_APPLICATION_ID")
    private String processorApplicationId;

    @JsonProperty(value = "STATUS")
    private String status;

    @JsonProperty(value = "APPLICATION_VERSION")
    private String applicationVersion;

    @JsonProperty(value = "BROCHURE_LINK")
    private String brochureLink;

    @JsonProperty(value = "SUBMISSION_STATUS")
    private String submissionStatus;

    @JsonProperty(value = "PRODUCT_LINE")
    private String productLine;

    @JsonProperty(value = "SUBSCRIBER_ID")
    private String subscriberId;

    @JsonProperty(value = "SUBMITTER_PAYLOAD")
    private String submitterPayload;

    @JsonProperty(value = "PROCESSOR_PAYLOAD")
    private String processorPayload;

    @JsonProperty(value = "BROKER_ID")
    private String brokerId;

    @JsonProperty(value = "BROKER_FIRST_NM")
    private String brokerFirstnm;

    @JsonProperty(value = "BROKER_LAST_NM")
    private String brokerLastnm;

    @JsonProperty(value = "APPLICANT_MEDICARE_ID")
    private String applicantMedicareId;

    @JsonProperty(value = "APPLICANT_FIRST_NM")
    private String applicantFirstnm;

    @JsonProperty(value = "APPLICANT_LAST_NM")
    private String applicantLastnm;

    @JsonProperty(value = "APPLICANT_DOB")
    private String applicantDob;

    @JsonProperty(value = "APPLICANT_SSN")
    private String applicantSsn;

    @JsonProperty(value = "PAYMENT_PAYLOAD")
    private String paymentPayload;

    @JsonProperty(value = "PAYMENT_STATUS")
    private String paymentStatus;
	
}
