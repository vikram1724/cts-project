package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class AccountDetails implements java.io.Serializable{
	
	private ProcessorPayload processorPayloadLg;
    
}
