package com.carefirst.nexus.group.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class AccountHeader implements java.io.Serializable{
    private String filler;
    private String fileType;
    private String groupType;
    private String holdField;
    private String recordType;
    private String companyName;
    private String contactName;
    private String pcpIndicator;
    private String renewalIndicator;
    private String dateFileSubmitted;
    private String salesPersonNumber;
    private String memberTermDateDefault;
    private String contactTelephoneNumber;
    private String resubmittedFileIndicator;
    private String uniqueCoIdentifierFedTaxId;
    private String resubmittedFileOriginalDate;
    
}
