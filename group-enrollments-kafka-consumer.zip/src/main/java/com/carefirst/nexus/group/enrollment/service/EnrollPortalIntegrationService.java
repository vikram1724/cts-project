package com.carefirst.nexus.group.enrollment.service;

import java.net.ConnectException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Address;
import com.carefirst.nexus.enrollments.gen.model.Attribute;
import com.carefirst.nexus.enrollments.gen.model.BenefitStatus;
import com.carefirst.nexus.enrollments.gen.model.Broker;
import com.carefirst.nexus.enrollments.gen.model.COB;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.MaritalStatus;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.OtherInfo;
import com.carefirst.nexus.enrollments.gen.model.Phone;
import com.carefirst.nexus.enrollments.gen.model.PhoneType;
import com.carefirst.nexus.enrollments.gen.model.ProductCategory;
import com.carefirst.nexus.enrollments.gen.model.ProductCoverage;
import com.carefirst.nexus.generate.employerportalenrollment.ws.AttributeType;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.CoverageInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.CoverageInformation.BrokerOrTPADetails;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.AddressInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.AddressInformation.MemberCommunications;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.CobraInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.Language;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails.CobDetails;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails.PcpDetails;
import com.carefirst.nexus.group.enrollment.helper.MembersProductCoverageRetrieve;

@Service
public class EnrollPortalIntegrationService {
	static final Log LOG = LogFactory.getLog(EnrollPortalIntegrationService.class);

	static DateTimeFormatter srcDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	static DateTimeFormatter localDateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd");
	static DateTimeFormatter reqDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd");
	private MembersProductCoverageRetrieve membersProductCoverageRetrieve;

	public EnrollPortalIntegrationService(MembersProductCoverageRetrieve membersProductCoverageRetrieve) {
		this.membersProductCoverageRetrieve = membersProductCoverageRetrieve;
	}

	public EnrollmentData enrollEmpoyeePortal(MemberEnrollmentApplication memberEnrollmentApplication,
			String submittrApplicationId)
			throws RecoverableMessageException, UnrecoverableMessageException {
		LOG.debug("> enrollEmpoyeePortal");
		Member subscriberMember = memberEnrollmentApplication.getMembers().stream()
				.filter(m -> Choice.Yes.equals(m.getSubscriberInd())).findAny().orElse(null);
		try {
			LOG.info("Calling Enroll");
			EnrollmentData enrollmentData = new EnrollmentData();
			CoverageInformation coverageInformation = getCoverageInformation(subscriberMember,
					memberEnrollmentApplication);
			coverageInformation.setTransID(submittrApplicationId);
			getPersonalInformation(enrollmentData, memberEnrollmentApplication);
			enrollmentData.setCoverageInformation(coverageInformation);
			if (CollectionUtils.isNotEmpty(memberEnrollmentApplication.getApplication().getAttributes())) {
				for (Attribute attribute : memberEnrollmentApplication.getApplication().getAttributes()) {
					AttributeType attr = new AttributeType();
					attr.setName(attribute.getName());
					attr.setValue(attribute.getValue());
					enrollmentData.getAttribute().add(attr);
				}
			}
			return enrollmentData;

		} catch (Exception e) {
			handleException(e);
		} finally {
			LOG.debug("< enrollEmpoyeePortal");
		}
		return null;
	}

	private void getPersonalInformation(EnrollmentData enrollmentData,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		for (Member member : memberEnrollmentApplication.getMembers()) {
			PersonalInformation personalInformation = new PersonalInformation();
			if (MemberTransactionType.ADD.equals(member.getTransactionType())) {
				personalInformation.setAddTermReinstateVoidDate(formatDateValue(member.getEffectiveDate()));
			} else if (MemberTransactionType.TERM.equals(member.getTransactionType())) {
				personalInformation.setAddTermReinstateVoidDate(formatDateValue(member.getTerminationDate()));
			} else if (MemberTransactionType.REINSTATE.equals(member.getTransactionType())) {
				personalInformation
						.setAddTermReinstateVoidDate(formatDateString(member.getAddReinstateEffectiveDate()));
			} else {
				personalInformation.setAddTermReinstateVoidDate(formatDateString(member.getAddVoidEffectiveDate()));
			}
			getAddress(member, personalInformation, memberEnrollmentApplication);
			getCobra(personalInformation, member, memberEnrollmentApplication);
			personalInformation.setDateOfBirth(formatDateString(member.getDateOfBirth()));
			if (MemberTransactionType.TERM.equals(member.getTransactionType())) {
				personalInformation.setDateOfDeath(formatDateValue(member.getTerminationDate()));
			}
			//personalInformation.setDisabilities(member.getDisabilityInd().getValue());
			personalInformation.setEmploymentSalaryDetails(null);
			personalInformation.setFirstName(member.getName().getFirstName());
			personalInformation.setGender(member.getGender().getValue());
			personalInformation.setHandicapIndicator(null);
			personalInformation.setJobTitle(null);
			personalInformation.setLastName(member.getName().getLastName());
			if (null != member.getMaintenanceReason()) {
				personalInformation.setMaintenanceReason(member.getMaintenanceReason().getValue());
			}
			if(member.getSubscriberInd().equals(Choice.Yes) && member.getMaritalStatus()!=null) {
				personalInformation.setMaritalStatus(getMaritalStatus(member));
			}
			personalInformation.setMiddleInitial(member.getName().getMiddleName());
			personalInformation.setNamePrefix(member.getName().getPrefix());
			//personalInformation.setNameSuffix(member.getName().getSuffix());
			getProductDetails(personalInformation, member);
			personalInformation.setRaceOrEthnicityCode(getRaceOrEthinicityCode(member));
			personalInformation.setRelation(member.getRelationshipCode().getValue());
			personalInformation.setSchoolName(null);
			personalInformation.setSocialSecurityNumber(member.getSocialSecurityNumber());
			personalInformation.setStudentEffectiveDate(null);
			personalInformation.setStudentIndicator(null);
			personalInformation.setStudentTermDate(null);
			personalInformation.setStudentTermReason(null);
			personalInformation.setSubscriberID(memberEnrollmentApplication.getApplication().getSubscriberId());
			personalInformation.setTrxType(member.getTransactionType().getValue());
			personalInformation.setUnionIndicator("N");
			personalInformation.setUnionName(null);
			if (null != member.getRelic() && null != member.getRelic().getLanguage()) {
				Language language = new Language();
				language.setLanguageCode(member.getRelic().getLanguage().getCode());
				personalInformation.getLanguage().add(language);
			}
			enrollmentData.getPersonalInformation().add(personalInformation);
			if (CollectionUtils.isNotEmpty(member.getAttributes())) {
				for (Attribute attribute : member.getAttributes()) {
					AttributeType attr = new AttributeType();
					attr.setName(attribute.getName());
					attr.setValue(attribute.getValue());
					personalInformation.getAttribute().add(attr);
				}
			}
		}
	}

	private String getMaritalStatus(Member member) {
		if (MaritalStatus.SINGLE.equals(member.getMaritalStatus())) {
			return "I";
		} else if (MaritalStatus.SEPARATED.equals(member.getMaritalStatus())) {
			return "S";
		} else {
			return member.getMaritalStatus().getValue();
		}
	}

	private String getRaceOrEthinicityCode(Member member) {
		if (null == member.getRelic()) {
			return "7";
		} else if (null != member.getRelic().getRace()) {
			return member.getRelic().getRace().getCode();
		} else if (null != member.getRelic().getEthnicity()) {
			return member.getRelic().getEthnicity().getCode();
		}
		return null;
	}

	private void getProductDetails(PersonalInformation personalInformation, Member member) {
		for (ProductCoverage productCoverage : member.getProductCoverages()) {
			ProductDetails productDetail = new ProductDetails();
			
			if(ProductCategory.MEDICAL.equals(productCoverage.getProductCategory())) {
				getCobDetail(productDetail, member);
			}
			getPcpDetail(productDetail, productCoverage);
			productDetail.setElectedUnits(null);
			productDetail.setInsuranceLineCode(getInsuranceLineCode(productCoverage));
			productDetail.setProductClassId(productCoverage.getClassId());
			productDetail.setProductStartDate(formatDateValue(productCoverage.getEffectiveDate()));
			productDetail.setProductTermDate(formatDateValue(productCoverage.getTerminationDate()));
			productDetail.setProductTrxType(productCoverage.getTransactionType().getValue());
			personalInformation.getProductDetails().add(productDetail);
		}
	}

	private String getInsuranceLineCode(ProductCoverage productCoverage) {
		if (ProductCategory.MEDICAL.equals(productCoverage.getProductCategory())) {
			return "HLT";
		} else if (ProductCategory.DRUG.equals(productCoverage.getProductCategory())) {
			return "PDG";
		} else {
			return productCoverage.getProductCategory().getValue();
		}
	}

	private String formatDateString(String dateValue) {
		try {
			return LocalDate.parse(dateValue, localDateFormat)
					.format(reqDateFormat);
		} catch (Exception e) {
			return dateValue;
		}
	}

	private String formatDateValue(LocalDate date) {
		try {
			return date
					.format(reqDateFormat);
		} catch (Exception e) {
			return null;
		}

	}

	private void getPcpDetail(ProductDetails productDetail, ProductCoverage productCoverage) {
		if (CollectionUtils.isNotEmpty(productCoverage.getPcp())
				&& !"TEMP".equalsIgnoreCase(productCoverage.getPcp().get(0).getProviderId())) {
			PcpDetails pcpDetail = new PcpDetails();
			pcpDetail.setEntityCode(null);
			pcpDetail.setPcpChangeEffDate(null);
			pcpDetail.setPcpChangeReasonCode(null);
			pcpDetail.setPcpID(productCoverage.getPcp().get(0).getProviderId());
			productDetail.setPcpDetails(pcpDetail);
		}

	}

	private void getCobDetail(ProductDetails productDetail, Member member) {
		for (COB cob : member.getCobs()) {
			if (Choice.Yes.equals(cob.getOtherInsuranceIndicator())) {
				for (OtherInfo otherInfo : cob.getOtherInfo()) {
					CobDetails cobDetail = new CobDetails();
					cobDetail.setBenefitEligDate(null);
					cobDetail.setCobCode("1");
					cobDetail.setFirstName(member.getName().getFirstName());
					cobDetail.setLastName(member.getName().getLastName());
					if (null != otherInfo.getPayerSeqNumber()) {
						cobDetail.setPayerSeqNumber(otherInfo.getPayerSeqNumber().getValue());
					} else {
						cobDetail.setPayerSeqNumber("U");
					}
					cobDetail.setPolicyNumber(otherInfo.getPolicyholderNumber());
					cobDetail.setServiceType(null);
					cobDetail.setSsn(member.getSocialSecurityNumber());
					cobDetail.setTrxType(MemberTransactionType.ADD.getValue());
					productDetail.setCobDetails(cobDetail);
				}
			} else {
				CobDetails cobDetail = new CobDetails();
				cobDetail.setBenefitEligDate(null);
				cobDetail.setCobCode("6");
				cobDetail.setPayerSeqNumber("U");
				cobDetail.setTrxType(MemberTransactionType.ADD.getValue());
				productDetail.setCobDetails(cobDetail);
			}
		}
	}

	private void getCobra(PersonalInformation personalInformation, Member member,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		if (BenefitStatus.COBRA.equals(member.getBenefitStatus())) {
			CobraInformation cobraInfo = new CobraInformation();
			cobraInfo.setCoverageEffDate(formatDateValue(member.getEffectiveDate()));
			cobraInfo.setCoverageTermDate(formatDateValue(member.getTerminationDate()));
			cobraInfo.setOrignalGroupId(memberEnrollmentApplication.getApplication().getGroup().getGroupId());
			cobraInfo.setOrignalSubGroupId(member.getSubGroupId());
			cobraInfo.setOrignalSubsId(memberEnrollmentApplication.getApplication().getSubscriberId());
			cobraInfo.setSubsCoveredPeriod(null);
			cobraInfo.setSubsDisbltyEffDate(null);
			cobraInfo.setSubsDisbltyIND(null);
			cobraInfo.setSubsTermRsn(null);
			personalInformation.getCobraInformation().add(cobraInfo);
		}
	}

	private void getAddress(Member member, PersonalInformation personalInformation,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		for (Address addr : member.getAddress()) {
			AddressInformation address = new AddressInformation();
			address.setAddressLine1(addr.getLine1());
			address.setAddressLine2(addr.getLine2());
			address.setCity(addr.getCity());
			address.setState(addr.getStateCode());
			address.setWorkStateCode(addr.getStateCode());
			address.setZipCode(addr.getZipCode());
			if (null != member.getContact() && CollectionUtils.isNotEmpty(member.getContact().getPhone())) {
				member.getContact().getPhone().stream().forEach(phone -> {
					MemberCommunications memberCommunications = new MemberCommunications();
					memberCommunications.setCommNumberOrEmail(phone.getPhoneNumber());
					memberCommunications.setCommType(getCommType(phone));
					address.getMemberCommunications().add(memberCommunications);
				});
			}
			if (null != member.getContact() && CollectionUtils.isNotEmpty(member.getContact().getEmail())) {
				member.getContact().getEmail().stream().forEach(email -> {
					MemberCommunications memberCommunications = new MemberCommunications();
					memberCommunications.setCommNumberOrEmail(email.getEmailAddress());
					memberCommunications.setCommType("EM");
					address.getMemberCommunications().add(memberCommunications);
				});
			}
			if (null != memberEnrollmentApplication.getApplication().getApplicantConsent()) {
				address.setConsentFlag(memberEnrollmentApplication.getApplication().getApplicantConsent().getValue());
			}
			personalInformation.getAddressInformation().add(address);
		}
	}

	private String getCommType(Phone phone) {
		if (PhoneType.H.equals(phone.getPhoneType())) {
			return "HP";
		} else if (PhoneType.W.equals(phone.getPhoneType())) {
			return "WP";
		} else if (PhoneType.C.equals(phone.getPhoneType())) {
			return "CP";
		}
		return phone.getPhoneType().getValue();
	}

	private CoverageInformation getCoverageInformation(Member subscriberMember,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		CoverageInformation coverageInformation = new CoverageInformation();
		coverageInformation.setBenefitStatus(subscriberMember.getBenefitStatus().getValue());
		coverageInformation.setClassID(subscriberMember.getProductCoverages().get(0).getClassId());
		coverageInformation
				.setContractType(membersProductCoverageRetrieve
						.getCoveragetype(memberEnrollmentApplication.getMembers().stream()
								.filter(member -> !MemberTransactionType.TERM.equals(member.getTransactionType()))
								.toList())
						.getValue());
		coverageInformation.setEmploymentStatus(subscriberMember.getEmploymentStatus().getValue());
		coverageInformation.setGroupName(memberEnrollmentApplication.getApplication().getGroup().getGroupName());
		coverageInformation
				.setGroupSubGroupNumber(memberEnrollmentApplication.getApplication().getGroup().getGroupId()
						+ subscriberMember.getSubGroupId());
		coverageInformation.setHireDate(formatDateValue(subscriberMember.getHireDate()));
		coverageInformation.setOriginalEffDate(formatDateValue(LocalDate.parse(subscriberMember.getOriginalEffdate())));
		return coverageInformation;
	}

	private void getBroker(CoverageInformation coverageInformation, List<Broker> brokers) {
		for (Broker broker : brokers) {
			BrokerOrTPADetails brokerOrTPADetails = new BrokerOrTPADetails();
			brokerOrTPADetails.setBrokerOrTPACode(broker.getTradingPartnerId());
			brokerOrTPADetails.setBrokerOrTPAName(broker.getTradingPartnerName());
			coverageInformation.getBrokerOrTPADetails().add(brokerOrTPADetails);
		}
	}

	private void handleException(Exception e) throws RecoverableMessageException, UnrecoverableMessageException {
		LOG.debug("> handleException");
		if (e instanceof ConnectException) {
			LOG.error("Error in connecting EMPI (Axway) Service: " + e);
			throw new RecoverableMessageException(e.getMessage(), e);
		} else {
			LOG.error("Error occured while getting subscriberId from EMPI: " + e);
			throw new UnrecoverableMessageException(e.getMessage(), e);
		}
	}

}
