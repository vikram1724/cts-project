package com.carefirst.nexus.group.enrollment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.Status;
import com.carefirst.nexus.group.enrollment.constants.EdifecsFileConstants;
import com.carefirst.nexus.group.enrollment.helper.MembersProductCoverageRetrieve;
import com.carefirst.nexus.group.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.group.enrollment.util.AE2ProcessorPayload;
import com.carefirst.nexus.group.enrollment.util.EdifecsProcessorPayload;
import com.carefirst.nexus.groupdetails.gen.model.GroupDetailsResponse;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcessorPayloadGeneratorService {

    boolean edifecs = false;

    @Value("${edifecsCodes}")
    private List<String> edifecsCodes;

    private EdifecsProcessorPayload edifecsProcessorPayload;
    private AE2ProcessorPayload ae2ProcessorPayload;
    private MeberEnrollmetApiService meberEnrollmetApiService;
    private EmpiIntegrationService empiIntegrationService;
    private MembersProductCoverageRetrieve membersProductCoverageRetrieve;
    private GroupDetailsService groupDetailsService;

    public ProcessorPayloadGeneratorService(
            MeberEnrollmetApiService meberEnrollmetApiService,
            EmpiIntegrationService empiIntegrationService,
            MembersProductCoverageRetrieve membersProductCoverageRetrieve,
            EdifecsProcessorPayload edifecsProcessorPayload,
            AE2ProcessorPayload ae2ProcessorPayload,
            GroupDetailsService groupDetailsService) {
        this.meberEnrollmetApiService = meberEnrollmetApiService;
        this.empiIntegrationService = empiIntegrationService;
        this.membersProductCoverageRetrieve = membersProductCoverageRetrieve;
        this.groupDetailsService = groupDetailsService;
        this.ae2ProcessorPayload = ae2ProcessorPayload;
        this.edifecsProcessorPayload = edifecsProcessorPayload;
    }

    public String generateProcessorPaylod(TransactionListenerPayload transactionListenerPayload)
            throws RecoverableMessageException, UnrecoverableMessageException {
        log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | START");
        log.info("ProcessorPayloadGeneratorService | submitterPayLoad : " + transactionListenerPayload);
        String processorPayLoad = null;
        String submitterAppId = transactionListenerPayload.getSubmitterApplicationId();
        String status = transactionListenerPayload.getStatus();
        String submitterPayload = null;
        String errMsg = null;
        try {
            submitterPayload = transactionListenerPayload.getSubmitterPayload();
            if (submitterPayload != null && !submitterPayload.isEmpty()) {
                ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                        .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
                mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                MemberEnrollmentApplication transactionSubmitterPayload = mapper.readValue(submitterPayload,
                        MemberEnrollmentApplication.class);
                String givenSubscriberId = transactionSubmitterPayload.getApplication().getSubscriberId();
                log.info("givenSubscriberId from submitter payload is {}", givenSubscriberId);
                Member subscriberMember = transactionSubmitterPayload.getMembers().stream()
                        .filter(m -> Choice.Yes.equals(m.getSubscriberInd())).findAny().orElse(null);
                String generatedSubscriberId = generateSubscriberIdWithEMPI(subscriberMember);
                log.info("generatedSubscriberId from EMPI service is {}", generatedSubscriberId);
                if (!StringUtils.hasText(givenSubscriberId)) {
                    transactionSubmitterPayload.getApplication().setSubscriberId(generatedSubscriberId);
                } else if (!givenSubscriberId.equalsIgnoreCase(generatedSubscriberId)) {
                    meberEnrollmetApiService.updateMemberEnrollment(submitterAppId,
                            processorPayLoad,
                            "Given subscriber id is invalid, Valid id is " + generatedSubscriberId,
                            Status.NOT_SUBMITTED, givenSubscriberId);
                    throw new UnrecoverableMessageException("Given subscriber id is invalid.", new RuntimeException("Given subscriber id is invalid"));
                }

                membersProductCoverageRetrieve.addExistingProducts(transactionSubmitterPayload);

                GroupDetailsResponse groupDetailsResponse = groupDetailsService
                        .getGroupDetails(transactionSubmitterPayload.getApplication().getGroup().getGroupId());

                if (groupDetailsResponse != null) {
                    if (null != groupDetailsResponse.getGroup()
                            && null != groupDetailsResponse.getGroup().getRelatedEntities()
                            && !CollectionUtils.isEmpty(groupDetailsResponse.getGroup().getRelatedEntities())) {
                        edifecs = groupDetailsResponse.getGroup().getRelatedEntities().stream()
                                .anyMatch(e -> edifecsCodes.contains(e.getEntityRelationType().getCode()));
                    }
                }

                log.info("ProcessorPayloadGeneratorService | transactionListenerPayload : ");
                if (edifecs) {
                    log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | edifecsProcessorPayload : ");
                    processorPayLoad = edifecsProcessorPayload.generateEdifecsProcessorPayload(processorPayLoad, transactionSubmitterPayload);
                } else {
                    processorPayLoad = ae2ProcessorPayload.generateAE2ProcessorPayload(transactionSubmitterPayload,
                            transactionListenerPayload.getSubmitterApplicationId());
                }

                log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | processorPayLoad : ");
                if (processorPayLoad != null && !processorPayLoad.isEmpty() && submitterAppId != null
                        && !submitterAppId.isEmpty() && status != null && !status.isEmpty()
                        && status.equalsIgnoreCase(EdifecsFileConstants.STATUS_PENDING)) {
                    meberEnrollmetApiService.updateMemberEnrollment(submitterAppId, processorPayLoad, errMsg,
                            Status.SUBMITTED, transactionSubmitterPayload.getApplication().getSubscriberId());

                }
            } else {
                throw new UnrecoverableMessageException(
                        "ProcessorPayloadGeneratorService | generateProcessorPaylod | submitterPayload : "
                                + submitterPayload + "Should not be Null or Empty. ", new RuntimeException("SubmitterPayLoad Should not be Null or Empty"));
            }
        } catch (UnrecoverableMessageException e) {
            log.error("ProcessorPayloadGeneratorService | generateProcessorPaylod| exception ", e);
            throw new UnrecoverableMessageException("Error occured in while generating processing payload " + e.getMessage(), e);
        } catch (Exception e) {
            log.error("ProcessorPayloadGeneratorService | generateProcessorPaylod| exception ", e);
            throw new RecoverableMessageException("Error occured in while generating processing payload " + e.getMessage(), e);
        }
        log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | Ends");
        return processorPayLoad;
    }

    private String generateSubscriberIdWithEMPI(Member subscriberMember) throws Exception {
        log.info("ProcessorPayloadGeneratorService | generateSubscriberIdWithEMPI | Ends");
        String subscriberId = null;
        try {
            subscriberId = empiIntegrationService.getSubscriberId(subscriberMember);
            return subscriberId;
        } catch (Exception e) {
            log.info("ProcessorPayloadGeneratorService | generateSubscriberIdWithEMPI | Exception" +e.getMessage());
            throw e;
        }
    }

}
