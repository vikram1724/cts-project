package com.carefirst.nexus.group.enrollment.service;

import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClientResponseException;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.groupdetails.gen.api.GroupDetailsApi;
import com.carefirst.nexus.groupdetails.gen.model.GroupDetailsResponse;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class GroupDetailsService {

    private GroupDetailsApi groupDetailsApi;

    public GroupDetailsService(GroupDetailsApi groupDetailsApi) {
        this.groupDetailsApi = groupDetailsApi;
    }

    public GroupDetailsResponse getGroupDetails(String groupId) throws RecoverableMessageException {
        log.info("> getGroupDetails | groupId: {}", groupId);
        GroupDetailsResponse response = null;
        try {
            response = groupDetailsApi.getGroup(groupId, null, null, null, null, null).block();
            return response;
        } catch (WebClientResponseException e) {
            throw new RecoverableMessageException("Error occured while getting Group Details" + e.getMessage(), e);
        } finally {
            log.info("< getGroupDetails | GroupDetailsResponse: {}", response);
        }
    }
}
