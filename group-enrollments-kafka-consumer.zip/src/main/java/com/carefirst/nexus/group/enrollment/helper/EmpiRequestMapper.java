package com.carefirst.nexus.group.enrollment.helper;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.apache.commons.lang.StringUtils;
import org.springframework.util.CollectionUtils;

import com.carefirst.nexus.enrollments.gen.model.Address;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.Name;
import com.carefirst.nexus.enrollments.gen.model.Phone;
import com.carefirst.nexus.generate.ws.ObjectFactory;
import com.carefirst.nexus.generate.ws.RegisterMemberRequest;
import com.carefirst.nexus.generate.ws.RegisterMemberRequest.RegisterMember;
import com.carefirst.nexus.group.enrollment.constants.EnrollmentConstants;
import com.carefirst.nexus.utils.web.error.AppJSONException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class EmpiRequestMapper {

	static DateTimeFormatter srcDateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd");
	static DateTimeFormatter regMemberDateFormat = DateTimeFormatter.ofPattern("uuuu/MM/dd");
	RegisterMember registerMember = null;
	RegisterMember.Address address = new RegisterMember.Address();
	RegisterMember.Name name = new RegisterMember.Name();
	RegisterMember.Phone phone = new RegisterMember.Phone();

	public RegisterMemberRequest createEmpiRequest(Member member) {
		log.debug("> createEmpiRequest");
		registerMember = new RegisterMember();
		try {
			log.info("Creating Empi Request from selected product coverage");
			mapMemberDetails(member);

			ObjectFactory factory = new ObjectFactory();
			RegisterMemberRequest registerMemberRequest = factory.createRegisterMemberRequest();

			registerMember.setEnrollmentSystem(EnrollmentConstants.EMPI_ENROLL_SYSTEM);
			registerMember.setMemberRelationshipCode(EnrollmentConstants.MEM_RELATIONSHIP_CODE);
			registerMember.setMemberSequenceNumber(EnrollmentConstants.MEM_SEQUENCE_NUMBER);

			registerMemberRequest.setRegisterMember(registerMember);
			registerMemberRequest.setReuseSubscriberId(true);
			log.debug("< createEmpiRequest");
			log.info("Empi request created ");
			return registerMemberRequest;
		} catch (Exception e) {
			log.error("Error in RegisterMember mapping: {}", e.getMessage());
		}
		return null;
	}

	public void mapMemberDetails(Member member) {
		Name memberName = null;
		try {
			memberName = member.getName();
			name.setFirstName(memberName.getFirstName());
			if (StringUtils.isNotEmpty(memberName.getMiddleName())) {
				name.setMiddleName(memberName.getMiddleName().length() > 1 ? memberName.getMiddleName().substring(0, 1)
						: memberName.getMiddleName());
			}
			name.setLastName(memberName.getLastName());

			Address memberAddress = member.getAddress().get(0);
			address.setCity(memberAddress.getCity());
			address.setCountry(memberAddress.getCountryCode());
			address.setLine1(memberAddress.getLine1());
			address.setLine2(memberAddress.getLine2());
			address.setState(memberAddress.getStateCode());
			address.setZip(memberAddress.getZipCode());

			Phone memPhone = null;
			if (null != member.getContact() && !CollectionUtils.isEmpty(member.getContact().getPhone())) {
				memPhone = member.getContact().getPhone().stream().filter(p -> Choice.Yes.equals(p.getIsPrimary()))
						.findAny()
						.orElse(null);
			}
			String memberPhoneNumber = null;

			if (memPhone != null) {
				if (null != memPhone.getPhoneNumber()) {
					memberPhoneNumber = memPhone.getPhoneNumber();
				}
				if (memberPhoneNumber != null && memberPhoneNumber.length() == 10) {
					phone.setAreaCode(memberPhoneNumber.substring(0, 3));
					phone.setNumber(memberPhoneNumber.substring(3));
				}
			}
			registerMember.setName(name);
			registerMember.setAddress(address);
			registerMember.setPhone(phone);
			registerMember.setSsn(member.getSocialSecurityNumber());
			// registerMember.setAlternateId(member.getMedicareNumber());
			registerMember.setSsn(member.getSocialSecurityNumber());
			registerMember.setBirthDate(
					LocalDate.parse(member.getDateOfBirth(), srcDateFormat).format(regMemberDateFormat));
			registerMember.setGender(member.getGender().getValue());

		} catch (Exception e) {
			log.error("RegisterMember mapping failed, please check data received from Kafka Topic: {}", e.getMessage());
			throw new AppJSONException(e.getMessage());
		}
	}
}
