package com.carefirst.nexus.group.enrollment.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.group.enrollment.entity.EnrollApplEntity;
import com.carefirst.nexus.group.enrollment.repo.EnrollApplRepo;
import com.carefirst.nexus.group.enrollment.service.DataBaseService;

@RunWith(MockitoJUnitRunner.class)
public class DataBaseServiceTest {

    @InjectMocks
    DataBaseService dataBaseService;

    @Mock
    EnrollApplRepo repo;

    @Test
    public void findBysubmitterAppIdTest() {
        EnrollApplEntity enrollApplEntity = new EnrollApplEntity();
        enrollApplEntity.setApplicantFirstnm("werr");
        enrollApplEntity.setSubmitterApplicationId("1234");
        enrollApplEntity.setStatus("OK");
        Optional<EnrollApplEntity> entityOptional = Optional.of(enrollApplEntity);
        when(repo.findBySubmitterApplicationId(Mockito.any())).thenReturn(entityOptional);
        assertNotNull(dataBaseService.findBysubmitterAppId("abcd"));
    }

}
