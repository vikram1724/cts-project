package com.carefirst.nexus.group.enrollment.util;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.StringWriter;

import javax.jms.TextMessage;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.group.enrollment.service.EnrollPortalIntegrationService;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;

@RunWith(MockitoJUnitRunner.Silent.class)
public class AE2ProcessorPayloadTest {

    @InjectMocks
    private AE2ProcessorPayload ae2ProcessorPayload;

    @Mock
    private EnrollPortalIntegrationService enrollPortalIntegrationService;

    @Mock
    private JmsTemplate jmsTemplate;

    @Mock
    private MemberEnrollmentApplication transactionSubmitterPayload;

    @Mock
    private EnrollmentData enrollmentData;

    @Mock
    private TextMessage textMessage;

    @Before
    public void setUp() throws Exception {
        when(enrollPortalIntegrationService.enrollEmpoyeePortal(any(), any())).thenReturn(enrollmentData);
        doNothing().when(jmsTemplate).send(any(String.class), any(MessageCreator.class));
    }

    @Test
    public void testGenerateAE2ProcessorPayload() throws Exception {
        String submittrApplicationId = "12345";
        String result = ae2ProcessorPayload.generateAE2ProcessorPayload(transactionSubmitterPayload,
                submittrApplicationId);
        assertNotNull(result);
        verify(enrollPortalIntegrationService).enrollEmpoyeePortal(any(), any());
        // verify(jmsTemplate).send(any(String.class), any(MessageCreator.class));
    }

    @Test(expected = RecoverableMessageException.class)
    public void testGenerateAE2ProcessorPayload_Exception() throws Exception {
        when(enrollPortalIntegrationService.enrollEmpoyeePortal(any(), any()))
                .thenThrow(new RuntimeException("Test Exception"));
        ae2ProcessorPayload.generateAE2ProcessorPayload(transactionSubmitterPayload, "12345");
    }

    // @Test(expected = RecoverableMessageException.class)
    // public void testSendPayloadtoJMS_Exception() throws Exception {
    // doThrow(new JMSException("Test
    // Exception")).when(jmsTemplate).send(any(String.class),
    // any(MessageCreator.class));
    // ae2ProcessorPayload.sendPayloadtoJMS("testPayload");
    // }

    // @Test
    // public void testSendPayloadtoJMS_Success() throws Exception {
    // ae2ProcessorPayload.sendPayloadtoJMS("testPayload");
    // verify(jmsTemplate).send(any(String.class), any(MessageCreator.class));
    // }

    @Test
    public void testMarshalEnrollmentData() throws JAXBException {
        JAXBContext jaxbContext = JAXBContext.newInstance(EnrollmentData.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        StringWriter sw = new StringWriter();
        jaxbMarshaller.marshal(enrollmentData, sw);
        assertNotNull(sw.toString());
    }
}
