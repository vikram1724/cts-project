
package com.carefirst.nexus.group.enrollment.util;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.ProcessorPayload1;
import com.carefirst.nexus.group.enrollment.helper.Custom1350LayoutGenerator;
import com.carefirst.nexus.group.enrollment.helper.ProcessorPayloadHelper;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EdifecsProcessorPayloadTest {

    @InjectMocks
    private EdifecsProcessorPayload edifecsProcessorPayload;

    @Mock
    private Custom1350LayoutGenerator custom1350LayoutGenerator;

    @Mock
    private BlobFileUtils blob;

    @Mock
    private ProcessorPayloadHelper processorPayloadHelper;

    @Mock
    private MemberEnrollmentApplication transactionSubmitterPayload;

    @Mock
    private ProcessorPayload1 processorPayload1;

    @Mock
    private EmployeeTransactionData employeeTransactionData;

    @Before
    public void setUp() throws Exception {
        when(processorPayloadHelper.populateFileHeader(any())).thenReturn(null);
        when(processorPayloadHelper.populateAccountHeader(any())).thenReturn(null);
        when(processorPayloadHelper.populteEmpTransactioData(any())).thenReturn(employeeTransactionData);
        when(processorPayloadHelper.populateAccountTrailer(any())).thenReturn(null);
        when(processorPayloadHelper.populteFileTrailer(any())).thenReturn(null);
        when(custom1350LayoutGenerator.formatEmplyeeTransactionData(any())).thenReturn("formattedData");
        when(transactionSubmitterPayload.getMembers()).thenReturn(Collections.singletonList(null));
    }

    // @Test
    // public void testGenerateEdifecsProcessorPayload() throws Exception {
    // String result =
    // edifecsProcessorPayload.generateEdifecsProcessorPayload("payload",
    // transactionSubmitterPayload);
    // assertNotNull(result);
    // verify(blob).fileUploadtoBlobStorage(any(), any());
    // }

    @Test(expected = RecoverableMessageException.class)
    public void testGenerateEdifecsProcessorPayload_Exception() throws Exception {
        doThrow(new RuntimeException("Test Exception")).when(custom1350LayoutGenerator)
                .formatEmplyeeTransactionData(any());
        edifecsProcessorPayload.generateEdifecsProcessorPayload("payload", transactionSubmitterPayload);
    }

    // @Test
    // public void testPopulateEmployeeTransactionData() {
    // ProcessorPayload1 result =
    // edifecsProcessorPayload.populateEmployeeTransactionData(transactionSubmitterPayload);
    // assertNotNull(result);
    // }

    // @Test
    // public void testGetJsonPayLoad() throws RecoverableMessageException {
    // String result = edifecsProcessorPayload.getJsonPayLoad("formattedData");
    // assertNotNull(result);
    // }
}
