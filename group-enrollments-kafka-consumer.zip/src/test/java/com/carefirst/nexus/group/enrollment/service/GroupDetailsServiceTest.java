package com.carefirst.nexus.group.enrollment.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.groupdetails.gen.api.GroupDetailsApi;
import com.carefirst.nexus.groupdetails.gen.model.GroupDetailsResponse;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.class)
public class GroupDetailsServiceTest {

    @Mock
    private GroupDetailsApi groupDetailsApi;

    @InjectMocks
    private GroupDetailsService groupDetailsService;

    @Before
    public void setUp() {
        groupDetailsService = new GroupDetailsService(groupDetailsApi);
    }

    @Test
    public void testGetGroupDetailsSuccess() throws RecoverableMessageException {
        GroupDetailsResponse mockResponse = new GroupDetailsResponse();
        when(groupDetailsApi.getGroup(anyString(), any(), any(), any(), any(), any()))
                .thenReturn(Mono.just(mockResponse));

        GroupDetailsResponse response = groupDetailsService.getGroupDetails("123");
        assertNotNull(response);
    }

    @Test(expected = RecoverableMessageException.class)
    public void testGetGroupDetailsFailure() throws RecoverableMessageException {
        when(groupDetailsApi.getGroup(anyString(), any(), any(), any(), any(), any()))
                .thenThrow(WebClientResponseException.class);

        groupDetailsService.getGroupDetails("123");
    }
}
