package com.carefirst.nexus.group.enrollment.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.api.MemberEnrollmentsApiApi;
import com.carefirst.nexus.enrollments.gen.model.Application;
import com.carefirst.nexus.enrollments.gen.model.ApplicationDetails;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentDetailsResponse;
import com.carefirst.nexus.enrollments.gen.model.Status;
import com.carefirst.nexus.enrollments.gen.model.UpdateMemberEnrollmentResponse;
import com.carefirst.nexus.group.enrollment.service.MeberEnrollmetApiService;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.class)
public class MeberEnrollmetApiServiceTest {

    @InjectMocks
    MeberEnrollmetApiService service;

    @Mock
    MemberEnrollmentsApiApi memberEnrollmentsApi;

    @Test
    public void updateMemberEnrollmentTest() throws RecoverableMessageException{
        when(memberEnrollmentsApi.updateMemberEnrollment(any())).thenReturn(Mono.just(new UpdateMemberEnrollmentResponse()));
        assertNotNull(service.updateMemberEnrollment("123", "test", "test", Status.DRAFT, "123"));
    }

    @Test
    public void updateMemberEnrollmentTest1() throws RecoverableMessageException{
        when(memberEnrollmentsApi.updateMemberEnrollment(any())).thenReturn(null);
        service.updateMemberEnrollment("123", "test", "test", Status.DRAFT, "123"); 
        verify(memberEnrollmentsApi).updateMemberEnrollment(any());
    }

    @Test(expected = Exception.class)
    public void updateMemberEnrollmentTest2() throws RecoverableMessageException{
        when(memberEnrollmentsApi.updateMemberEnrollment(any())).thenThrow(new RuntimeException("test"));
        service.updateMemberEnrollment("123", "test", "test", Status.DRAFT, "123"); 
    }

    @Test
    public void getEnrollmentStatusTest_validResponse() {
        ApplicationDetails appDetail1 = new ApplicationDetails();
        appDetail1.setStatus("APPROVED");
        ApplicationDetails appDetail2 = new ApplicationDetails();
        appDetail2.setStatus("PENDING");
        MemberEnrollmentDetailsResponse mockResponse = new MemberEnrollmentDetailsResponse();
        mockResponse.setApplication(List.of(appDetail1, appDetail2));
        when(memberEnrollmentsApi.getMemberEnrollmentDetails(any(), any(), any(), any(), any())).thenReturn(Mono.just(mockResponse));
        Application mockApplication = new Application();
        mockApplication.setSubscriberId("123");
        MemberEnrollmentApplication memberApplication = new MemberEnrollmentApplication();
        memberApplication.setApplication(mockApplication);
        List<String> statuses = service.getEnrollmentStatus(memberApplication);
        assertNotNull(statuses);
        assertEquals(2, statuses.size());
        assertEquals("APPROVED", statuses.get(0));
        assertEquals("PENDING", statuses.get(1));
    }

    @Test
    public void getEnrollmentStatusTest_nullResponse() {
        when(memberEnrollmentsApi.getMemberEnrollmentDetails(any(), any(), any(), any(), any())).thenReturn(null);
        Application mockApplication = new Application();
        mockApplication.setSubscriberId("123");
        MemberEnrollmentApplication memberApplication = new MemberEnrollmentApplication();
        memberApplication.setApplication(mockApplication);
        List<String> statuses = service.getEnrollmentStatus(memberApplication);
        assertNotNull(statuses);
        assertTrue(statuses.isEmpty());
    }

   @Test(expected = RuntimeException.class)
   public void getEnrollmentStatusTest_exception() {
        when(memberEnrollmentsApi.getMemberEnrollmentDetails(any(), any(), any(), any(), any())).thenThrow(new RuntimeException("API Error"));
        Application mockApplication = new Application();
        mockApplication.setSubscriberId("123");
        MemberEnrollmentApplication memberApplication = new MemberEnrollmentApplication();
        memberApplication.setApplication(mockApplication);
        service.getEnrollmentStatus(memberApplication);
    }
    
}
