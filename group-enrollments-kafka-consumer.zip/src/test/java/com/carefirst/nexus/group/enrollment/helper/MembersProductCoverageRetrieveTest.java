package com.carefirst.nexus.group.enrollment.helper;

import static org.junit.Assert.assertNull;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Application;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.ProductCoverage;
import com.carefirst.nexus.enrollments.gen.model.RelationshipCode;
import com.carefirst.nexus.membercoverage.gen.model.CoverageLevel;
import com.carefirst.nexus.membercoverage.gen.model.CoverageLevelCode;
import com.carefirst.nexus.membercoverage.gen.model.CoverageStatus;
import com.carefirst.nexus.membercoverage.gen.model.MemberCoverage;
import com.carefirst.nexus.membercoverage.gen.model.MemberCoveragesResponse;
import com.carefirst.nexus.membercoverage.gen.model.MemberDescriptor;
import com.carefirst.nexus.membercoverage.gen.model.MemberEnrollmentDetails;
import com.carefirst.nexus.membercoverage.gen.model.Product;
import com.carefirst.nexus.membercoverage.gen.model.ProductCategory;
import com.carefirst.nexus.group.enrollment.helper.MembersProductCoverageRetrieve;
import com.carefirst.nexus.group.enrollment.service.MemberCoverageApiService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@RunWith(MockitoJUnitRunner.class)
public class MembersProductCoverageRetrieveTest {

    @InjectMocks
    MembersProductCoverageRetrieve service;

    @Mock
    MemberCoverageApiService memberCoverageApiService;

    MemberEnrollmentApplication memberEnrollmentApplication;

    @Before
    public void setUp() throws IOException {
        ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
        memberEnrollmentApplication = mapper.readValue(
                new File("src/test/resources/memberEnrollmentApplication_request.json"),
                MemberEnrollmentApplication.class);
        memberEnrollmentApplication.getApplication().setSubscriberId("123");
    }

    @Test
    public void addExistingProductsTest1() throws UnrecoverableMessageException, RecoverableMessageException{
        MemberCoveragesResponse coverageResponse = new MemberCoveragesResponse();
        memberEnrollmentApplication.getMembers().get(0).setTransactionType(MemberTransactionType.CHANGE);
        List<MemberCoverage> memberCoverages = new ArrayList<>();
        MemberCoverage cov = new MemberCoverage();
        MemberEnrollmentDetails details = new MemberEnrollmentDetails();
        CoverageStatus coverageStatus = new CoverageStatus();
        coverageStatus.setStatusDescription("Active Coverage");
        coverageStatus.setTerminationDate(LocalDate.now());
        details.setCoverageStatus(coverageStatus);
        Product product = new Product();
        product.setProductCode("123");
        product.setCategory(ProductCategory.MEDICAL);
        details.setProduct(List.of(product));
        details.setPackageClassId("123");
        CoverageLevel coverageLevel = new CoverageLevel();
        coverageLevel.setCode(CoverageLevelCode.CHILDREN_ONLY);
        details.setCoverageLevel(coverageLevel);
        cov.setMemberEnrollmentDetails(details);
        MemberDescriptor descriptor = new MemberDescriptor();
        descriptor.setMemberLifeId("110055288");
        cov.setMemberDescriptor(descriptor);
        memberCoverages.add(cov);
        coverageResponse.setMemberCoverages(memberCoverages);
        when(memberCoverageApiService.getMemberCoverages(anyString())).thenReturn(coverageResponse);
        service.addExistingProducts(memberEnrollmentApplication);
        verify(memberCoverageApiService).getMemberCoverages(anyString());
    }

    @Test
    public void addExistingProductTest2() throws UnrecoverableMessageException, RecoverableMessageException{
        MemberCoveragesResponse covResponse = new MemberCoveragesResponse();
        covResponse.setMemberCoverages(List.of());
        when(memberCoverageApiService.getMemberCoverages(anyString())).thenReturn(new MemberCoveragesResponse());
        service.addExistingProducts(memberEnrollmentApplication);
        verify(memberCoverageApiService).getMemberCoverages(anyString());
    }

    @Test
    public void addExistingProductsTest3() throws UnrecoverableMessageException, RecoverableMessageException{
        Member member = memberEnrollmentApplication.getMembers().get(0);
        memberEnrollmentApplication.setMembers(List.of(member));
        service.addExistingProducts(memberEnrollmentApplication);
        verify(memberCoverageApiService).getMemberCoverages(anyString());
    }

    @Test
    public void addExistingProductTest4() throws UnrecoverableMessageException, RecoverableMessageException{
        when(memberCoverageApiService.getMemberCoverages(anyString())).thenReturn(null);
        memberEnrollmentApplication.getMembers().get(0).setTransactionType(MemberTransactionType.TERM);
        service.addExistingProducts(memberEnrollmentApplication);
        verify(memberCoverageApiService).getMemberCoverages(anyString());
    }

    @Test
    public void addExistingProductsTest() throws UnrecoverableMessageException, RecoverableMessageException{
        service.addExistingProducts(null);
        memberEnrollmentApplication.setMembers(null);
        service.addExistingProducts(memberEnrollmentApplication);
        memberEnrollmentApplication.getApplication().setSubscriberId(null);
        service.addExistingProducts(memberEnrollmentApplication);
        assertNull(null);
    }

}
