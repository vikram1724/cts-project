package com.carefirst.nexus.group.enrollment.service;

import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.time.LocalDate;
import java.net.ConnectException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Attribute;
import com.carefirst.nexus.enrollments.gen.model.BenefitStatus;
import com.carefirst.nexus.enrollments.gen.model.Broker;
import com.carefirst.nexus.enrollments.gen.model.CoverageLevel;
import com.carefirst.nexus.enrollments.gen.model.MaritalStatus;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.PCP;
import com.carefirst.nexus.enrollments.gen.model.Phone;
import com.carefirst.nexus.enrollments.gen.model.PhoneType;
import com.carefirst.nexus.enrollments.gen.model.ProductCategory;
import com.carefirst.nexus.enrollments.gen.model.ProductCoverage;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.CoverageInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails;
import com.carefirst.nexus.group.enrollment.helper.MembersProductCoverageRetrieve;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@RunWith(MockitoJUnitRunner.class)
public class EnrollPortalIntegrationServiceTest {

    @InjectMocks
    private EnrollPortalIntegrationService service;

    MemberEnrollmentApplication memberEnrollmentApplication;

    @Mock
    MembersProductCoverageRetrieve membersProductCoverageRetrieve;

    @Before
    public void setUp() throws IOException {
        ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
        memberEnrollmentApplication = mapper.readValue(
                new File("src/test/resources/memberEnrollmentApplication_request.json"),
                MemberEnrollmentApplication.class);
        memberEnrollmentApplication.getApplication().setSubscriberId("123");
    }

    @Test
    public void testEnrollEmpoyeePortal() throws RecoverableMessageException, UnrecoverableMessageException {
        when(membersProductCoverageRetrieve.getCoveragetype(anyList())).thenReturn(CoverageLevel.EMPLOYEE);
        EnrollmentData enrollmentData = service.enrollEmpoyeePortal(memberEnrollmentApplication, "123");
        assertEquals(3, enrollmentData.getPersonalInformation().size());
    }

    @Test
    public void testEnrollEmpoyeePortal1() throws RecoverableMessageException, UnrecoverableMessageException {
        memberEnrollmentApplication.getMembers().get(0).setBenefitStatus(BenefitStatus.COBRA);
        memberEnrollmentApplication.getMembers().get(0).setTransactionType(MemberTransactionType.TERM);
        memberEnrollmentApplication.getMembers().get(1).setTransactionType(MemberTransactionType.REINSTATE);
        memberEnrollmentApplication.getMembers().get(2).setTransactionType(MemberTransactionType.CHANGE);
        when(membersProductCoverageRetrieve.getCoveragetype(anyList())).thenReturn(CoverageLevel.EMPLOYEE);
        EnrollmentData enrollmentData = service.enrollEmpoyeePortal(memberEnrollmentApplication, "123");
        assertEquals(3, enrollmentData.getPersonalInformation().size());
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void testEnrollEmpoyeePortal2() throws RecoverableMessageException, UnrecoverableMessageException {
        memberEnrollmentApplication.setApplication(null);
        service.enrollEmpoyeePortal(memberEnrollmentApplication, "123");
    }

    @Test
    public void testGetBrokerUsingReflection() throws Exception {
        CoverageInformation coverageInformation = new CoverageInformation();
        Broker broker1 = new Broker();
        broker1.setTradingPartnerId("TP1");
        broker1.setTradingPartnerName("Trading Partner 1");
        Broker broker2 = new Broker();
        broker2.setTradingPartnerId("TP2");
        broker2.setTradingPartnerName("Trading Partner 2");
        List<Broker> brokers = Arrays.asList(broker1, broker2);
        EnrollPortalIntegrationService service = new EnrollPortalIntegrationService(null);
        java.lang.reflect.Method getBrokerMethod = EnrollPortalIntegrationService.class.getDeclaredMethod("getBroker",
                CoverageInformation.class, List.class);
        getBrokerMethod.setAccessible(true);
        getBrokerMethod.invoke(service, coverageInformation, brokers);
        assertEquals(2, coverageInformation.getBrokerOrTPADetails().size());
        assertEquals("TP1", coverageInformation.getBrokerOrTPADetails().get(0).getBrokerOrTPACode());
        assertEquals("Trading Partner 1", coverageInformation.getBrokerOrTPADetails().get(0).getBrokerOrTPAName());
    }

    @Test
    public void testGetPcpDetail() throws Exception {
        ProductCoverage mockProductCoverage = mock(ProductCoverage.class);
        ProductDetails mockProductDetails = new ProductDetails();
        when(mockProductCoverage.getPcp()).thenReturn(List.of(mock(PCP.class)));
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("getPcpDetail", ProductDetails.class,
                ProductCoverage.class);
        method.setAccessible(true);
        EnrollPortalIntegrationService service = new EnrollPortalIntegrationService(membersProductCoverageRetrieve);
        method.invoke(service, mockProductDetails, mockProductCoverage);
        assertNotNull(mockProductDetails.getPcpDetails(), "PCP details should be set when PCP list is not empty.");
        when(mockProductCoverage.getPcp()).thenReturn(Collections.emptyList());
        method.invoke(service, mockProductDetails, mockProductCoverage);
    }

    @Test
    public void testGetMaritalStatus() throws Exception {
        Member member = new Member();
        member.setMaritalStatus(MaritalStatus.SINGLE);
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("getMaritalStatus", Member.class);
        method.setAccessible(true);
        String maritalStatus = (String) method.invoke(service, member);
        assertEquals("I", maritalStatus);
        member.setMaritalStatus(MaritalStatus.SEPARATED);
        maritalStatus = (String) method.invoke(service, member);
        assertEquals("S", maritalStatus);
        member.setMaritalStatus(MaritalStatus.MARRIED);
        maritalStatus = (String) method.invoke(service, member);
        assertEquals("M", maritalStatus);
    }

    @Test
    public void testGetRaceOrEthinicityCode() throws Exception {
        Member member = new Member();
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("getRaceOrEthinicityCode", Member.class);
        method.setAccessible(true);
        String raceOrEthinicityCode = (String) method.invoke(service, member);
        assertEquals("7", raceOrEthinicityCode);
    }

    @Test
    public void testFormatDateValue() throws Exception {
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("formatDateValue", LocalDate.class);
        method.setAccessible(true);
        String formattedDate = (String) method.invoke(service, LocalDate.of(2023, 1, 1));
        assertEquals("20230101", formattedDate);
        formattedDate = (String) method.invoke(service, (LocalDate) null);
        assertEquals(null, formattedDate);
    }

    @Test
    public void testGetInsuranceLineCode() throws Exception {
        ProductCoverage productCoverage = new ProductCoverage();
        productCoverage.setProductCategory(ProductCategory.MEDICAL);
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("getInsuranceLineCode",
                ProductCoverage.class);
        method.setAccessible(true);
        String insuranceLineCode = (String) method.invoke(service, productCoverage);
        assertEquals("HLT", insuranceLineCode);
        productCoverage.setProductCategory(ProductCategory.DRUG);
        insuranceLineCode = (String) method.invoke(service, productCoverage);
        assertEquals("PDG", insuranceLineCode);
        productCoverage.setProductCategory(ProductCategory.DENTAL);
        insuranceLineCode = (String) method.invoke(service, productCoverage);
        assertEquals("DEN", insuranceLineCode);
    }

    @Test
    public void testGetCommType() throws Exception {
        Phone phone = new Phone();
        phone.setPhoneType(PhoneType.H);
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("getCommType", Phone.class);
        method.setAccessible(true);
        String commType = (String) method.invoke(service, phone);
        assertEquals("HP", commType);
        phone.setPhoneType(PhoneType.W);
        commType = (String) method.invoke(service, phone);
        assertEquals("WP", commType);
        phone.setPhoneType(PhoneType.C);
        commType = (String) method.invoke(service, phone);
        assertEquals("CP", commType);
    }

    @Test
    public void testEnrollEmpoyeePortalWithAttributes()
            throws RecoverableMessageException, UnrecoverableMessageException {
        Attribute attribute1 = new Attribute();
        attribute1.setName("Attribute1");
        attribute1.setValue("Value1");
        Attribute attribute2 = new Attribute();
        attribute2.setName("Attribute2");
        attribute2.setValue("Value2");
        memberEnrollmentApplication.getApplication().setAttributes(Arrays.asList(attribute1, attribute2));
        when(membersProductCoverageRetrieve.getCoveragetype(anyList())).thenReturn(CoverageLevel.EMPLOYEE);
        EnrollmentData enrollmentData = service.enrollEmpoyeePortal(memberEnrollmentApplication, "123");
        assertEquals(2, enrollmentData.getAttribute().size());
        assertEquals("Attribute1", enrollmentData.getAttribute().get(0).getName());
        assertEquals("Value1", enrollmentData.getAttribute().get(0).getValue());
        assertEquals("Attribute2", enrollmentData.getAttribute().get(1).getName());
        assertEquals("Value2", enrollmentData.getAttribute().get(1).getValue());
    }

    @Test
    public void testHandleException() throws Exception {
        Method method = EnrollPortalIntegrationService.class.getDeclaredMethod("handleException", Exception.class);
        method.setAccessible(true);
        EnrollPortalIntegrationService service = new EnrollPortalIntegrationService(membersProductCoverageRetrieve);
        Exception connectException = new ConnectException("Connection error");
        try {
            method.invoke(service, connectException);
        } catch (InvocationTargetException e) {
            Throwable targetException = e.getTargetException();
            assertTrue(targetException instanceof RecoverableMessageException);
            assertEquals("Connection error", targetException.getMessage());
        }

    }
}
