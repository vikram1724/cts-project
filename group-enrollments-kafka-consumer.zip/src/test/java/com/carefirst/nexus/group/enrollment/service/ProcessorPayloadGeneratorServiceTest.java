package com.carefirst.nexus.group.enrollment.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.group.enrollment.helper.MembersProductCoverageRetrieve;
import com.carefirst.nexus.group.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.group.enrollment.util.AE2ProcessorPayload;
import com.carefirst.nexus.group.enrollment.util.EdifecsProcessorPayload;
import com.carefirst.nexus.groupdetails.gen.model.GroupDetailsResponse;
import jakarta.xml.bind.JAXBException;

@RunWith(MockitoJUnitRunner.class)
public class ProcessorPayloadGeneratorServiceTest {

    @InjectMocks
    ProcessorPayloadGeneratorService service;

    @Mock
    private EdifecsProcessorPayload edifecsProcessorPayload;

    @Mock
    private AE2ProcessorPayload ae2ProcessorPayload;

    @Mock
    private MeberEnrollmetApiService meberEnrollmetApiService;

    @Mock
    private EmpiIntegrationService empiIntegrationService;

    @Mock
    private MembersProductCoverageRetrieve membersProductCoverageRetrieve;

    @Mock
    private GroupDetailsService groupDetailsService;

    @Before
    public void setUp() throws UnrecoverableMessageException, RecoverableMessageException, JAXBException {
        ReflectionTestUtils.setField(service, "edifecs", true);
        when(groupDetailsService.getGroupDetails(any())).thenReturn(new GroupDetailsResponse());
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void generateProcessorPaylodTest() throws RecoverableMessageException, UnrecoverableMessageException {
        service.generateProcessorPaylod(new TransactionListenerPayload());
    }

    @Test
    public void generateProcessorPaylodTest1()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("test");
        service.generateProcessorPaylod(payload);
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setStatus("DRAFT");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
        payload.setSubmitterApplicationId(null);
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(3)).generateEdifecsProcessorPayload(any(), any());
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void generateProcessorPaylodTest2() throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterPayload(null);
        service.generateProcessorPaylod(payload);
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void generateProcessorPaylodTest3() throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterPayload("");
        service.generateProcessorPaylod(payload);
    }

    @Test
    public void generateProcessorPaylodTest4()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest5()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest6()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
    }

    @Test(expected = RecoverableMessageException.class)
    public void generateProcessorPaylodTest7() throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        payload.setSubmitterPayload("invalid payload");
        service.generateProcessorPaylod(payload);
    }

    @Test
    public void generateProcessorPaylodTest8()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
    }

    @Test
    public void generateProcessorPaylodTest9()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setStatus("SUBMITTED");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest10()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setSubmitterApplicationId("456");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest11()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("789");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setStatus("NOT_SUBMITTED");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest12()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("101112");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setSubmitterApplicationId("131415");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest13()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("161718");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setStatus("COMPLETED");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
    }

    @Test
    public void generateProcessorPaylodTest14()
            throws RecoverableMessageException, IOException, UnrecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("192021");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(edifecsProcessorPayload.generateEdifecsProcessorPayload(any(), any())).thenReturn("formattedData");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload).generateEdifecsProcessorPayload(any(), any());
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setSubmitterApplicationId("222324");
        service.generateProcessorPaylod(payload);
        verify(edifecsProcessorPayload, atLeast(2)).generateEdifecsProcessorPayload(any(), any());
    }

}