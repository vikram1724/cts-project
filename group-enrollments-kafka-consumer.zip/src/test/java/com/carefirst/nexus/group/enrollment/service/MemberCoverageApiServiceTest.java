package com.carefirst.nexus.group.enrollment.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.group.enrollment.service.MemberCoverageApiService;
import com.carefirst.nexus.membercoverage.gen.api.MemberCoverageBaseApi;
import com.carefirst.nexus.membercoverage.gen.model.MemberCoveragesResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.class)
class MemberCoverageApiServiceTest {

    @Mock
    private MemberCoverageBaseApi memberCoverageBaseApi;

    @InjectMocks
    private MemberCoverageApiService memberCoverageApiService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetMemberCoverages_Success() throws UnrecoverableMessageException, RecoverableMessageException {
        String subscriberId = "12345";
        MemberCoveragesResponse mockResponse = new MemberCoveragesResponse();
        when(memberCoverageBaseApi.getMemberCoverages(
                any(), eq(subscriberId), any(), any(), any(), any(), any(), 
                any(), any(), any(), any(), any(), any(), any()
        )).thenReturn(Mono.just(mockResponse));
        MemberCoveragesResponse response = memberCoverageApiService.getMemberCoverages(subscriberId);
        assertNotNull(response, "Response should not be null");
        verify(memberCoverageBaseApi, times(1)).getMemberCoverages(
                any(), eq(subscriberId), any(), any(), any(), any(), any(), 
                any(), any(), any(), any(), any(), any(), any()
        );
    }

    @Test
    void testGetMemberCoverages_ThrowsUnrecoverableMessageException() {
       
        String subscriberId = "12345";
        when(memberCoverageBaseApi.getMemberCoverages(
                any(), eq(subscriberId), any(), any(), any(), any(), any(), 
                any(), any(), any(), any(), any(), any(), any()
        )).thenThrow(new RuntimeException("Simulated exception"));
        RecoverableMessageException exception = assertThrows(
                RecoverableMessageException.class,
                () -> memberCoverageApiService.getMemberCoverages(subscriberId),
                "Expected UnrecoverableMessageException to be thrown"
        );
        assertNotNull(exception.getMessage(), "Exception message should not be null");
        verify(memberCoverageBaseApi, times(1)).getMemberCoverages(
                any(), eq(subscriberId), any(), any(), any(), any(), any(), 
                any(), any(), any(), any(), any(), any(), any()
        );
    }

    //@Test
    void testGetMemberCoverages_NullResponse() throws UnrecoverableMessageException, RecoverableMessageException {
        String subscriberId = "12345";
        when(memberCoverageBaseApi.getMemberCoverages(
                any(), eq(subscriberId), any(), any(), any(), any(), any(), 
                any(), any(), any(), any(), any(), any(), any()
        )).thenReturn(Mono.empty());
        MemberCoveragesResponse response = memberCoverageApiService.getMemberCoverages(subscriberId);
        assertNotNull(response, "Response should be null when API returns empty");
        verify(memberCoverageBaseApi, times(1)).getMemberCoverages(
                any(), eq(subscriberId), any(), any(), any(), any(), any(), 
                any(), any(), any(), any(), any(), any(), any()
        );
    }
}