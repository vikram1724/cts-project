package com.carefirst.nexus.group.enrollment.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.group.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.utils.web.error.AppJSONException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EnrollmentTransactionProcessServiceTest {

    @InjectMocks
    EnrollmentTransactionProcessService service;

    @Mock
    ProcessorPayloadGeneratorService processorPayloadGeneratorService;

    @Test
    public void processPayloadTest() throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        transactionListenerPayload.setSubmitterApplicationId("1234");
        service.processPayload(transactionListenerPayload);
        verify(processorPayloadGeneratorService).generateProcessorPaylod(transactionListenerPayload);
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void processPayloadTest1() throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        service.processPayload(transactionListenerPayload);
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void processPayloadTest2() throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        transactionListenerPayload.setSubmitterApplicationId("");
        service.processPayload(transactionListenerPayload);
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void processPayloadTestWithAppJSONException()
            throws RecoverableMessageException, UnrecoverableMessageException {
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        transactionListenerPayload.setSubmitterApplicationId("1234");
        when(processorPayloadGeneratorService.generateProcessorPaylod(any()))
                .thenThrow(new AppJSONException("JSON error"));
        service.processPayload(transactionListenerPayload);
    }

}
