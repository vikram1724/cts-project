package com.carefirst.nexus.group.enrollment.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.enrollments.gen.model.Address;
import com.carefirst.nexus.enrollments.gen.model.Application;
import com.carefirst.nexus.enrollments.gen.model.COB;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Contact;
import com.carefirst.nexus.enrollments.gen.model.Email;
import com.carefirst.nexus.enrollments.gen.model.Gender;
import com.carefirst.nexus.enrollments.gen.model.Group;
import com.carefirst.nexus.enrollments.gen.model.MaritalStatus;
import com.carefirst.nexus.enrollments.gen.model.Medicare;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.Name;
import com.carefirst.nexus.enrollments.gen.model.OtherInfo;
import com.carefirst.nexus.enrollments.gen.model.PCP;
import com.carefirst.nexus.enrollments.gen.model.Phone;
import com.carefirst.nexus.enrollments.gen.model.PhoneType;
import com.carefirst.nexus.enrollments.gen.model.ProductCategory;
import com.carefirst.nexus.enrollments.gen.model.ProductCoverage;
import com.carefirst.nexus.enrollments.gen.model.RelationshipCode;
import com.carefirst.nexus.group.enrollment.constants.EnrollmentConstants;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.AccountHeader;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.AccountTrailer;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.DisabilityDataLg;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.EmployeeSpecificDataLg;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.FileHeader;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.FileTrailer;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.ProcessorPayload1;
import com.carefirst.nexus.group.enrollment.edifecsfilemodel.TefraInformationLg;

@RunWith(MockitoJUnitRunner.class)
public class Custom1350LayoutGeneratorTest {

    @InjectMocks
    private Custom1350LayoutGenerator custom1350LayoutGenerator;

    @Mock
    private EnrollmentUtil enrollmentUtil;

    @Test
    public void testFormatEmplyeeTransactionData() {
        FileHeader fileHeader = new FileHeader();
        AccountHeader accountHeader = new AccountHeader();
        List<EmployeeTransactionData> employeeTransactionDatas = new ArrayList<>();
        AccountTrailer accountTrailer = new AccountTrailer();
        FileTrailer fileTrailer = new FileTrailer();
        ProcessorPayload1 processorPayload = new ProcessorPayload1();
        processorPayload.setFileHeader(fileHeader);
        processorPayload.setAccountHeader(accountHeader);
        processorPayload.setEmployeeTransactionDatas(employeeTransactionDatas);
        processorPayload.setAccountTrailer(accountTrailer);
        processorPayload.setFileTrailer(fileTrailer);
        String result = custom1350LayoutGenerator.formatEmplyeeTransactionData(processorPayload);
        assertNotNull(result);
    }

    @Test
    public void testGetFileHeaderData() {
        FileHeader fileHeader = new FileHeader();
        StringBuilder result = custom1350LayoutGenerator.getFileHeaderData(fileHeader);
        assertNotNull(result);
    }

    @Test
    public void testGetFileTrailer() {
        FileTrailer fileTrailer = new FileTrailer();
        StringBuilder result = custom1350LayoutGenerator.getFileTrailer(fileTrailer);
        assertNotNull(result);
    }

    @Test
    public void testGetAccountTrailer() {
        AccountTrailer accountTrailer = new AccountTrailer();
        Object result = custom1350LayoutGenerator.getAccountTrailer(accountTrailer);
        assertNotNull(result);
    }

    @Test
    public void testGetDetailRecord() {
        List<EmployeeTransactionData> employeeTransactionDatas = new ArrayList<>();
        StringBuilder result = custom1350LayoutGenerator.getDetailRecord(employeeTransactionDatas);
        assertNotNull(result);
    }

    @Test
    public void testMemberIterator() {
        List<Member> members = new ArrayList<>();
        StringBuilder detailRecord = new StringBuilder();
        custom1350LayoutGenerator.memberIterator(detailRecord, new EmployeeTransactionData(), members, "123-45-6789");
        // Add assertions to verify the result
    }

    @Test
    public void testMemberSsnAndLnameAndFnameAndMiAndSuffix() {
        Member member = new Member().name(new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr"));
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.memberSsnAndLnameAndFnameAndMiAndSuffix(member, keyDemographicDataStr, "123-45-6789");
        // Add assertions to verify the result
    }

    @Test
    public void testMemberDobAndSeAndRc() {
        Member member = new Member();
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.memberDobAndSeAndRc(member, keyDemographicDataStr);
        // Add assertions to verify the result
    }

    @Test
    public void testSetRelationShipCode() {
        Member member = new Member();
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        // Add assertions to verify the result
    }

    @Test
    public void testGetOtherInsuranceData() {
        Member member = new Member().contact(new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890"))));
        String result = custom1350LayoutGenerator.getOtherInsuranceData(member);
        assertNotNull(result);
    }

    @Test
    public void testGetOtherInsuranceData_presentCobs() {
        Member member = new Member().contact(new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890"))));
        member.cobs(
                Arrays.asList(new com.carefirst.nexus.enrollments.gen.model.COB().otherInsuranceIndicator(Choice.Yes)));
        String result = custom1350LayoutGenerator.getOtherInsuranceData(member);
        assertNotNull(result);
    }

    @Test
    public void testGetTefraInformationData() {
        TefraInformationLg tefraInformationLg = new TefraInformationLg();
        String result = custom1350LayoutGenerator.getTefraInformationData(tefraInformationLg);
        assertNotNull(result);
    }

    @Test
    public void testGetStudentData() {
        Member member = new Member().contact(new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890"))));
        String result = custom1350LayoutGenerator.getStudentData(member);
        assertNotNull(result);
    }

    @Test
    public void testGetStudentData_emailNull() {
        Member member = new Member().contact(new Contact());
        String result = custom1350LayoutGenerator.getStudentData(member);
        assertNotNull(result);
    }

    @Test
    public void testGetDisabilityData() {
        Member disabilityData = new Member();
        String result = custom1350LayoutGenerator.getDisabilityData(disabilityData);
        assertNotNull(result);
    }

    @Test
    public void testGetDisabilityData_AllFieldsPresent() {
        Member disabilityData = new Member();
       // disabilityData.setDisabilityEffectiveDate("2023-10-10");
        String result = custom1350LayoutGenerator.getDisabilityData(disabilityData);
        assertNotNull(result);
    }

    @Test
    public void testGetMedicareInsuranceInfo() {
        Member member = new Member();
        String result = custom1350LayoutGenerator.getMedicareInsuranceInfo(member);
        assertNotNull(result);
    }

    @Test
    public void testGetMedicareInsuranceInfo_AllFieldsPresent() {
        Member member = new Member().addMedicareItem(new Medicare());
        String result = custom1350LayoutGenerator.getMedicareInsuranceInfo(member);
        assertNotNull(result);
    }

    @Test
    public void testSetMedicareEligibilityIndicator() {
        Medicare medicareInsuranceInfo = new Medicare();
        String result = custom1350LayoutGenerator.setMedicareEligibilityIndicator(medicareInsuranceInfo);
        assertNotNull(result);
    }

    @Test
    public void testMedicareAAndBDatesandHICNumAndEligibiltyIndDetails() {
        StringBuilder medicareInsuranceInfostr = new StringBuilder();
        Medicare medicareInsuranceInfo = new Medicare();
        custom1350LayoutGenerator.medicareAAndBDatesandHICNumAndEligibiltyIndDetails(medicareInsuranceInfostr,
                medicareInsuranceInfo, "9");
        // Add assertions to verify the result
    }

    @Test
    public void testMedicareAAndBDatesandHICNumAndEligibiltyIndDetails_medicareEligibilityIndicatorEmpty() {
        StringBuilder medicareInsuranceInfostr = new StringBuilder();
        Medicare medicareInsuranceInfo = new Medicare();
        custom1350LayoutGenerator.medicareAAndBDatesandHICNumAndEligibiltyIndDetails(medicareInsuranceInfostr,
                medicareInsuranceInfo, "");
        // Add assertions to verify the result
    }

    @Test
    public void testMediInfo() {
        StringBuilder medicareInsuranceInfostr = new StringBuilder();
        Medicare medicareInsuranceInfo = new Medicare();
        Member member = new Member();
        custom1350LayoutGenerator.mediInfo(medicareInsuranceInfo, medicareInsuranceInfostr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testMediInfo_AllFieldsPresent() {
        StringBuilder medicareInsuranceInfostr = new StringBuilder();
        Medicare medicareInsuranceInfo = new Medicare().hasPartB(Choice.Yes).medicareEfftiveEndDate("2023-10-10")
                .partBEntitlementDate(LocalDate.of(2023, 10, 10));
        Member member = new Member();
        custom1350LayoutGenerator.mediInfo(medicareInsuranceInfo, medicareInsuranceInfostr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testGetOtherInsuranceinfomationData() {
        Member member = new Member();
        String result = custom1350LayoutGenerator.getOtherInsuranceinfomationData(member);
        assertNotNull(result);
    }

    @Test
    public void testGetOtherInsuranceinfomationData_AllFieldsPresent() {
        OtherInfo otherInfo = new OtherInfo().insuranceCompanyName("ABC").effectiveDate("2023-10-10")
                .terminationDate("2023-10-10").employerName("XYZ")
                .policyholderName(new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr"));
        COB cobsItem = new COB().otherInfo(Arrays.asList(otherInfo));
        Member member = new Member().addCobsItem(cobsItem).memberEntityId("12345");
        String result = custom1350LayoutGenerator.getOtherInsuranceinfomationData(member);
        assertNotNull(result);
    }

    @Test
    public void testGetOtherInsuranceInformationInnner() {
        StringBuilder otherInsuranceInfomationStr = new StringBuilder();
        OtherInfo otherInsuranceInfomation = new OtherInfo();
        custom1350LayoutGenerator.getOtherInsuranceInformationInnner(otherInsuranceInfomationStr,
                otherInsuranceInfomation);
        // Add assertions to verify the result
    }

    @Test
    public void testFormatDateString() {
        String result = custom1350LayoutGenerator.formatDateString("2023-10-10");
        assertEquals("10102023", result);
    }

    @Test
    public void testFormatDateString_Exception() {
        String result = custom1350LayoutGenerator.formatDateString("10102023");
        assertEquals("10102023", result);
    }

    @Test
    public void testFormatDateValue() {
        String result = custom1350LayoutGenerator.formatDateValue(LocalDate.of(2023, 10, 10));
        assertEquals("10102023", result);
    }

    @Test
    public void testOtherInsurancInfo() {
        OtherInfo otherInsuranceInfomation = new OtherInfo();
        StringBuilder otherInsuranceInfomationStr = new StringBuilder();
        Member member = new Member();
        custom1350LayoutGenerator.otherInsurancInfo(otherInsuranceInfomation, otherInsuranceInfomationStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testOtherInsurancInfo_AllFieldsPresent() {
        OtherInfo otherInsuranceInfomation = new OtherInfo().policyholderId("12345").policyholderNumber("12345")
                .insuranceCompanyName("ABC")
                .effectiveDate("2023-10-10").terminationDate("2023-10-10").employerName("XYZ")
                .policyholderName(new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr"));
        StringBuilder otherInsuranceInfomationStr = new StringBuilder();
        Member member = new Member().dateOfBirth("2023-10-10");
        custom1350LayoutGenerator.otherInsurancInfo(otherInsuranceInfomation, otherInsuranceInfomationStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testGetPolicyHolderName() {
        OtherInfo otherInsuranceInfomation = new OtherInfo()
                .policyholderName(new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr"));
        StringBuilder fullName = new StringBuilder();
        custom1350LayoutGenerator.getPolicyHolderName(otherInsuranceInfomation, fullName);
        // Add assertions to verify the result
    }

    @Test
    public void testGetProductChoices() {
        Member member = new Member();
        Application application = new Application();
        String result = custom1350LayoutGenerator.getProductChoices(member, application);
        assertNotNull(result);
    }

    @Test
    public void testGetVisionProductData() {
        Member member = new Member();
        Application application = new Application();
        String result = custom1350LayoutGenerator.getVisionProductData(Map.of(), member, application);
        assertNotNull(result);
    }

    @Test
    public void testGetVisionProductData_AllFieldsPresent() {
        Member member = new Member().subGroupId("12345").transactionType(MemberTransactionType.TERM);
        Application application = new Application().group(new Group().groupId("12345"));
        Map<ProductCategory, List<ProductCoverage>> mapProductCoverages = Map.of(ProductCategory.VISION,
                Arrays.asList(new ProductCoverage().productId("12345").classId("12345").coverageLevel(null)
                        .effectiveDate(LocalDate.of(2023, 10, 10)).terminationDate(LocalDate.of(2023, 10, 10))
                        .productCategory(ProductCategory.VISION).addPcpItem(new PCP().providerId("12345").providerName(
                                new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")))));

        when(enrollmentUtil.getCoverageLevelByCoverageType(any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);

        String result = custom1350LayoutGenerator.getVisionProductData(mapProductCoverages, member, application);
        assertNotNull(result);
    }

    @Test
    public void testVisionProdData() {
        ProductCoverage visionProductCoverage = new ProductCoverage();
        StringBuilder visionProductDataLgStr = new StringBuilder();
        Member member = new Member();
        custom1350LayoutGenerator.visionProdData(visionProductCoverage, visionProductDataLgStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testGetDentalProductData() {
        Member member = new Member();
        Application application = new Application();
        String result = custom1350LayoutGenerator.getDentalProductData(Map.of(), member, application);
        assertNotNull(result);
    }

    @Test
    public void testGetDentalProductData_AllFieldsPresent() {
        Member member = new Member().subGroupId("12345").transactionType(MemberTransactionType.TERM);
        Application application = new Application().group(new Group().groupId("12345"));
        Map<ProductCategory, List<ProductCoverage>> mapProductCoverages = Map.of(ProductCategory.DENTAL,
                Arrays.asList(new ProductCoverage().productId("12345").classId("12345").coverageLevel(null)
                        .effectiveDate(LocalDate.of(2023, 10, 10)).terminationDate(LocalDate.of(2023, 10, 10))
                        .productCategory(ProductCategory.DENTAL).addPcpItem(new PCP().providerId("12345").providerName(
                                new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")))));

        when(enrollmentUtil.getCoverageLevelByCoverageType(any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);

        String result = custom1350LayoutGenerator.getDentalProductData(mapProductCoverages, member, application);
        assertNotNull(result);
    }

    @Test
    public void testDentalProdData() {
        ProductCoverage dentalProductCoverage = new ProductCoverage();
        StringBuilder dentalProductDataEgwpStr = new StringBuilder();
        Member member = new Member();
        custom1350LayoutGenerator.dentalProdData(dentalProductCoverage, dentalProductDataEgwpStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testDentalProd() {
        ProductCoverage dentalProductCoverage = new ProductCoverage();
        StringBuilder dentalProductDataEgwpStr = new StringBuilder();
        Member member = new Member();
        custom1350LayoutGenerator.dentalProd(dentalProductCoverage, dentalProductDataEgwpStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testGetPcpProviderName() {
        ProductCoverage dentalProductCoverage = new ProductCoverage().addPcpItem(
                new PCP().providerName(new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")));
        StringBuilder fullName = new StringBuilder();
        custom1350LayoutGenerator.getPcpProviderName(dentalProductCoverage, fullName);
        // Add assertions to verify the result
    }

    @Test
    public void testGetDrugProductDataLg() {
        Member member = new Member();
        Application application = new Application();
        String result = custom1350LayoutGenerator.getDrugProductDataLg(Map.of(), member, application);
        assertNotNull(result);
    }

    @Test
    public void testGetDrugProductDataLg_AllFieldsPresent() {
        Member member = new Member().subGroupId("12345").transactionType(MemberTransactionType.TERM);
        Application application = new Application().group(new Group().groupId("12345"));
        Map<ProductCategory, List<ProductCoverage>> mapProductCoverages = Map.of(ProductCategory.DRUG,
                Arrays.asList(new ProductCoverage().productId("12345").classId("12345").coverageLevel(null)
                        .effectiveDate(LocalDate.of(2023, 10, 10)).terminationDate(LocalDate.of(2023, 10, 10))
                        .productCategory(ProductCategory.DRUG).addPcpItem(new PCP().providerId("12345").providerName(
                                new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")))));

        when(enrollmentUtil.getCoverageLevelByCoverageType(any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);

        String result = custom1350LayoutGenerator.getDrugProductDataLg(mapProductCoverages, member, application);
        assertNotNull(result);
    }

    @Test
    public void testDrugProdData() {
        ProductCoverage drugProductCoverage = new ProductCoverage().productId("12345");
        StringBuilder drugProductDataLgStr = new StringBuilder();
        Member member = new Member();
        custom1350LayoutGenerator.drugProdData(drugProductCoverage, drugProductDataLgStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testGetPcpSelectionData() {
        String result = custom1350LayoutGenerator.getPcpSelectionData(Map.of());
        assertNotNull(result);
    }

    @Test
    public void testGetPcpSelectionData_AllFieldsPresent() {
        Map<ProductCategory, List<ProductCoverage>> mapProductCoverages = Map.of(ProductCategory.MEDICAL,
                Arrays.asList(new ProductCoverage().productId("12345").classId("12345").coverageLevel(null)
                        .effectiveDate(LocalDate.of(2023, 10, 10)).terminationDate(LocalDate.of(2023, 10, 10))
                        .addPcpItem(new PCP().providerId("12345").effectiveDate(LocalDate.of(2023, 10, 10))
                                .terminationDate(LocalDate.of(2023, 10, 10)).providerName(
                                        new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")))));

        String result = custom1350LayoutGenerator.getPcpSelectionData(mapProductCoverages);
        assertNotNull(result);
    }

    @Test
    public void testGetPcpSelectionData_providerIdIsTEMP() {
        Map<ProductCategory, List<ProductCoverage>> mapProductCoverages = Map.of(ProductCategory.MEDICAL,
                Arrays.asList(new ProductCoverage().productId("12345").classId("12345").coverageLevel(null)
                        .effectiveDate(LocalDate.of(2023, 10, 10)).terminationDate(LocalDate.of(2023, 10, 10))
                        .addPcpItem(new PCP().providerId("TEMP").effectiveDate(LocalDate.of(2023, 10, 10))
                                .terminationDate(LocalDate.of(2023, 10, 10)).providerName(
                                        new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")))));

        String result = custom1350LayoutGenerator.getPcpSelectionData(mapProductCoverages);
        assertNotNull(result);
    }

    @Test
    public void testPcpData() {
        PCP medicalPcp = new PCP();
        StringBuilder pcpSelectionDataStr = new StringBuilder();
        custom1350LayoutGenerator.pcpData(medicalPcp, pcpSelectionDataStr);
        // Add assertions to verify the result
    }

    @Test
    public void testGetMedicalCoverageDataLg() {
        Member member = new Member();
        Application application = new Application();
        String result = custom1350LayoutGenerator.getMedicalCoverageDataLg(Map.of(), member, application);
        assertNotNull(result);
    }

    @Test
    public void testGetMedicalCoverageDataLg_AllFieldsPresent() {
        Member member = new Member().subGroupId("12345").transactionType(MemberTransactionType.TERM);
        Application application = new Application().group(new Group().groupId("12345"));
        Map<ProductCategory, List<ProductCoverage>> mapProductCoverages = Map.of(ProductCategory.MEDICAL,
                Arrays.asList(new ProductCoverage().productId("12345").classId("12345").coverageLevel(null)
                        .effectiveDate(LocalDate.of(2023, 10, 10)).terminationDate(LocalDate.of(2023, 10, 10))
                        .addPcpItem(new PCP().providerId("12345").providerName(
                                new Name().firstName("fn").lastName("ln").middleName("mn").suffix("Jr")))));

        when(enrollmentUtil.getCoverageLevelByCoverageType(any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);

        String result = custom1350LayoutGenerator.getMedicalCoverageDataLg(mapProductCoverages, member, application);
        assertNotNull(result);
    }

    @Test
    public void testMedicalCoverage() {
        ProductCoverage medicalProductCoverage = new ProductCoverage().productId("12345");
        ;
        StringBuilder medicalCoverageDataEgwpStr = new StringBuilder();
        Member member = new Member();
        custom1350LayoutGenerator.medicalCoverage(medicalProductCoverage, medicalCoverageDataEgwpStr, member);
        // Add assertions to verify the result
    }

    @Test
    public void testMediCvrgData() {
        ProductCoverage medicalProductCoverage = new ProductCoverage().productId("");
        StringBuilder medicalCoverageDataEgwpStr = new StringBuilder();
        custom1350LayoutGenerator.mediCvrgData(medicalProductCoverage, medicalCoverageDataEgwpStr);
        // Add assertions to verify the result
    }

    @Test
    public void testGetAdditionalMemberInformation() {
        Member member = new Member();
        String result = custom1350LayoutGenerator.getAdditionalMemberInformation(member);
        assertNotNull(result);
    }

    @Test
    public void testGetAdditionalMemberInformation_AllFieldsPresent() {
        Address address = new Address().line1("12345").line2("12345").city("city").state("state")
                .zipCode("12345").isPrimary(Choice.Yes).stateCode("SC").countryCode("CC");
        Contact contact = new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890").phoneType(PhoneType.H),
                        new Phone().phoneNumber("9876543210").phoneType(PhoneType.W)));
        Member member = new Member().addAddressItem(address).socialSecurityNumber("123-45-678").contact(contact)
                .subscriberInd(Choice.Yes);
        String result = custom1350LayoutGenerator.getAdditionalMemberInformation(member);
        assertNotNull(result);
    }

    @Test
    public void testGetAdditionalMemberInformation_ifEmpty() {
        Address address = new Address().line1("12345").line2("12345").city("").state("state")
                .zipCode("12345").isPrimary(Choice.Yes).stateCode("").countryCode("CC");
        Contact contact = new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890").phoneType(PhoneType.H),
                        new Phone().phoneNumber("9876543210").phoneType(PhoneType.W)));
        Member member = new Member().addAddressItem(address).socialSecurityNumber("123-45-678").contact(contact)
                .subscriberInd(Choice.Yes);
        String result = custom1350LayoutGenerator.getAdditionalMemberInformation(member);
        assertNotNull(result);
    }

    @Test
    public void testSetAddressLine1AndLine2() {
        Address address = new Address();
        StringBuilder additionalMemberInformationStr = new StringBuilder();
        custom1350LayoutGenerator.setAddressLine1AndLine2(additionalMemberInformationStr, address);
        // Add assertions to verify the result
    }

    @Test
    public void testAdditionalMembInfo() {
        Member member = new Member()
                .contact(new com.carefirst.nexus.enrollments.gen.model.Contact().phone(Arrays.asList(new Phone())));
        Address address = new Address();
        StringBuilder additionalMemberInformationStr = new StringBuilder();
        custom1350LayoutGenerator.additionalMembInfo(member, additionalMemberInformationStr, address);
        // Add assertions to verify the result
    }

    @Test
    public void testSetMemberContactPhone() {
        Member member = new Member();
        StringBuilder additionalMemberInformationStr = new StringBuilder();
        Phone homePhone = new Phone();
        Phone workPhone = new Phone();
        custom1350LayoutGenerator.setMemberContactPhone(member, additionalMemberInformationStr, homePhone, workPhone);
        // Add assertions to verify the result
    }

    @Test
    public void testGetEmployeeSpecificData() {
        EmployeeSpecificDataLg employeeSpecificData = new EmployeeSpecificDataLg();
        MaritalStatus maritalStatus = MaritalStatus.SINGLE;
        String result = custom1350LayoutGenerator.getEmployeeSpecificData(employeeSpecificData, maritalStatus);
        assertNotNull(result);
    }

    @Test
    public void testGetEmployeeSpecificData_AllFieldsPresent() {
        EmployeeSpecificDataLg employeeSpecificData = new EmployeeSpecificDataLg();
        employeeSpecificData.setEmployeeNumber("12345");
        employeeSpecificData.setEmployeeLocation("location");
        employeeSpecificData.setEmployeeSalaryAmount("1000");
        employeeSpecificData.setEmployeeSalaryEffectiveDate("2023-10-10");
        employeeSpecificData.setEmploymentHireDate("2023-10-10");
        employeeSpecificData.setMarriageDate("2023-10-10");

        MaritalStatus maritalStatus = MaritalStatus.SINGLE;
        String result = custom1350LayoutGenerator.getEmployeeSpecificData(employeeSpecificData, maritalStatus);
        assertNotNull(result);
    }

    @Test
    public void testGetMartialStatus() {
        MaritalStatus maritalStatus = MaritalStatus.SINGLE;
        String result = custom1350LayoutGenerator.getMartialStatus(maritalStatus);
        assertEquals("S", result);
    }

    @Test
    public void testGetMartialStatus_MARRIED() {
        MaritalStatus maritalStatus = MaritalStatus.MARRIED;
        String result = custom1350LayoutGenerator.getMartialStatus(maritalStatus);
        assertEquals("M", result);
    }

    @Test
    public void testGetMartialStatus_DIVORCED() {
        MaritalStatus maritalStatus = MaritalStatus.DIVORCED;
        String result = custom1350LayoutGenerator.getMartialStatus(maritalStatus);
        assertEquals("D", result);
    }

    @Test
    public void testGetMartialStatus_LEGALLYSEPARATED() {
        MaritalStatus maritalStatus = MaritalStatus.LEGALLYSEPARATED;
        String result = custom1350LayoutGenerator.getMartialStatus(maritalStatus);
        assertEquals("X", result);
    }

    @Test
    public void testGetMartialStatus_WIDOWER() {
        MaritalStatus maritalStatus = MaritalStatus.WIDOWER;
        String result = custom1350LayoutGenerator.getMartialStatus(maritalStatus);
        assertEquals("W", result);
    }

    @Test
    public void testGetMartialStatus_null() {
        String result = custom1350LayoutGenerator.getMartialStatus(null);
        assertEquals("U", result);
    }

    @Test
    public void testEmpSpecData() {
        EmployeeSpecificDataLg employeeSpecificData = new EmployeeSpecificDataLg();
        StringBuilder employeeSpecificDataStr = new StringBuilder();
        MaritalStatus maritalStatus = MaritalStatus.SINGLE;
        custom1350LayoutGenerator.empSpecData(employeeSpecificData, employeeSpecificDataStr, maritalStatus);
        // Add assertions to verify the result
    }

    @Test
    public void testGetAccountHeaderData() {
        AccountHeader accountHeader = new AccountHeader();
        StringBuilder result = custom1350LayoutGenerator.getAccountHeaderData(accountHeader);
        assertNotNull(result);
    }

    @Test
    public void testGetAccountHeaderData_AllFieldsPresent() {
        AccountHeader accountHeader = new AccountHeader();
        accountHeader.setFileType("FT");
        accountHeader.setRecordType("RT");
        accountHeader.setCompanyName("CN");
        accountHeader.setUniqueCoIdentifierFedTaxId("12345");
        accountHeader.setContactName("CN");
        accountHeader.setContactTelephoneNumber("123456789");
        accountHeader.setDateFileSubmitted("2023-10-10");
        accountHeader.setMemberTermDateDefault("2023-10-10");
        accountHeader.setSalesPersonNumber("12345");
        accountHeader.setPcpIndicator("Y");
        accountHeader.setResubmittedFileIndicator("Y");
        accountHeader.setResubmittedFileOriginalDate("2023-10-10");

        StringBuilder result = custom1350LayoutGenerator.getAccountHeaderData(accountHeader);
        assertNotNull(result);
    }

    @Test
    public void testAccntHdr1() {
        StringBuilder fileHeaderBuffer = new StringBuilder();
        AccountHeader accountHeader = new AccountHeader();
        custom1350LayoutGenerator.accntHdr1(accountHeader, fileHeaderBuffer);
        // Add assertions to verify the result
    }

    @Test
    public void testAccntHdr2() {
        StringBuilder fileHeaderBuffer = new StringBuilder();
        AccountHeader accountHeader = new AccountHeader();
        custom1350LayoutGenerator.accntHdr2(accountHeader, fileHeaderBuffer);
        // Add assertions to verify the result
    }

    @Test
    public void testGetFileHeaderData_AllFieldsPresent() {
        FileHeader fileHeader = new FileHeader();
        fileHeader.setRecordType("RT");
        fileHeader.setCreatedDate("2023-10-10");
        fileHeader.setSourceId("SID");
        fileHeader.setSubmitterRole("SR");

        StringBuilder result = custom1350LayoutGenerator.getFileHeaderData(fileHeader);

        assertNotNull(result);
    }

    @Test
    public void testGetFileHeaderData_MissingRecordType() {
        FileHeader fileHeader = new FileHeader();
        fileHeader.setCreatedDate("2023-10-10");
        fileHeader.setSourceId("SID");
        fileHeader.setSubmitterRole("SR");

        StringBuilder result = custom1350LayoutGenerator.getFileHeaderData(fileHeader);

        assertNotNull(result);
    }

    @Test
    public void testGetFileHeaderData_MissingCreatedDate() {
        FileHeader fileHeader = new FileHeader();
        fileHeader.setRecordType("RT");
        fileHeader.setSourceId("SID");
        fileHeader.setSubmitterRole("SR");

        StringBuilder result = custom1350LayoutGenerator.getFileHeaderData(fileHeader);

        assertNotNull(result);
    }

    @Test
    public void testGetFileHeaderData_MissingSourceId() {
        FileHeader fileHeader = new FileHeader();
        fileHeader.setRecordType("RT");
        fileHeader.setCreatedDate("2023-10-10");
        fileHeader.setSubmitterRole("SR");

        StringBuilder result = custom1350LayoutGenerator.getFileHeaderData(fileHeader);

        assertNotNull(result);
    }

    @Test
    public void testGetFileHeaderData_MissingSubmitterRole() {
        FileHeader fileHeader = new FileHeader();
        fileHeader.setRecordType("RT");
        fileHeader.setCreatedDate("2023-10-10");
        fileHeader.setSourceId("SID");

        StringBuilder result = custom1350LayoutGenerator.getFileHeaderData(fileHeader);

        assertNotNull(result);
    }

    @Test
    public void testGetFileTrailer_AllFieldsPresent() {
        FileTrailer fileTrailer = new FileTrailer();
        fileTrailer.setRecordType("RT");
        fileTrailer.setTotalAccountorGroupCount("10");
        fileTrailer.setTotalrecordCount("100");

        StringBuilder result = custom1350LayoutGenerator.getFileTrailer(fileTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetFileTrailer_MissingRecordType() {
        FileTrailer fileTrailer = new FileTrailer();
        fileTrailer.setTotalAccountorGroupCount("10");
        fileTrailer.setTotalrecordCount("100");

        StringBuilder result = custom1350LayoutGenerator.getFileTrailer(fileTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetFileTrailer_MissingTotalAccountorGroupCount() {
        FileTrailer fileTrailer = new FileTrailer();
        fileTrailer.setRecordType("RT");
        fileTrailer.setTotalrecordCount("100");

        StringBuilder result = custom1350LayoutGenerator.getFileTrailer(fileTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetFileTrailer_MissingTotalrecordCount() {
        FileTrailer fileTrailer = new FileTrailer();
        fileTrailer.setRecordType("RT");
        fileTrailer.setTotalAccountorGroupCount("10");

        StringBuilder result = custom1350LayoutGenerator.getFileTrailer(fileTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetFileTrailer_AllFieldsMissing() {
        FileTrailer fileTrailer = new FileTrailer();

        StringBuilder result = custom1350LayoutGenerator.getFileTrailer(fileTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetAccountTrailer_AllFieldsPresent() {
        AccountTrailer accountTrailer = new AccountTrailer();
        accountTrailer.setRecordType("RT");
        accountTrailer.setFileType("FT");
        accountTrailer.setDetailEmployeeRecordCount("100");

        Object result = custom1350LayoutGenerator.getAccountTrailer(accountTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetAccountTrailer_MissingRecordType() {
        AccountTrailer accountTrailer = new AccountTrailer();
        accountTrailer.setFileType("FT");
        accountTrailer.setDetailEmployeeRecordCount("100");

        Object result = custom1350LayoutGenerator.getAccountTrailer(accountTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetAccountTrailer_MissingFileType() {
        AccountTrailer accountTrailer = new AccountTrailer();
        accountTrailer.setRecordType("RT");
        accountTrailer.setDetailEmployeeRecordCount("100");

        Object result = custom1350LayoutGenerator.getAccountTrailer(accountTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetAccountTrailer_MissingDetailEmployeeRecordCount() {
        AccountTrailer accountTrailer = new AccountTrailer();
        accountTrailer.setRecordType("RT");
        accountTrailer.setFileType("FT");

        Object result = custom1350LayoutGenerator.getAccountTrailer(accountTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetAccountTrailer_AllFieldsMissing() {
        AccountTrailer accountTrailer = new AccountTrailer();

        Object result = custom1350LayoutGenerator.getAccountTrailer(accountTrailer);

        assertNotNull(result);
    }

    @Test
    public void testGetDetailRecord_WithEmployeeTransactionData() {
        EmployeeTransactionData employeeTransactionData = new EmployeeTransactionData();
        employeeTransactionData.setRecordType("RT");
        employeeTransactionData.setTransactionCode("TC");
        Member member = new Member();
        member.setSubscriberInd(Choice.Yes);
        member.setSocialSecurityNumber("123-45-6789");
        member.setName(new Name().firstName("John").lastName("Doe"));
        member.contact(new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890"))));
        employeeTransactionData.setMembers(Arrays.asList(member));
        List<EmployeeTransactionData> employeeTransactionDatas = new ArrayList<>();
        employeeTransactionDatas.add(employeeTransactionData);
        employeeTransactionData.setEmployeeSpecificDatalg(new EmployeeSpecificDataLg());
        StringBuilder result = custom1350LayoutGenerator.getDetailRecord(employeeTransactionDatas);

        assertNotNull(result);
    }

    @Test
    public void testGetDetailRecord_EmptyEmployeeTransactionData() {
        List<EmployeeTransactionData> employeeTransactionDatas = new ArrayList<>();
        StringBuilder result = custom1350LayoutGenerator.getDetailRecord(employeeTransactionDatas);

        assertNotNull(result);
    }

    @Test
    public void testMemberIterator_WithMembers() {
        EmployeeTransactionData employeeTransactionData = new EmployeeTransactionData();
        employeeTransactionData.setRecordType("RT");
        employeeTransactionData.setTransactionCode("TC");
        employeeTransactionData.setEmployeeSpecificDatalg(new EmployeeSpecificDataLg());
        Member member = new Member();
        member.setSubscriberInd(Choice.Yes);
        member.setSocialSecurityNumber("123-45-6789");
        member.setName(new Name().firstName("John").lastName("Doe"));
        member.contact(new Contact().email(Arrays.asList(new Email().emailAddress("aaa")))
                .phone(Arrays.asList(new Phone().phoneNumber("1234567890"))));
        List<Member> members = Arrays.asList(member);
        StringBuilder detailRecord = new StringBuilder();

        custom1350LayoutGenerator.memberIterator(detailRecord, employeeTransactionData, members, "123-45-6789");

        assertNotNull(detailRecord);
    }

    @Test
    public void testMemberIterator_EmptyMembers() {
        EmployeeTransactionData employeeTransactionData = new EmployeeTransactionData();
        List<Member> members = new ArrayList<>();
        StringBuilder detailRecord = new StringBuilder();

        custom1350LayoutGenerator.memberIterator(detailRecord, employeeTransactionData, members, "123-45-6789");

        assertNotNull(detailRecord);
    }

    @Test
    public void testMemberSsnAndLnameAndFnameAndMiAndSuffix_AllElseBlocks() {
        Member member = new Member();
        member.setName(new Name());
        StringBuilder keyDemographicDataStr = new StringBuilder();
        String subscriberSSN = null;

        custom1350LayoutGenerator.memberSsnAndLnameAndFnameAndMiAndSuffix(member, keyDemographicDataStr, subscriberSSN);

        String result = keyDemographicDataStr.toString();
        assertNotNull(result);
    }

    @Test
    public void testSetRelationShipCode_Self() {
        Member member = new Member();
        member.setRelationshipCode(RelationshipCode.SELF);
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testSetRelationShipCode_Spouse() {
        Member member = new Member();
        member.setRelationshipCode(RelationshipCode.SPOUSE);
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testSetRelationShipCode_Child() {
        Member member = new Member();
        member.setRelationshipCode(RelationshipCode.CHILD);
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testSetRelationShipCode_LifePartner() {
        Member member = new Member();
        member.setRelationshipCode(RelationshipCode.LIFE_PARTNER);
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testSetRelationShipCode_Other() {
        Member member = new Member();
        member.setRelationshipCode(RelationshipCode.WARD);
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testSetRelationShipCode_Null() {
        Member member = new Member();
        member.setRelationshipCode(null);
        StringBuilder keyDemographicDataStr = new StringBuilder();
        custom1350LayoutGenerator.setRelationShipCode(member, keyDemographicDataStr);
        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testMemberDobAndSeAndRc_AllFieldsPresent() {
        Member member = new Member();
        member.setDateOfBirth("2023-10-10");
        member.setGender(Gender.MALE);
        member.setRelationshipCode(RelationshipCode.SELF);
        StringBuilder keyDemographicDataStr = new StringBuilder();

        custom1350LayoutGenerator.memberDobAndSeAndRc(member, keyDemographicDataStr);

        assertNotNull(keyDemographicDataStr);
    }

    @Test
    public void testGetTefraInformationData_EffectiveDateNotNull() {
        TefraInformationLg tefraInformationLg = new TefraInformationLg();
        tefraInformationLg.setTefraEffectiveDate("2023-10-10");
        String result = custom1350LayoutGenerator.getTefraInformationData(tefraInformationLg);
        assertNotNull(result);
    }

    @Test
    public void testGetTefraInformationData_TerminationDateNotNull() {
        TefraInformationLg tefraInformationLg = new TefraInformationLg();
        tefraInformationLg.setTefraTerminationDate("2023-12-31");
        String result = custom1350LayoutGenerator.getTefraInformationData(tefraInformationLg);
        assertNotNull(result);
    }

    @Test
    public void testSetMedicareEligibilityIndicator_PartAAndPartBYes() {
        Medicare medicareInsuranceInfo = new Medicare();
        medicareInsuranceInfo.setHasPartA(Choice.Yes);
        medicareInsuranceInfo.setHasPartB(Choice.Yes);
        String result = custom1350LayoutGenerator.setMedicareEligibilityIndicator(medicareInsuranceInfo);
        assertNotNull(result);
    }

    @Test
    public void testSetMedicareEligibilityIndicator_PartAYesPartBNo() {
        Medicare medicareInsuranceInfo = new Medicare();
        medicareInsuranceInfo.setHasPartA(Choice.Yes);
        String result = custom1350LayoutGenerator.setMedicareEligibilityIndicator(medicareInsuranceInfo);
        assertNotNull(result);
    }

    @Test
    public void testSetMedicareEligibilityIndicator_PartANoPartBYes() {
        Medicare medicareInsuranceInfo = new Medicare();
        medicareInsuranceInfo.setHasPartB(Choice.Yes);
        String result = custom1350LayoutGenerator.setMedicareEligibilityIndicator(medicareInsuranceInfo);
        assertNotNull(result);
    }

    @Test
    public void testSetMedicareEligibilityIndicator_PartANoPartBNo() {
        Medicare medicareInsuranceInfo = new Medicare();
        medicareInsuranceInfo.setHasPartA(Choice.No);
        medicareInsuranceInfo.setHasPartB(Choice.No);
        String result = custom1350LayoutGenerator.setMedicareEligibilityIndicator(medicareInsuranceInfo);
        assertEquals("4", result);
    }

    @Test
    public void testSetMedicareEligibilityIndicator_PartANullPartBNull() {
        Medicare medicareInsuranceInfo = new Medicare();
        medicareInsuranceInfo.setHasPartA(null);
        medicareInsuranceInfo.setHasPartB(null);
        String result = custom1350LayoutGenerator.setMedicareEligibilityIndicator(medicareInsuranceInfo);
        assertEquals("9", result);
    }

    @Test
    public void testMedicareAAndBDatesandHICNumAndEligibiltyIndDetails_AllFieldsPresent() {
        StringBuilder medicareInsuranceInfostr = new StringBuilder();
        Medicare medicareInsuranceInfo = new Medicare();
        medicareInsuranceInfo.setMedicareNumber("123456789");
        medicareInsuranceInfo.setPartAEntitlementDate(LocalDate.of(2023, 10, 10));
        medicareInsuranceInfo.setMedicareEfftiveEndDate("2023-12-31");
        String medicareEligibilityIndicator = "3";

        custom1350LayoutGenerator.medicareAAndBDatesandHICNumAndEligibiltyIndDetails(medicareInsuranceInfostr,
                medicareInsuranceInfo, medicareEligibilityIndicator);

        assertNotNull(medicareInsuranceInfostr);
    }

}