# group-enrollments-kafka-consumer
 
1.	<B>Title:</B> group-enrollments-kafka-consumer    

2.	<B>Description:</B>This is CareFirst Member Enrollment API helps consumers for submitting member enrollment applications<br><br>This Application or Enrollment Submission client API is a standard intake enrollment api from  all the consumer to put the enrollment application data captured as part of the enrollment submission workflow to the enrollment target system. <br><br> Consumer send the  daily enrollment application files to Carefirst Member Enrollment API. Once the application intake is done,Member Enrollment API process those application and send it to corresponding consumer based upon the line of business. <br><br>Member Enrollment API supports enrollment submissions for MAPD, Individual, all market segments which includes small market, mid market and large group and all FSPs.<br><br><b> It is covering below  operations. </b> <br> * post: application - operation to submit member enrollment application.<br>  * get: application - operation to get the member enrollment application details.<br>  * patch: application - operation to update member enrollment application.<br>  * get: application/status - operation to get the member enrollment application current status.<br><br>
Kafka Connector KSQL will send the Application Request with PENDING status to topic member.enrollment.domaincdc.<<env>>.application. <br>It will be consumed by group-enrollments-kafka-consumer to generate the processor payload. <br>And that processor payload will be read by enrollments-edifecs-sb to generate the 1350 file.<br> And enrollments-edifecs-sb will upload the 1350 file to Azure blob. <br> And it will be pickup by Edifecs for actual enrollment processing 

And group-enrollments-kafka-consumer will process those pending request and generate '

3.	<B>Documentation:</B> <br>
    a.	OpenAPI Definitions:<br>
        	<a href="https://nexus-deva.carefirst.com/member-enrollments-api/swagger-ui/index.html">Swagger UI</a> <br>
       		<a href="https://dev.azure.com/CareFirstCloud/nexus-enrollment/_git/member-enrollments-api"> Microservice Spec </a>    <br>            
    b.	Share point: <a href="#"> Reference </a>  <br>             
	c.	Jira <a href="#">Reference</a>  <br>
   	d.	Features: .<br>
	e.	Backing systems:<br>
		<a href="#">Database: pcftst</a> <br>

		DEVA / SITA / PIT / UAT :
jdbc:postgresql://psql-nexusmembenrollmentdeva-dev-001.postgres.database.azure.com:5432/membenrollmentdeva
jdbc:postgresql://psql-nexusmembenrollmentsita-test-001.postgres.database.azure.com:5432/membenrollmentsita
jdbc:postgresql://psql-nexmembenrollmentpit-test-001.postgres.database.azure.com:5432/enrollmentmanagerpit
jdbc:postgresql://psql-nexmembenrollmentuat-uat-001.postgres.database.azure.com:5432/enrollmentmanageruat

	f. APIM proxy URL:
		https://azapim-{{env}}.carefirst.com/api-memberenrollments/v1/	

3.	<B>Setup and Configuration:</B> 
                SpringBoot Maven Project with all dependencies added in Nexus parent Project.
        
4. <B>Solution Manager: </B> Gupta, Rajan <Rajan.Gupta@carefirst.com>

5. <B>System Architect: </B> Mahadevappa, Chethan <Chethan.Mahadevappa@carefirst.com> , Chowdripalya, Lokesh <Lokesh.Chowdripalya@carefirst.com> 

6. <B>Domain SME: </B> Andhavarapu, Srinivasa <Srinivasa.Andhavarapu@carefirst.com>

7. <B>Developer Lead: </B> Prema, Alamelu <Alamelu.Prema@carefirst.com>

8. <B> Supporting DL:  </B> Nexus Domain Team.
