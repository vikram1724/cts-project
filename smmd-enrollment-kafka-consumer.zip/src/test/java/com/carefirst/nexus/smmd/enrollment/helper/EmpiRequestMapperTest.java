package com.carefirst.nexus.smmd.enrollment.helper;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;

import java.io.File;
import java.io.IOException;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.generate.ws.RegisterMemberRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@RunWith(MockitoJUnitRunner.class)
public class EmpiRequestMapperTest {
    @InjectMocks
    private EmpiRequestMapper empiRequestMapper;
    MemberEnrollmentApplication memberEnrollmentApplication;

    @Before
    public void setUp() throws IOException {
        ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
        memberEnrollmentApplication = mapper.readValue(
                new File("src/test/resources/memberEnrollmentApplication_request.json"),
                MemberEnrollmentApplication.class);
    }

    @Test
    public void testCreateEmpiRequest() {
        RegisterMemberRequest request = empiRequestMapper
                .createEmpiRequest(memberEnrollmentApplication.getMembers().get(0));
        assertEquals(memberEnrollmentApplication.getMembers().get(0).getName().getFirstName(),
                request.getRegisterMember().getName().getFirstName());
    }

    @Test
    public void testCreateEmpiRequest_exc() {
        memberEnrollmentApplication.getMembers().get(0).setDateOfBirth("12/12/2023");
        RegisterMemberRequest request = empiRequestMapper
                .createEmpiRequest(memberEnrollmentApplication.getMembers().get(0));
        assertNull(request);
    }

}
