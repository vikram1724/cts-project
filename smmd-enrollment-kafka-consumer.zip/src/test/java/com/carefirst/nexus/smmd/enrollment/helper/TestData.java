package com.carefirst.nexus.smmd.enrollment.helper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountTrailer;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeSpecificDataLg;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileTrailer;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

public class TestData {

    public FileHeader setFileHeaderValues() {
        FileHeader fileHeader = new FileHeader();
        fileHeader.setSourceId("sourceid");
        fileHeader.setCreatedDate("createdDate");
        fileHeader.setHoldField("holdfiled");
        fileHeader.setRecordType("recordType");
        fileHeader.setSubmitterRole("role");

        return fileHeader;
    }

    public List<EmployeeTransactionData> setvaluesEmployeeDataTransac() throws StreamReadException, DatabindException, IOException {
        List<EmployeeTransactionData> list = new ArrayList<>();
        ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
        MemberEnrollmentApplication memberEnrollmentApplication = mapper.readValue(
                new File("src/test/resources/memberEnrollmentApplication_request.json"),
                MemberEnrollmentApplication.class);

        EmployeeTransactionData employeeTransactionData = new EmployeeTransactionData();
        EmployeeSpecificDataLg employeeSpecificDataLg = new EmployeeSpecificDataLg();
        employeeSpecificDataLg.setEmployeeLocation("location");
        employeeSpecificDataLg.setEmployeeNumber("number");
        employeeSpecificDataLg.setEmployeeSalaryAmount("salaryamt");
        employeeSpecificDataLg.setEmployeeSalaryEffectiveDate("effdate");
        employeeSpecificDataLg.setEmploymentHireDate("emphireDate");
        employeeSpecificDataLg.setMaritalStatus("marital");
        employeeSpecificDataLg.setMarriageDate("marriageDate");
        employeeSpecificDataLg.setStatusIndicator("indicatorStatus");
        employeeTransactionData.setEmployeeSpecificDatalg(employeeSpecificDataLg);
        employeeTransactionData.setApplication(memberEnrollmentApplication.getApplication());
        employeeTransactionData.setBrokers(memberEnrollmentApplication.getAgents());
        employeeTransactionData.setMembers(memberEnrollmentApplication.getMembers());
        list.add(employeeTransactionData);
        return list;
    }

    public AccountHeader setAccountHeaderValues() {
        AccountHeader accountHeader = new AccountHeader();
        accountHeader.setCompanyName("compname");
        accountHeader.setContactName("contactname");
        accountHeader.setContactTelephoneNumber("09843098765432");
        accountHeader.setDateFileSubmitted("datefilesubmit");
        accountHeader.setFileType("filetypei");
        accountHeader.setFiller("fill");
        accountHeader.setGroupType("grp");
        accountHeader.setHoldField("hold");
        accountHeader.setMemberTermDateDefault("membertermdef");
        accountHeader.setPcpIndicator("PCPIND");
        accountHeader.setRecordType("recordType");
        accountHeader.setRenewalIndicator("renIND");
        accountHeader.setResubmittedFileIndicator("resubbmitInd");
        accountHeader.setResubmittedFileOriginalDate("originaldate");
        accountHeader.setSalesPersonNumber("98765432347876543");
        accountHeader.setUniqueCoIdentifierFedTaxId("uniq");

        return accountHeader;
    }

    public AccountTrailer setAccountTrailerValues() {

        AccountTrailer accountTrailer = new AccountTrailer();
        accountTrailer.setFileType("filetype");
        accountTrailer.setHoldField("holdField");
        accountTrailer.setRecordType("recordType");
        accountTrailer.setDetailEmployeeRecordCount("detailEmployeeRecordCount");
        return accountTrailer;

    }

    public FileTrailer setFileTrailerValues() {

        FileTrailer fileTrailer = new FileTrailer();
        fileTrailer.setHoldField("holdFiled");
        fileTrailer.setRecordType("recordType");
        fileTrailer.setTotalAccountorGroupCount("totalAccgrpCpunt");
        fileTrailer.setTotalrecordCount("totalrecordCount");
        return fileTrailer;

    }
}
