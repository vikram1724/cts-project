package com.carefirst.nexus.smmd.enrollment.service;

import static org.mockito.Mockito.verify;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;

@RunWith(MockitoJUnitRunner.class)
public class EnrollmentTransactionProcessServiceTest {

    @InjectMocks
    EnrollmentTransactionProcessService service;

    @Mock
    ProcessorPayloadGeneratorService processorPayloadGeneratorService;

    @Test
    public void processPayloadTest() throws RecoverableMessageException, UnrecoverableMessageException{
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        transactionListenerPayload.setSubmitterApplicationId("1234");
        service.processPayload(transactionListenerPayload);
        verify(processorPayloadGeneratorService).generateProcessorPaylod(transactionListenerPayload);
    }

    @Test(expected = RecoverableMessageException.class)
    public void processPayloadTest1() throws RecoverableMessageException, UnrecoverableMessageException{
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        service.processPayload(transactionListenerPayload);
    }

    @Test(expected = RecoverableMessageException.class)
    public void processPayloadTest2() throws RecoverableMessageException, UnrecoverableMessageException{
        TransactionListenerPayload transactionListenerPayload = new TransactionListenerPayload();
        transactionListenerPayload.setSubmitterApplicationId("");
        service.processPayload(transactionListenerPayload);
    }
}
