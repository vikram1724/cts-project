package com.carefirst.nexus.smmd.enrollment.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.smmd.enrollment.helper.Custom1350LayoutGenerator;
import com.carefirst.nexus.smmd.enrollment.helper.MembersProductCoverageRetrieve;
import com.carefirst.nexus.smmd.enrollment.helper.ProcessorPayloadHelper;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;

@RunWith(MockitoJUnitRunner.Silent.class)
public class ProcessorPayloadGeneratorServiceTest {

    @InjectMocks
    ProcessorPayloadGeneratorService service;

    @Mock
    private Custom1350LayoutGenerator custom1350LayoutGenerator;

    @Mock
    private EnrollPortalIntegrationService enrollPortalIntegrationService;

    @Mock
    private MembersProductCoverageRetrieve membersProductCoverageRetrieve;

    @Mock
    private ProcessorPayloadHelper processorPayloadHelper;

    @Mock
    private MeberEnrollmetApiService meberEnrollmetApiService;

    @Mock
    private EmpiIntegrationService empiIntegrationService;

    @Before
    public void setUp() throws  UnrecoverableMessageException, RecoverableMessageException{
        ReflectionTestUtils.setField(service, "edifecs", true);
        when(enrollPortalIntegrationService.enrollEmpoyeePortal(Mockito.any(MemberEnrollmentApplication.class))).thenReturn(new EnrollmentData());
    }

    @Test(expected = RecoverableMessageException.class)
    public void generateProcessorPaylodTest() throws RecoverableMessageException {
        service.generateProcessorPaylod(new TransactionListenerPayload());
    }

    @Test
    public void generateProcessorPaylodTest1() throws RecoverableMessageException, IOException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(custom1350LayoutGenerator.formatEmplyeeTransactionData(any())).thenReturn("test");
        service.generateProcessorPaylod(payload);
        verify(meberEnrollmetApiService).updateMemberEnrollment(any(), any(), any(), any(), any());
        payload.setStatus("DRAFT");
        service.generateProcessorPaylod(payload);
        verify(custom1350LayoutGenerator, atLeast(2)).formatEmplyeeTransactionData(any());
        payload.setSubmitterApplicationId(null);
        service.generateProcessorPaylod(payload);
        verify(custom1350LayoutGenerator, atLeast(3)).formatEmplyeeTransactionData(any());
    }

    @Test(expected = RecoverableMessageException.class)
    public void generateProcessorPaylodTest2() throws RecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterPayload(null);
        service.generateProcessorPaylod(payload);
    }

    @Test(expected = RecoverableMessageException.class)
    public void generateProcessorPaylodTest3() throws RecoverableMessageException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterPayload("");
        service.generateProcessorPaylod(payload);
    }

    @Test
    public void generateProcessorPaylodTest4() throws RecoverableMessageException, IOException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        service.generateProcessorPaylod(payload);
        verify(custom1350LayoutGenerator).formatEmplyeeTransactionData(any());
    }

    @Test
    public void generateProcessorPaylodTest5() throws RecoverableMessageException, IOException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(custom1350LayoutGenerator.formatEmplyeeTransactionData(any())).thenReturn("");
        service.generateProcessorPaylod(payload);
        verify(custom1350LayoutGenerator).formatEmplyeeTransactionData(any());
    }

    @Test
    public void generateProcessorPaylodTest6() throws RecoverableMessageException, IOException {
        TransactionListenerPayload payload = new TransactionListenerPayload();
        payload.setSubmitterApplicationId("123");
        payload.setStatus("PENDING");
        String submitterPayload = Files
                .readString(Path.of("src/test/resources/memberEnrollmentApplication_request.json"));
        payload.setSubmitterPayload(submitterPayload);
        when(custom1350LayoutGenerator.formatEmplyeeTransactionData(any())).thenReturn("");
        service.generateProcessorPaylod(payload);
        verify(custom1350LayoutGenerator).formatEmplyeeTransactionData(any());
    }

}
