package com.carefirst.nexus.smmd.enrollment.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.enrollments.gen.api.MemberEnrollmentsApiApi;
import com.carefirst.nexus.enrollments.gen.model.Status;
import com.carefirst.nexus.enrollments.gen.model.UpdateMemberEnrollmentResponse;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.class)
public class MeberEnrollmetApiServiceTest {

    @InjectMocks
    MeberEnrollmetApiService service;

    @Mock
    MemberEnrollmentsApiApi memberEnrollmentsApi;

    @Test
    public void updateMemberEnrollmentTest(){
        when(memberEnrollmentsApi.updateMemberEnrollment(any())).thenReturn(Mono.just(new UpdateMemberEnrollmentResponse()));
        assertNotNull(service.updateMemberEnrollment("123", "test", "test", Status.DRAFT, "123"));
    }

    @Test
    public void updateMemberEnrollmentTest1(){
        when(memberEnrollmentsApi.updateMemberEnrollment(any())).thenReturn(null);
        service.updateMemberEnrollment("123", "test", "test", Status.DRAFT, "123"); 
        verify(memberEnrollmentsApi).updateMemberEnrollment(any());
    }

    @Test(expected = Exception.class)
    public void updateMemberEnrollmentTest2(){
        when(memberEnrollmentsApi.updateMemberEnrollment(any())).thenThrow(new RuntimeException("test"));
        service.updateMemberEnrollment("123", "test", "test", Status.DRAFT, "123"); 
    }
    
}
