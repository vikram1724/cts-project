package com.carefirst.nexus.smmd.enrollment.helper;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.enrollments.gen.model.BenefitStatus;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.group.gen.model.Group;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountTrailer;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeSpecificDataLg;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileTrailer;
import com.carefirst.nexus.smmd.enrollment.service.groupapi.GroupBaseApiService;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;

@RunWith(MockitoJUnitRunner.class)
public class ProcessorPayloadHelperTest {

   @InjectMocks
   private ProcessorPayloadHelper processorPayloadHelper;

   @Mock
   GroupBaseApiService groupService;

   MemberEnrollmentApplication memberEnrollmentApplication;

   @Before
   public void setUp() throws StreamReadException, DatabindException, IOException {
      Group group = new Group();
      group.setGroupId("0MDB");
      group.setGroupName("GroupName");
      when(groupService.getGroupDetailsByGroupId(Mockito.any())).thenReturn(group);
      ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
            .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
      memberEnrollmentApplication = mapper.readValue(
            new File("src/test/resources/memberEnrollmentApplication_request.json"),
            MemberEnrollmentApplication.class);
   }

   @Test
   public void populateFileHeaderTest() {
      FileHeader populateFileHeader = processorPayloadHelper.populateFileHeader(memberEnrollmentApplication);
      assertEquals("01", populateFileHeader.getRecordType());
   }

   @Test
   public void populateAccountHeaderTest() {
      AccountHeader accountHeader = processorPayloadHelper.populateAccountHeader(memberEnrollmentApplication);
      assertEquals("10", accountHeader.getRecordType());
   }

   @Test
   public void populateAccountHeaderTest_exc() {
      when(groupService.getGroupDetailsByGroupId(Mockito.any())).thenThrow(new RuntimeException());
      AccountHeader accountHeader = processorPayloadHelper.populateAccountHeader(memberEnrollmentApplication);
      assertEquals("10", accountHeader.getRecordType());
   }

   @Test
   public void populteEmpTransactioDataTest() {
      EmployeeTransactionData employeeTransactionData = processorPayloadHelper
            .populteEmpTransactioData(memberEnrollmentApplication);
      assertEquals("20", employeeTransactionData.getRecordType());
   }

   @Test
   public void populateAccountTrailerTest() {
      AccountTrailer accountTrailer = processorPayloadHelper.populateAccountTrailer("1");
      assertEquals("30", accountTrailer.getRecordType());
   }

   @Test
   public void populteFileTrailerTest() {
      FileTrailer populteFileTrailer = processorPayloadHelper.populteFileTrailer("1");
      assertEquals("02", populteFileTrailer.getRecordType());
   }

   @Test
   public void populteEmployeeSpecificDataLgTest() {
      EmployeeSpecificDataLg populteEmployeeSpecificDataLg = processorPayloadHelper
            .populteEmployeeSpecificDataLg(memberEnrollmentApplication);
      assertEquals("A", populteEmployeeSpecificDataLg.getStatusIndicator());
   }

   @Test
   public void populteEmployeeSpecificDataLgTestCobra() {
      memberEnrollmentApplication.getMembers().get(1).setBenefitStatus(BenefitStatus.COBRA);
      EmployeeSpecificDataLg populteEmployeeSpecificDataLg = processorPayloadHelper
            .populteEmployeeSpecificDataLg(memberEnrollmentApplication);
      assertEquals("C", populteEmployeeSpecificDataLg.getStatusIndicator());
   }

   @Test
   public void populteEmployeeSpecificDataLgTestR() {
      memberEnrollmentApplication.getMembers().get(1).setBenefitStatus(BenefitStatus.RETIRED);
      EmployeeSpecificDataLg populteEmployeeSpecificDataLg = processorPayloadHelper
            .populteEmployeeSpecificDataLg(memberEnrollmentApplication);
      assertEquals("R", populteEmployeeSpecificDataLg.getStatusIndicator());
   }

   @Test
   public void getFormattedDateTest() {
      assertNotNull(processorPayloadHelper.getFormattedDate(LocalDate.now()));
   }

   @Test
   public void getFormattedDateTestNull() {
      LocalDate dt = null;
      assertNull(processorPayloadHelper.getFormattedDate(dt));
   }

   @Test
   public void getFormattedDateTimeTestNull() {
      LocalDateTime dt = null;
      assertNull(processorPayloadHelper.getFormattedDate(dt));
   }

}
