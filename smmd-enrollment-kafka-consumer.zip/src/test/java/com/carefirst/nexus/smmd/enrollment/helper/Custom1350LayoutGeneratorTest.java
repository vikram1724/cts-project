package com.carefirst.nexus.smmd.enrollment.helper;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.enrollments.gen.model.Application;
import com.carefirst.nexus.enrollments.gen.model.Broker;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.RelationshipCode;
import com.carefirst.nexus.smmd.enrollment.constants.EnrollmentConstants;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountTrailer;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileTrailer;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.ProcessorPayload1;
import com.fasterxml.jackson.core.exc.StreamReadException;
import com.fasterxml.jackson.databind.DatabindException;

@RunWith(MockitoJUnitRunner.Silent.class)
public class Custom1350LayoutGeneratorTest {

    @InjectMocks
    Custom1350LayoutGenerator custom1350LayoutGenerator;

    @Mock
    EnrollmentUtil enrollmentUtil;

    @Test
    public void testFormatEmplyeeTransactionData() throws StreamReadException, DatabindException, IOException {
        when(enrollmentUtil.getCoverageLevelByCoverageType(Mockito.any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);
        ProcessorPayload1 processorPayload = new ProcessorPayload1();

        TestData test1 = new TestData();
        FileHeader fileheader = test1.setFileHeaderValues();
        processorPayload.setFileHeader(fileheader);

        List<EmployeeTransactionData> list = test1.setvaluesEmployeeDataTransac();
        processorPayload.setEmployeeTransactionDatas(list);

        AccountHeader accountHeader = test1.setAccountHeaderValues();
        processorPayload.setAccountHeader(accountHeader);

        AccountTrailer accountTrailer = test1.setAccountTrailerValues();
        processorPayload.setAccountTrailer(accountTrailer);

        FileTrailer fileTrailer = test1.setFileTrailerValues();
        processorPayload.setFileTrailer(fileTrailer);

        String result = custom1350LayoutGenerator.formatEmplyeeTransactionData(processorPayload);
        assertNotNull(result);
    }

    @Test
    public void testFormatEmplyeeTransactionDataLiefPartner() throws StreamReadException, DatabindException, IOException {
        when(enrollmentUtil.getCoverageLevelByCoverageType(Mockito.any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);
        ProcessorPayload1 processorPayload = new ProcessorPayload1();

        TestData test1 = new TestData();
        FileHeader fileheader = test1.setFileHeaderValues();
        processorPayload.setFileHeader(fileheader);

        List<EmployeeTransactionData> list = test1.setvaluesEmployeeDataTransac();
        list.get(0).getMembers().stream().forEach(member -> {
            if(RelationshipCode.CHILD.equals(member.getRelationshipCode())){
                member.setRelationshipCode(RelationshipCode.LIFE_PARTNER);
            }
            if(RelationshipCode.SPOUSE.equals(member.getRelationshipCode())){
                member.setRelationshipCode(RelationshipCode.STEPSON_OR_DAUGHTER);
            }
        });
        processorPayload.setEmployeeTransactionDatas(list);

        AccountHeader accountHeader = test1.setAccountHeaderValues();
        processorPayload.setAccountHeader(accountHeader);

        AccountTrailer accountTrailer = test1.setAccountTrailerValues();
        processorPayload.setAccountTrailer(accountTrailer);

        FileTrailer fileTrailer = test1.setFileTrailerValues();
        processorPayload.setFileTrailer(fileTrailer);

        String result = custom1350LayoutGenerator.formatEmplyeeTransactionData(processorPayload);
        assertNotNull(result);
    }

    @Test
    public void testFormatEmplyeeTransactionDataEMpty() throws StreamReadException, DatabindException, IOException {
        when(enrollmentUtil.getCoverageLevelByCoverageType(Mockito.any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);
        ProcessorPayload1 processorPayload = new ProcessorPayload1();

        TestData test1 = new TestData();
        FileHeader fileheader = test1.setFileHeaderValues();
        processorPayload.setFileHeader(fileheader);

        List<EmployeeTransactionData> list = test1.setvaluesEmployeeDataTransac();
        EmployeeTransactionData data = list.get(0);
        data.setApplication(new Application());
        data.setMembers(new ArrayList<>());
        Member member = new Member();
        member.setProductCoverages(new ArrayList<>());
        data.getMembers().add(member);
        data.setBrokers(new ArrayList<>());
        data.getBrokers().add(new Broker());
        processorPayload.setEmployeeTransactionDatas(list);

        AccountHeader accountHeader = test1.setAccountHeaderValues();
        processorPayload.setAccountHeader(accountHeader);

        AccountTrailer accountTrailer = test1.setAccountTrailerValues();
        processorPayload.setAccountTrailer(accountTrailer);

        FileTrailer fileTrailer = test1.setFileTrailerValues();
        processorPayload.setFileTrailer(fileTrailer);

        String result = custom1350LayoutGenerator.formatEmplyeeTransactionData(processorPayload);
        assertNotNull(result);
    }

    @Test
    public void testFormatEmplyeeTransactionDataNull() {
        when(enrollmentUtil.getCoverageLevelByCoverageType(Mockito.any()))
                .thenReturn(EnrollmentConstants.COVERAGETYPE_EMP_CODE);
        ProcessorPayload1 processorPayload = new ProcessorPayload1();
        processorPayload.setAccountHeader(new AccountHeader());
        processorPayload.setAccountTrailer(new AccountTrailer());
        processorPayload.setEmployeeTransactionDatas(new ArrayList<>());
        processorPayload.setFileHeader(new FileHeader());
        processorPayload.setFileTrailer(new FileTrailer());
        String result = custom1350LayoutGenerator.formatEmplyeeTransactionData(processorPayload);
        assertNotNull(result);
    }

}
