package com.carefirst.nexus.smmd.enrollment.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import com.carefirst.nexus.group.gen.model.Group;
import com.carefirst.nexus.group.gen.api.GroupDetailsApi;
import com.carefirst.nexus.group.gen.model.GroupResponse;
import com.carefirst.nexus.smmd.enrollment.service.groupapi.GroupBaseApiService;
import com.carefirst.nexus.utils.web.error.AppJSONException;

import reactor.core.publisher.Mono;

@RunWith(MockitoJUnitRunner.class)
public class GroupBaseApiServiceTest {
    @InjectMocks
    GroupBaseApiService groupBaseApiService;

    @Mock
     GroupDetailsApi groupOperationsApi;

     @Test
     public void getGroupDetailsByGroupId(){
        GroupResponse groupResponse=new GroupResponse();
        Group group=new Group();
        group.setCjaCode("test");
        groupResponse.setGroup(group);
        when(groupOperationsApi.getGroup(Mockito.anyString())).thenReturn(Mono.just(groupResponse));
       assertNotNull(groupBaseApiService.getGroupDetailsByGroupId("test"));
     }
     @Test(expected=AppJSONException.class)
     public void getGroupDetailsByGroupIdWithGroupNull(){
        GroupResponse groupResponse=new GroupResponse();
        groupResponse.setGroup(null);
        when(groupOperationsApi.getGroup(Mockito.anyString())).thenReturn(Mono.just(groupResponse));
        groupBaseApiService.getGroupDetailsByGroupId("test");
     }
     @Test(expected=Exception.class)
     public void getGroupDetailsByGroupIdException(){
        when(groupOperationsApi.getGroup(Mockito.anyString())).thenThrow(Exception.class);
        groupBaseApiService.getGroupDetailsByGroupId("test");
     }

}
