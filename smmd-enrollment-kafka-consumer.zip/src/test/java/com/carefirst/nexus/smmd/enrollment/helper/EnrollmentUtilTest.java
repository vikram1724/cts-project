package com.carefirst.nexus.smmd.enrollment.helper;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.junit.MockitoJUnitRunner;

import com.carefirst.nexus.enrollments.gen.model.CoverageLevel;
import com.carefirst.nexus.smmd.enrollment.constants.EnrollmentConstants;

@RunWith(MockitoJUnitRunner.class)
public class EnrollmentUtilTest {

    @InjectMocks
    EnrollmentUtil enrollmentUtil;

    @Test
    public void testCoverageLevelByCoverageTypeEMP() {
        String coverageType = enrollmentUtil.getCoverageLevelByCoverageType(CoverageLevel.EMPLOYEE);
        assertEquals(EnrollmentConstants.COVERAGETYPE_EMP_CODE, coverageType);
    }

    @Test
    public void testCoverageLevelByCoverageTypeSPOUSE() {
        String coverageType = enrollmentUtil.getCoverageLevelByCoverageType(CoverageLevel.EMPLOYEE_SPOUSE);
        assertEquals(EnrollmentConstants.COVERAGETYPE_ESP_CODE, coverageType);
    }

    @Test
    public void testCoverageLevelByCoverageTypeFAMILY() {
        String coverageType = enrollmentUtil.getCoverageLevelByCoverageType(CoverageLevel.FAMILY);
        assertEquals(EnrollmentConstants.COVERAGETYPE_FAM_CODE, coverageType);
    }

    @Test
    public void testCoverageLevelByCoverageTypeEDP() {
        String coverageType = enrollmentUtil.getCoverageLevelByCoverageType(CoverageLevel.EMPLOYEE_DOMESTIC_PARTNER);
        assertEquals(EnrollmentConstants.COVERAGETYPE_EDP_CODE, coverageType);
    }

    @Test
    public void testCoverageLevelByCoverageTypeChild() {
        String coverageType = enrollmentUtil.getCoverageLevelByCoverageType(CoverageLevel.EMPLOYEE_CHILDREN);
        assertEquals(EnrollmentConstants.COVERAGETYPE_E1D_CODE, coverageType);
    }

    @Test
    public void testCoverageLevelByCoverageTypeNull() {
        String coverageType = enrollmentUtil.getCoverageLevelByCoverageType(null);
        assertNull(coverageType);
    }

}
