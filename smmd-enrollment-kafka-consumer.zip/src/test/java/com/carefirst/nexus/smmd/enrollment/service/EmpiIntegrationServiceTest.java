package com.carefirst.nexus.smmd.enrollment.service;

import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.when;

import java.net.ConnectException;
import java.util.ArrayList;
import java.util.List;

import com.carefirst.nexus.generate.ws.Status;

import ch.qos.logback.core.testUtil.MockInitialContext;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.generate.ws.EmpiPort;
import com.carefirst.nexus.generate.ws.EmpiResponse;
import com.carefirst.nexus.generate.ws.MessageHeader;
import com.carefirst.nexus.generate.ws.RegisterMemberRequest;
import com.carefirst.nexus.generate.ws.ResponseMember;
import com.carefirst.nexus.enrollments.gen.model.Address;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Contact;
import com.carefirst.nexus.enrollments.gen.model.Email;
import com.carefirst.nexus.enrollments.gen.model.Gender;
import com.carefirst.nexus.enrollments.gen.model.Name;
import com.carefirst.nexus.enrollments.gen.model.Phone;

@RunWith(MockitoJUnitRunner.Silent.class)
public class EmpiIntegrationServiceTest {

    @InjectMocks
    EmpiIntegrationService empiIntegrationService;

    @Mock
    EmpiPort empiPort;

    @Before
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        ReflectionTestUtils.setField(empiIntegrationService, "username", "UQQEDCXA9Y");

    }

    @Test(expected = UnrecoverableMessageException.class)
    public void getSubscriberIdException() throws RecoverableMessageException, UnrecoverableMessageException {
        EmpiResponse responseMember = new EmpiResponse();
        Member member = new Member();
        List<Address> addresses = new ArrayList<>();
        List<Email> emails = new ArrayList<>();
        List<Phone> phones = new ArrayList<>();
        Phone phone = new Phone();
        phone.setExtension("+91");
        phone.setIsPrimary(Choice.Yes);
        phone.setPhoneNumber("8883567899");
        phones.add(phone);
        Email email = new Email();
        email.setEmailAddress("test");
        emails.add(email);
        Address address = new Address();
        Name name = new Name();
        Contact contact = new Contact();
        contact.setPhone(phones);
        contact.setEmail(emails);
        name.setFirstName("gdfgfgh");
        name.setLastName("tryy");
        name.setMiddleName("hfhdgh");
        name.setPrefix("sddf");
        address.setCity("test");
        address.setCountryCode("test");
        address.setLine1("test");
        address.setState("");
        address.setZipCode("weee");
        addresses.add(address);
        member.setAddress(addresses);
        member.setName(name);
        member.setContact(contact);
        member.setDateOfBirth("2001-07-12");
        member.setGender(Gender.FEMALE);
        MessageHeader value = new MessageHeader();
        value.setApplicationHeader("Test");
        responseMember.setMessageHeader(value);
        when(empiPort.empiRegisterMember(Mockito.any())).thenReturn(responseMember);
        empiIntegrationService.getSubscriberId(member);
    }

    @Test(expected = Exception.class)
    public void getSubscriberIdWithException() throws RecoverableMessageException, UnrecoverableMessageException {
        Member member = new Member();
        List<Address> addresses = new ArrayList<>();
        List<Email> emails = new ArrayList<>();
        List<Phone> phones = new ArrayList<>();
        Phone phone = new Phone();
        phone.setExtension("+91");
        phone.setIsPrimary(Choice.Yes);
        phone.setPhoneNumber("8883567899");
        phones.add(phone);
        Email email = new Email();
        email.setEmailAddress("test");
        emails.add(email);
        Address address = new Address();
        Name name = new Name();
        Contact contact = new Contact();
        contact.setPhone(phones);
        contact.setEmail(emails);
        name.setFirstName("gdfgfgh");
        name.setLastName("tryy");
        name.setMiddleName("hfhdgh");
        name.setPrefix("sddf");
        address.setCity("test");
        address.setCountryCode("test");
        address.setLine1("test");
        address.setState("");
        address.setZipCode("weee");
        addresses.add(address);
        member.setAddress(addresses);
        member.setName(name);
        member.setContact(contact);
        member.setDateOfBirth("2001-07-12");
        member.setGender(Gender.FEMALE);
        RegisterMemberRequest registerMemberRequest = new RegisterMemberRequest();
        when(empiPort.empiRegisterMember(registerMemberRequest)).thenThrow(Exception.class);
        empiIntegrationService.getSubscriberId(member);
    }

    @Test(expected = UnrecoverableMessageException.class)
    public void getSubscriberIdElseException() throws RecoverableMessageException, UnrecoverableMessageException {
        EmpiResponse responseMember = new EmpiResponse();
        Member member = new Member();
        List<Address> addresses = new ArrayList<>();
        List<Email> emails = new ArrayList<>();
        List<Phone> phones = new ArrayList<>();
        Phone phone = new Phone();
        phone.setExtension("+91");
        phone.setIsPrimary(Choice.Yes);
        phone.setPhoneNumber("8883567899");
        phones.add(phone);
        Email email = new Email();
        email.setEmailAddress("test");
        emails.add(email);
        Address address = new Address();
        Name name = new Name();
        Contact contact = new Contact();
        contact.setPhone(phones);
        contact.setEmail(emails);
        name.setFirstName("gdfgfgh");
        name.setLastName("tryy");
        name.setMiddleName("hfhdgh");
        name.setPrefix("sddf");
        address.setCity("test");
        address.setCountryCode("test");
        address.setLine1("test");
        address.setState("");
        address.setZipCode("weee");
        addresses.add(address);
        member.setAddress(addresses);
        member.setName(name);
        member.setContact(contact);
        member.setDateOfBirth("2001-07-12");
        member.setGender(Gender.FEMALE);
        MessageHeader value = new MessageHeader();
        value.setApplicationHeader("Test");
        responseMember.setMessageHeader(value);
        ResponseMember responseMember1 = new ResponseMember();
        com.carefirst.nexus.generate.ws.Member meber1 = new com.carefirst.nexus.generate.ws.Member();
        meber1.setSubscriberId("1234567");
        Status status = new Status();
        status.setCode("1234");
        status.setDescription("12345");
        responseMember1.setStatus(status);
        responseMember1.setMember(meber1);
        responseMember.getResponseMember().add(responseMember1);
        when(empiPort.empiRegisterMember(Mockito.any())).thenReturn(responseMember);
        empiIntegrationService.getSubscriberId(member);
    }

    @Test
    public void getSubscriberId() throws RecoverableMessageException, UnrecoverableMessageException {
        EmpiResponse responseMember = new EmpiResponse();
        Member member = new Member();
        List<Address> addresses = new ArrayList<>();
        List<Email> emails = new ArrayList<>();
        List<Phone> phones = new ArrayList<>();
        Phone phone = new Phone();
        phone.setExtension("+91");
        phone.setIsPrimary(Choice.Yes);
        phone.setPhoneNumber("8883567899");
        phones.add(phone);
        Email email = new Email();
        email.setEmailAddress("test");
        emails.add(email);
        Address address = new Address();
        Name name = new Name();
        Contact contact = new Contact();
        contact.setPhone(phones);
        contact.setEmail(emails);
        name.setFirstName("gdfgfgh");
        name.setLastName("tryy");
        name.setMiddleName("hfhdgh");
        name.setPrefix("sddf");
        address.setCity("test");
        address.setCountryCode("test");
        address.setLine1("test");
        address.setState("");
        address.setZipCode("weee");
        addresses.add(address);
        member.setAddress(addresses);
        member.setName(name);
        member.setContact(contact);
        member.setDateOfBirth("2001-07-12");
        member.setGender(Gender.FEMALE);
        MessageHeader value = new MessageHeader();
        value.setApplicationHeader("Test");
        responseMember.setMessageHeader(value);
        ResponseMember responseMember1 = new ResponseMember();
        com.carefirst.nexus.generate.ws.Member meber1 = new com.carefirst.nexus.generate.ws.Member();
        meber1.setSubscriberId("1234567");
        Status status = new Status();
        status.setCode("0000");
        responseMember1.setStatus(status);
        responseMember1.setMember(meber1);
        responseMember.getResponseMember().add(responseMember1);
        when(empiPort.empiRegisterMember(Mockito.any())).thenReturn(responseMember);
        assertNotNull(empiIntegrationService.getSubscriberId(member));
    }
}
