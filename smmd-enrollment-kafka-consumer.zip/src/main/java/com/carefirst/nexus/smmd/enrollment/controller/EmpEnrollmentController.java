package com.carefirst.nexus.smmd.enrollment.controller;

import java.util.Optional;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.smmd.enrollment.entity.EnrollApplEntity;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.smmd.enrollment.service.DataBaseService;
import com.carefirst.nexus.smmd.enrollment.service.EnrollmentTransactionProcessService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
public class EmpEnrollmentController {

    private DataBaseService dbApi;
    EnrollmentTransactionProcessService enrollmentTransactionProcessService;

    public EmpEnrollmentController(DataBaseService dbApi,
        EnrollmentTransactionProcessService enrollmentTransactionProcessService) {
        this.dbApi = dbApi;
        this.enrollmentTransactionProcessService = enrollmentTransactionProcessService;
    }

    @GetMapping("/kafkaenrollment")
    public Optional<EnrollApplEntity> testProvEvent(
            @RequestParam(value = "submitterApplicationId", required = false) String submitterApplicationId) {
        log.info(" > submitterApplicationId: {}", submitterApplicationId);
        Optional<EnrollApplEntity> response = dbApi.findBysubmitterAppId(submitterApplicationId);
        log.info(" > dbResponse: {}", response.get());
        return response;
    }

    @GetMapping("/processPayloadByApplicationId")
    public void processPayloadByApplicationId(
            @RequestParam(value = "submitterApplicationId", required = false) String submitterApplicationId) throws RecoverableMessageException, UnrecoverableMessageException {
        log.info(" > submitterApplicationId: {}", submitterApplicationId);
        Optional<EnrollApplEntity> response = dbApi.findBysubmitterAppId(submitterApplicationId);
        log.info(" > dbResponse: {}", response.get());
        TransactionListenerPayload payload = new TransactionListenerPayload();
        if(response.isPresent()){
            EnrollApplEntity entity = response.get();
            payload.setSubmitterPayload(entity.getSubmitterPayload());
            payload.setSubmitterApplicationId(entity.getSubmitterApplicationId());
            payload.setSource(entity.getSource());
            payload.setStatus(entity.getStatus());
            payload.setProductLine(entity.getProductLine());
            payload.setApplicantSsn(entity.getApplicantSsn());
        }
        enrollmentTransactionProcessService.processPayload(payload);
    }

    @PostMapping("/processPaylod")
    public void processPayload(@RequestBody TransactionListenerPayload response) throws RecoverableMessageException, UnrecoverableMessageException {
        enrollmentTransactionProcessService.processPayload(response);
    }

}
