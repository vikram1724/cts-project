package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class AccountDetails implements java.io.Serializable{
	
	private ProcessorPayload processorPayloadLg;
    
}
