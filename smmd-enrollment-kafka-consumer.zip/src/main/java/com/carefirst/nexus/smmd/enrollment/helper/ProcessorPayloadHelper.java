package com.carefirst.nexus.smmd.enrollment.helper;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;

import com.carefirst.nexus.enrollments.gen.model.BenefitStatus;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.SubmittedEntity;
import com.carefirst.nexus.group.gen.model.Group;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.AccountTrailer;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeSpecificDataLg;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileHeader;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.FileTrailer;
import com.carefirst.nexus.smmd.enrollment.service.groupapi.GroupBaseApiService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
public class ProcessorPayloadHelper {

    private GroupBaseApiService groupService;

    public ProcessorPayloadHelper(GroupBaseApiService groupService) {
        this.groupService = groupService;
    }

    static DateTimeFormatter srcDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
    static DateTimeFormatter localDateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd");
    static DateTimeFormatter regMemberDateFormat = DateTimeFormatter.ofPattern("MMddyyyy");

    public FileHeader populateFileHeader(MemberEnrollmentApplication transactionSubmitterPayload) {
        log.info("ProcessorPayloadHelper || populateFileHeader || Starts");
        FileHeader fileHeader = new FileHeader();
        List<Member> list = transactionSubmitterPayload.getMembers();
        fileHeader.setRecordType("01");
        fileHeader.setCreatedDate(getFormattedDate(LocalDateTime.now()));
        if (list != null) {
            list.forEach(mem -> {
                if (Choice.Yes.equals(mem.getSubscriberInd())) {
                    fileHeader.setSourceId(mem.getSocialSecurityNumber());
                }
            });
        }
         if (SubmittedEntity.EMPLOYER.equals(transactionSubmitterPayload.getApplication().getEntity())) {
        fileHeader.setSubmitterRole("G");
         } else {
        fileHeader.setSubmitterRole("V");
        }
        fileHeader.setHoldField("X");
        log.info("ProcessorPayloadHelper || populateFileHeader || Ends");
        return fileHeader;
    }

    public AccountHeader populateAccountHeader(MemberEnrollmentApplication transactionSubmitterPayload) {
        log.info("ProcessorPayloadHelper || populateAccountHeader || Starts");
        String groupId = transactionSubmitterPayload.getApplication().getGroup().getGroupId();
        AccountHeader header = new AccountHeader();
        header.setRecordType("10");
        header.setFileType("PF");

        if (groupId != null && !groupId.isEmpty()) {
            header.setUniqueCoIdentifierFedTaxId(groupId);
            try {
                Group grp = groupService.getGroupDetailsByGroupId(groupId);
                if (grp != null && grp.getGroupName() != null) {
                    header.setCompanyName(grp.getGroupName());
                }
            } catch (Exception e) {
                log.error("Error occured while making call to getGroupDetailsByGroupId {}", groupId);
            }
        }
        header.setDateFileSubmitted(getFormattedDate(LocalDate.now()));
        header.setPcpIndicator("N");
        header.setResubmittedFileIndicator(null);
        header.setResubmittedFileOriginalDate(null);
        header.setRenewalIndicator("N");
        header.setGroupType(null);
        header.setHoldField("X");
        log.info("ProcessorPayloadHelper || populateAccountHeader || Ends");
        return header;
    }

    public EmployeeTransactionData populteEmpTransactioData(MemberEnrollmentApplication transactionSubmitterPayload) {
        log.info("ProcessorPayloadHelper || populteEmpTransactioData || Starts");
        EmployeeTransactionData employeeTransactionData = new EmployeeTransactionData();
        employeeTransactionData.setRecordType("20");
        List<Member> memberlist = transactionSubmitterPayload.getMembers();
        if (memberlist != null) {
            memberlist.forEach(member -> {
                MemberTransactionType transanctionType = member.getTransactionType();
                if (MemberTransactionType.ADD.equals(transanctionType)
                        || MemberTransactionType.CHANGE.equals(transanctionType)) {
                    employeeTransactionData.setTransactionCode("A");
                } else {
                    employeeTransactionData.setTransactionCode("T");
                }
            });
        }
        employeeTransactionData.setMembers(transactionSubmitterPayload.getMembers());
        employeeTransactionData.setApplication(transactionSubmitterPayload.getApplication());
        employeeTransactionData.setBrokers(transactionSubmitterPayload.getAgents());
        employeeTransactionData.setEmployeeSpecificDatalg(populteEmployeeSpecificDataLg(transactionSubmitterPayload));
        log.info("ProcessorPayloadHelper || populteEmpTransactioData || Ends");
        return employeeTransactionData;
    }

    public AccountTrailer populateAccountTrailer(String detailsRecordsCount) {
        log.info("ProcessorPayloadHelper || populateAccountTrailer || Starts");
        AccountTrailer accountTrailer = new AccountTrailer();
        accountTrailer.setRecordType("30");
        accountTrailer.setFileType("PF");
        accountTrailer.setDetailEmployeeRecordCount(detailsRecordsCount);
        accountTrailer.setHoldField("X");
        log.info("ProcessorPayloadHelper || populateAccountTrailer || Ends");
        return accountTrailer;
    }

    public FileTrailer populteFileTrailer(String detailsRecordsCount) {
        log.info("ProcessorPayloadHelper || populteFileTrailer || Starts");
        FileTrailer trailer = new FileTrailer();
        trailer.setRecordType("02");
        trailer.setTotalAccountorGroupCount("000000");
        trailer.setTotalrecordCount(detailsRecordsCount);
        trailer.setHoldField("X");

        log.info("ProcessorPayloadHelper || populteFileTrailer || Ends");
        return trailer;
    }

    public EmployeeSpecificDataLg populteEmployeeSpecificDataLg(
            MemberEnrollmentApplication transactionSubmitterPayload) {
        EmployeeSpecificDataLg employeeSpecificDataLg = new EmployeeSpecificDataLg();
        Member subscriberMember = transactionSubmitterPayload.getMembers().stream()
                .filter(m -> Choice.Yes.equals(m.getSubscriberInd())).findAny().orElse(null);
        employeeSpecificDataLg.setEmployeeNumber(null);
        employeeSpecificDataLg.setEmployeeLocation(null);
        employeeSpecificDataLg
                .setEmployeeSalaryAmount(null);
        employeeSpecificDataLg.setEmployeeSalaryEffectiveDate(null);
        if (null != subscriberMember) {
            employeeSpecificDataLg.setEmploymentHireDate(subscriberMember.getHireDate().format(regMemberDateFormat));
            employeeSpecificDataLg.setMarriageDate(null);
            employeeSpecificDataLg.setMaritalStatus(subscriberMember.getMaritalStatus().getValue());
            getStatusIndicator(employeeSpecificDataLg, subscriberMember);
        }
        return employeeSpecificDataLg;
    }

    private void getStatusIndicator(EmployeeSpecificDataLg employeeSpecificDataLg, Member subscriberMember) {
        if (subscriberMember != null && subscriberMember.getBenefitStatus() != null
                && ObjectUtils.isNotEmpty(subscriberMember.getBenefitStatus())) {
            if (BenefitStatus.ACTIVE.equals(subscriberMember.getBenefitStatus())) {
                employeeSpecificDataLg.setStatusIndicator("A");
            } else if (BenefitStatus.COBRA.equals(subscriberMember.getBenefitStatus())) {
                employeeSpecificDataLg.setStatusIndicator("C");
            } else {
                employeeSpecificDataLg.setStatusIndicator("R");
            }
        }
    }

    public String getFormattedDate(LocalDateTime dateTime) {
        log.debug("ProcessorPayloadHelper | getFormattedDate | date: {},", dateTime);
        try {
            if (dateTime != null) {
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMddyyyyHHmmss");
                return formatter.format(dateTime);
            }
        } catch (Exception e) {
            log.error("DateParse exception ", e);
        }
        return null;
    }

    public String getFormattedDate(LocalDate date) {
        log.debug("ProcessorPayloadHelper | getFormattedDate | date: {}", date);
        try {
            if (date != null) {
                DateTimeFormatter formatter = null;
                formatter = DateTimeFormatter.ofPattern("MMddyyyy");
                return formatter.format(date);
            }
        } catch (Exception e) {
            log.error("LocalDate parseException ", e);
        }
        return null;
    }

}
