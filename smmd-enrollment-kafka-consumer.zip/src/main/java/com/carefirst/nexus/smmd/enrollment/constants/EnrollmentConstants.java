package com.carefirst.nexus.smmd.enrollment.constants;

import java.util.Arrays;
import java.util.List;

public class EnrollmentConstants {
	private EnrollmentConstants() {
	}

	public static final String SPACE_CHAR = " ";
	public static final String RECORD_TYPE = "20";
	public static final String TRANSACTION_CODE = "A";
	public static final String SPOUSE_CODE = "spouse";
	public static final String CHILD_CODE = "child";
	public static final String PARTNER_CODE = "life_partner";
	public static final String SELF_CODE = "self";
	protected static final List<String> ISPARALLEL_NO_ARRAY = Arrays.asList("NON-PARALLEL", "NON-PARALELL", "BUY-UP",
			"NO");
	
	public static final String ISMEDICAL_PRODUCT = "YES";
	public static final String ISDRUG_PRODUCT = "YES";
	public static final String ISVISION_PRODUCT = "YES";
	public static final String SOURCE_SYS_NASCO = "NASCO";
	public static final String SOURCE_SYS_FACETS = "FACETS";
	public static final String SECTION_CODE_ASSIGNMENT_YES = "YES";
	public static final String SECTION_CODE_ASSIGNMENT_NO = "NO";
	public static final String TRANSACTION_TYPE_ADD_EMPLOYEE = "add_employee";
	public static final String STATUS_PROCESSED = "processed";
	public static final String TRANSACTION_TYPE_ADD_DEPENDENT = "add_dependent";
	public static final String TRANSACTION_TYPE_EDIT_MEMBER = "edit_member";
	public static final String TRANSACTION_TYPE_REINSTATE_MEMBER = "reinstate_member";
	public static final String TRANSACTION_TYPE_REINSTATE_PRODUCT = "reinstate_product";
	public static final String UNDER_SCORE = "_";
	public static final String TERMINATE_TRANSACTION_CODE = "T";
	public static final String TRANSACTION_TYPE_TERMINATE_MEMBER = "terminate_member";
	public static final String TRANSACTION_TYPE_TERMINATE_PRODUCT = "terminate_product";
	public static final String TRANSACTION_TYPE_CHANGE_PROVIDER = "change_provider";
	public static final String ERROR_INVALID_SUBSCRIBER_ID = "Invalid Subscriber ID";
	public static final String EDIFECS_RELATIONSHIP_SELF = "1";
	public static final String EDIFECS_RELATIONSHIP_SPOUSE = "2";
	public static final String EDIFECS_RELATIONSHIP_CHILD = "3";
	public static final String EDIFECS_RELATIONSHIP_PARTNER = "4";
	public static final String EDIFECS_RELATIONSHIP_OTHERS = "5";
	
	public static final String ADD_TRANSACTION_CODE = "A";
	public static final String CHANGE_TRANSACTION_CODE = "C";
	public static final String EMPI_RESPONSE_SUCCESS_CODE = "0000";

	public static final String COB_TYPE_MEDICARE_CODE = "04";
	public static final String PRODUCT_CATEGORY_MED = "MED";
	public static final String PRODUCT_CATEGORY_DEN = "DEN";
	public static final String PRODUCT_CATEGORY_VIS = "VIS";
	public static final String PRODUCT_CATEGORY_DRG = "DRG";
	public static final String ELIGIBILITY_SELF_CODE = "18";
	public static final String ELIGIBILITY_SPOUSE_CODE = "01";
	public static final String ELIGIBILITY_CHILD_CODE = "19";
	public static final String ELIGIBILITY_PARTNER_CODE = "53";

	public static final String AUD_UPDT_ID = "CONSUMER";
	
	public static final String TRANSACTION_REASON_DEATH = "Death";

	public static final String SUBSCRIBER_DEATH_TERM_CODE = "30";
	public static final String DEPENDENT_DEATH_TERM_CODE = "31";
	public static final String SUBSCRIBER_OTHER_REASON_TERM_CODE = "01";
	public static final String DEPENDENT_OTHER_REASON_TERM_CODE = "04";


	public static final String COVERAGETYPE_FAM= "FAM";
	public static final String COVERAGETYPE_ESP= "ESP";
	public static final String COVERAGETYPE_EDP= "EDP";
	public static final String COVERAGETYPE_EMP= "EMP";
	public static final String COVERAGETYPE_E1D= "E1D";

	public static final String COVERAGETYPE_FAM_CODE= "04";
	public static final String COVERAGETYPE_ESP_CODE= "02";
	public static final String COVERAGETYPE_EDP_CODE= "05";
	public static final String COVERAGETYPE_EMP_CODE= "01";
	public static final String COVERAGETYPE_E1D_CODE= "03";

	public static final String PRODUCTID= "08";

	public static final String SUB_RELATIONSHOP_CODE= "1";
	public static final String SPOUSE_RELATIONSHOP_CODE= "2";
	public static final String CHILD_RELATIONSHOP_CODE= "3";
	public static final String DEMESTICPARTENER_RELATIONSHOP_CODE= "4";
	public static final String CLASS_RELATIONSHOP_CODE= "5";
	public static final String OTHER_RELATIONSHOP_CODE= "9";

	public static final String EMPI_ENROLL_SYSTEM = "237";
	public static final String MEM_RELATIONSHIP_CODE = "01";
	public static final String EMPLOYER_IDENTIFICATION_CODE = "CMSMBI";
	public static final String MEM_SEQUENCE_NUMBER = "001";
	public static final String COUNTRY = "USA";


	public static final String MEDICARE_PARTA_ATTRIBUTE= "PartA";
	public static final String MEDICARE_PARTB_ATTRIBUTE= "PartB";

	public static final String ACTIVE_COVERAGE = "Active Coverage";

	public static List<String> getIsparallelNoArray() {
		return ISPARALLEL_NO_ARRAY;
	}

}
