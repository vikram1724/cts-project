package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class AdditionalMemberInformationLg implements java.io.Serializable{
	private String zip;
    private String city;
    private String state;
	private String homePhone;
	private String workPhone;
	private String addressLine1;
    private String addressLine2;
    private String homePhoneAreaCode;
    private String workPhoneAreaCode;
    private String memberSocialSecurityNumber;
}
