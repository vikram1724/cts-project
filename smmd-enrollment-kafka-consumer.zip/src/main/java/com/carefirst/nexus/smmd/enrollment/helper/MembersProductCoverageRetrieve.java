package com.carefirst.nexus.smmd.enrollment.helper;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.CoverageLevel;
import com.carefirst.nexus.enrollments.gen.model.CoverageTransactionType;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.ProductCategory;
import com.carefirst.nexus.enrollments.gen.model.ProductCoverage;
import com.carefirst.nexus.membercoverage.gen.model.MemberCoverage;
import com.carefirst.nexus.membercoverage.gen.model.MemberCoveragesResponse;
import com.carefirst.nexus.membercoverage.gen.model.Product;
import com.carefirst.nexus.smmd.enrollment.constants.EnrollmentConstants;
import com.carefirst.nexus.smmd.enrollment.service.MemberCoverageApiService;

@Component
public class MembersProductCoverageRetrieve {

    private MemberCoverageApiService memberCoverageApiService;

    public MembersProductCoverageRetrieve(MemberCoverageApiService memberCoverageApiService) {
        this.memberCoverageApiService = memberCoverageApiService;
    }

    public void addExistingProducts(MemberEnrollmentApplication transactionSubmitterPayload)
            throws UnrecoverableMessageException {
        if (null != transactionSubmitterPayload
                && StringUtils.hasText(transactionSubmitterPayload.getApplication().getSubscriberId())
                && CollectionUtils.isNotEmpty(transactionSubmitterPayload.getMembers())) {
            MemberCoveragesResponse coverageResponse = memberCoverageApiService
                    .getMemberCoverages(transactionSubmitterPayload.getApplication().getSubscriberId());
            if (null != coverageResponse && CollectionUtils.isNotEmpty(coverageResponse.getMemberCoverages())) {
                List<Member> membersFromIncomingRequest = transactionSubmitterPayload.getMembers();

                Map<String, List<MemberCoverage>> mapOfMemberIdAndActiveProducts = coverageResponse.getMemberCoverages()
                        .stream()
                        .filter(cov -> EnrollmentConstants.ACTIVE_COVERAGE
                                .equals(cov.getMemberEnrollmentDetails().getCoverageStatus().getStatusDescription()))
                        .collect(Collectors.groupingBy(cov -> cov.getMemberDescriptor().getMemberLifeId()));

                for (Member member : membersFromIncomingRequest) {
                    if (null != member && ObjectUtils.isNotEmpty(member.getTransactionType())
                            && MemberTransactionType.CHANGE.equals(member.getTransactionType())) {
                        List<String> productCategoryListFromRrquest = member.getProductCoverages().stream()
                                .map(p -> member.getMemberId() + "-" + p.getProductCategory().getValue() + "-"
                                        + p.getProductId())
                                .toList();

                        List<MemberCoverage> existingMemberCoverages = mapOfMemberIdAndActiveProducts
                                .get(member.getMemberId());
                        if (CollectionUtils.isNotEmpty(existingMemberCoverages)) {
                            List<MemberCoverage> existingActiveProductCoverages = existingMemberCoverages.stream()
                                    .filter(cov -> cov.getMemberEnrollmentDetails().getProduct().stream().allMatch(
                                            p -> !productCategoryListFromRrquest
                                                    .contains(cov.getMemberDescriptor().getMemberLifeId() + "-"
                                                            + cov.getMemberEnrollmentDetails().getProductCategory()
                                                            + "-"
                                                            + p.getProductCode())))
                                    .toList();
                            addProductsFromCoverages(member, existingActiveProductCoverages);
                        }
                    }
                }
            }

            CoverageLevel medicalProductCoverageLevel = getCoverageLevelProductWise(
                    transactionSubmitterPayload.getMembers(), ProductCategory.MEDICAL);
            CoverageLevel dentalProductCoverageLevel = getCoverageLevelProductWise(
                    transactionSubmitterPayload.getMembers(), ProductCategory.DENTAL);
            CoverageLevel visionProductCoverageLevel = getCoverageLevelProductWise(
                    transactionSubmitterPayload.getMembers(), ProductCategory.VISION);

            for (Member member : transactionSubmitterPayload.getMembers()) {
                if(!MemberTransactionType.TERM.equals(member.getTransactionType())){
                    for (ProductCoverage productCov : member.getProductCoverages()) {
                        if (ProductCategory.MEDICAL.equals(productCov.getProductCategory())) {
                            productCov.setCoverageLevel(medicalProductCoverageLevel);
                        } else if (ProductCategory.DENTAL.equals(productCov.getProductCategory())) {
                            productCov.setCoverageLevel(dentalProductCoverageLevel);
                        } else if (ProductCategory.VISION.equals(productCov.getProductCategory())) {
                            productCov.setCoverageLevel(visionProductCoverageLevel);
                        }
                    }
                }
            }
        }

    }

    public CoverageLevel getCoveragetype(List<Member> members) {
        return determineContactOrCoverageType(members.stream().filter(m -> null != m.getRelationshipCode())
                .map(m -> m.getRelationshipCode().getValue()).toList());
    }

    public CoverageLevel getCoverageLevelProductWise(List<Member> members, ProductCategory productCategory) {
        return determineContactOrCoverageType(members.stream()
                .filter(member -> !MemberTransactionType.TERM.equals(member.getTransactionType()) &&
                        member.getProductCoverages().stream()
                                .anyMatch(p -> productCategory.equals(p.getProductCategory())))
                .map(m -> m.getRelationshipCode().getValue()).toList());
    }

    private CoverageLevel determineContactOrCoverageType(List<String> relationshipCodes) {
        if (relationshipCodes != null && !relationshipCodes.isEmpty()) {
            long childCount = relationshipCodes.stream().filter(code -> code.equals("19")).count();
            if (relationshipCodes.contains("18") && relationshipCodes.contains("01")
                    && relationshipCodes.contains("19")) {
                return CoverageLevel.FAMILY;
            } else if (relationshipCodes.contains("18") && relationshipCodes.contains("01")) {
                return CoverageLevel.EMPLOYEE_SPOUSE;
            } else if (relationshipCodes.contains("18") && childCount == 1) {
                return CoverageLevel.EMPLOYEE_ONE_CHILD;
            } else if (relationshipCodes.contains("18") && childCount > 1) {
                return CoverageLevel.EMPLOYEE_CHILDREN;
            } else if (relationshipCodes.contains("18") && relationshipCodes.contains("53")) {
                return CoverageLevel.EMPLOYEE_DOMESTIC_PARTNER;
            } else if (relationshipCodes.contains("01") && relationshipCodes.contains("19")) {
                return CoverageLevel.SPOUSE_CHILD;
            } else if (relationshipCodes.size() == 1 && relationshipCodes.contains("01")) {
                return CoverageLevel.SPOUSE_ONLY;
            } else if (relationshipCodes.size() == childCount) {
                return CoverageLevel.CHILDREN_ONLY;
            } else if (relationshipCodes.size() == 1 && relationshipCodes.contains("18")) {
                return CoverageLevel.EMPLOYEE;
            }
        }
        return null;
    }

    private void addProductsFromCoverages(Member member, List<MemberCoverage> existingActiveProductCoverages) {
        for (MemberCoverage coverage : existingActiveProductCoverages) {
            Product product = coverage.getMemberEnrollmentDetails().getProduct().get(0);
            ProductCoverage productCoverage = new ProductCoverage();
            productCoverage.setProductCategory(ProductCategory.fromValue(product.getCategory().getValue()));
            productCoverage.setProductId(product.getProductCode());
            productCoverage.setProductCoverageId(null);
            productCoverage.setTransactionType(CoverageTransactionType.EXISTING);
            productCoverage.setClassId(coverage.getMemberEnrollmentDetails().getPackageClassId());
            productCoverage
                    .setEffectiveDate(coverage.getMemberEnrollmentDetails().getCoverageStatus().getEffectiveDate());
            productCoverage
                    .setTerminationDate(coverage.getMemberEnrollmentDetails().getCoverageStatus().getTerminationDate());
            productCoverage.setCoverageLevel(CoverageLevel
                    .fromValue(coverage.getMemberEnrollmentDetails().getCoverageLevel().getCode().getValue()));
            member.addProductCoveragesItem(productCoverage);
        }
    }

}
