package com.carefirst.nexus.smmd.enrollment.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.carefirst.nexus.smmd.enrollment.entity.EnrollApplEntity;
import com.carefirst.nexus.smmd.enrollment.repo.EnrollApplRepo;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class DataBaseService {

    private EnrollApplRepo repo;

    public DataBaseService(EnrollApplRepo repo) {
        this.repo = repo;
    }

    public Optional<EnrollApplEntity> findBysubmitterAppId(String submitterApplicationId) {
        return repo.findBySubmitterApplicationId(submitterApplicationId);
    }

}
