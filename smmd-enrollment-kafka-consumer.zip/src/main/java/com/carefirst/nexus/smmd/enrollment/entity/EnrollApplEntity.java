package com.carefirst.nexus.smmd.enrollment.entity;

import java.sql.Timestamp;
import java.util.Date;

import org.hibernate.annotations.ColumnTransformer;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity
@Table(name = "enroll_appl", schema = "enroll_appl")
@Data
public class EnrollApplEntity {

    @Id
	@Column(name = "enroll_appl_id")
    private Integer enrollApplId;

    @Column(name = "submitter_application_id")
    private String submitterApplicationId;

    @Column(name = "source")
    private String source;

    @Column(name = "processor_application_id")
    private String processorApplicationId;

    @Column(name = "status")
    private String status;

    @Column(name = "application_version")
    private String applicationVersion;

    @Column(name = "brochure_link")
    private String brochureLink;

    @Column(name = "submission_status")
    private String submissionStatus;

    @Column(name = "product_line")
    private String productLine;

    @Column(name = "subscriber_id")
    private String subscriberId;

    @ColumnTransformer(write = "?::jsonb")
    @Column(name = "submitter_payload", columnDefinition = "jsonb")
    private String submitterPayload;

    @ColumnTransformer(write = "?::jsonb")
    @Column(name = "processor_payload", columnDefinition = "jsonb")
    private String processorPayload;

    @Column(name = "broker_id")
    private String brokerId;

    @Column(name = "broker_first_nm")
    private String brokerFirstnm;

    @Column(name = "broker_last_nm")
    private String brokerLastnm;

    @Column(name = "applicant_medicare_id")
    private String applicantMedicareId;

    @Column(name = "applicant_first_nm")
    private String applicantFirstnm;

    @Column(name = "applicant_last_nm")
    private String applicantLastnm;

    @Column(name = "applicant_dob")
    private Date applicantDob;

    @Column(name = "applicant_ssn")
    private String applicantSsn;

    @Column(name = "audt_insrt_id")
    private String audtInsrtId;

    @Column(name = "audt_insrt_tmstp")
    private Timestamp audtInsrtTmstp;

    @Column(name = "audt_updt_id")
    private String audtUpdtId;

    @Column(name = "audt_updt_tmstp")
    private Timestamp audtUpdtTmstp;

    @Column(name = "error_message")
    private String errorMessage;

    @ColumnTransformer(write = "?::jsonb")
    @Column(name = "payment_payload", columnDefinition = "jsonb")
    private String paymentPayload;

    @Column(name = "payment_status")
    private String paymentStatus;

    @ColumnTransformer(write = "?::jsonb")
    @Column(name = "additional_info", columnDefinition = "jsonb")
    private String additionalInfo;

}
 