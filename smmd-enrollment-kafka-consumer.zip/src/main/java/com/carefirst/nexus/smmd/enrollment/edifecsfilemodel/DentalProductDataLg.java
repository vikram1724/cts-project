package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class DentalProductDataLg implements java.io.Serializable{
	private String dentalProductID;
    private String dentalGroupNumber;
	private String dentalProviderName;
	private String dentalCoverageLevel;
	private String dentalProviderNumber;
	private String dentalCoverageEffectiveDate;
    private String dentalCoverageTerminationCode;
    private String dentalCoverageTerminationDate;
    private String dentalSubGroupNumberOrPackageCode;
    private String dentalContractCodeOrDepartNumberOrClassID;
    
}
