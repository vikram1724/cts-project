package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
@Data
public class ProcessorPayload1{
    private FileHeader fileHeader;
    private FileTrailer fileTrailer;
    private AccountHeader accountHeader;
    private AccountTrailer accountTrailer;
    @JsonProperty(value = "employeeTransactionDatas")
    private List<EmployeeTransactionData> employeeTransactionDatas;
   
   
}
