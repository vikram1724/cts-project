package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class StudentDataLg implements java.io.Serializable{
	private String holdField;
	private String emailaddress;
    private String studentDataIndicator;
    private String studentEffectiveDate;
    private String studentTerminationDate;
}
