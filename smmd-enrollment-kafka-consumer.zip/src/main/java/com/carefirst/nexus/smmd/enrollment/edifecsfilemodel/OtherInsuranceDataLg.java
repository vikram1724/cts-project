package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class OtherInsuranceDataLg implements java.io.Serializable{
    @JsonProperty(value = "studentData")
	private StudentDataLg studentDataLg;
    private String cobIndicator;
    @JsonProperty(value = "disabilityData")
	private DisabilityDataLg disabilityDataLg;
    @JsonProperty(value = "tefraInformation")
	private TefraInformationLg tefraInformationLg;
    @JsonProperty(value = "medicareInsuranceInfo")
    private List<MedicareInsuranceInfoLg> medicareInsuranceInfoLg;
    @JsonProperty(value = "otherInsuranceInfomation")
    private OtherInsuranceInfomationLg otherInsuranceInfomationLg;   

}
