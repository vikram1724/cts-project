package com.carefirst.nexus.smmd.enrollment.config;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.xml.namespace.QName;

import org.apache.cxf.binding.soap.saaj.SAAJOutInterceptor;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.carefirst.nexus.generate.ws.EmpiPort;
import com.carefirst.nexus.utils.jaxws.WsClientConfigAttributes;
import com.carefirst.nexus.utils.masking.SoapLoggingInterceptor;

@Configuration
public class MemberEnrollmentConfig implements WsClientConfigAttributes {
	private static final Logger LOG = LogManager.getLogger(MemberEnrollmentConfig.class);

	QName serviceName = new QName(
			"http://www.carefirst.com/EmpiRegisterMemberImpl/BusinessProcesses/BusinessServices/Register/Starters",
			"WSRegister");
	QName endpointName = new QName(
			"http://www.carefirst.com/EmpiRegisterMemberImpl/BusinessProcesses/BusinessServices/Register/Starters",
			"SOAPRegisterMember");

	@Value("${application.wsclient.empi.request-timeout}")
	private Integer requestTimeout;

	@Value("${application.wsclient.empi.axis2-connect-timeout}")
	private String axis2ConnectTimeout;

	@Value("${application.wsclient.empi.axis2-write-timeout}")
	private String axis2WriteTimeout;

	@Value("${application.wsclient.empi.axis2-timeout}")
	private String axis2Timeout;

	@Value("${application.wsclient.empi.endpoint-address}")
	private String endpointAddress;

	@Value("${application.wsclient.empi.username}")
	private String username;

	@Value("${application.wsclient.empi.password}")
	private String password;

	@Bean
	public EmpiPort empiPort() throws IOException {
		LOG.info("creating EmpiService ...");
		JaxWsProxyFactoryBean bean = new JaxWsProxyFactoryBean();
		bean.setServiceClass(EmpiPort.class);
		bean.setWsdlURL(
				MemberEnrollmentConfig.class.getClassLoader().getResource("wsdl/empi-register.wsdl").toString());
		bean.setEndpointName(endpointName);
		bean.setServiceName(serviceName);
		bean.setAddress(endpointAddress);
		bean.setUsername(username);
		bean.setPassword(password);

		Map<String, Object> customProperties = new HashMap<>();
		customProperties.put("com.sun.xml.internal.ws.request.timeout", requestTimeout);
		customProperties.put("com.sun.xml.internal.ws.connect.timeout", requestTimeout);
		customProperties.put("connection_timeout", axis2ConnectTimeout);
		customProperties.put("write_timeout", axis2WriteTimeout);
		customProperties.put("timeout", axis2Timeout);
		bean.setProperties(customProperties);

		bean.getInInterceptors().add(new SoapLoggingInterceptor());
		bean.getOutInterceptors().add(new SAAJOutInterceptor());

		EmpiPort client = (EmpiPort) bean.create();
		Client proxy = ClientProxy.getClient(client);
		HTTPConduit http = (HTTPConduit) proxy.getConduit();
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(requestTimeout);
		httpClientPolicy.setReceiveTimeout(requestTimeout);
		http.setClient(httpClientPolicy);
		http.getClient().setReceiveTimeout(requestTimeout);
		
		LOG.info("Empi Service successfully created ...");
		return client;
	}

}
