package com.carefirst.nexus.smmd.enrollment.listener;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.smmd.enrollment.service.EnrollmentTransactionProcessService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EnrollmentTransactionsListener {

	private EnrollmentTransactionProcessService enrollmentTransactionProcessService;

	public EnrollmentTransactionsListener(EnrollmentTransactionProcessService enrollmentTransactionProcessService) {
		this.enrollmentTransactionProcessService = enrollmentTransactionProcessService;
	}

	@KafkaListener(id = "transactions", topics = {
			"${application.kafka.listeners.transactions.consumer.topic}" }, groupId = "${application.kafka.listeners.transactions.consumer.properties.group.id}", containerFactory = "transactions_ContainerFactory")
	public void enrollmentTransactionListener(@Payload ConsumerRecord<String, TransactionListenerPayload> consumerRecord,
			Acknowledgment ack) throws RecoverableMessageException {
		boolean errorFlag = false;
		log.info("EnrollmentTransactionsListener | enrollmentTransactionListener | Message received:{} ", consumerRecord.value());
		if (consumerRecord.value() != null) {
			enrollmentTransactionProcessService.processPayload(consumerRecord.value());
		}
		if (errorFlag) {
			throw new RecoverableMessageException(
					"Exception caught while consuming data from kafka and generating as a edifecs processor payload",
					new RuntimeException("edifecs processor payload not generating and not updating in DDS"));
		}
		log.info("enrollmentTransactionListener : End ");
		ack.acknowledge();
	}

	@KafkaListener(id = "transactions-retry-1", topics = {
			"${application.kafka.listeners.transactions-retry-1.consumer.topic}" }, groupId = "${application.kafka.listeners.transactions-retry-1.consumer.properties.group.id}", containerFactory = "transactions-retry-1_ContainerFactory", autoStartup = "false")
	public void enrollmentTransactionListenerRetry1(@Payload ConsumerRecord<String, TransactionListenerPayload> consumerRecord,
			Acknowledgment ack) throws RecoverableMessageException {
		log.info("EnrollmentTransactionsListener | enrollmentTransactionListenerRetry1 | Message received:{} ",
				consumerRecord.value());
		boolean errorFlag = false;
		if (consumerRecord.value() != null) {
			enrollmentTransactionProcessService.processPayload(consumerRecord.value());
		}
		if (errorFlag) {
			throw new RecoverableMessageException(
					"Exception caught while consuming data from kafka and generating as a edifecs processor payload",
					new RuntimeException("edifecs processor payload not generating and not updating in DDS"));
		}
		log.info("enrollmentTransactionListenerRetry1 : End ");
		ack.acknowledge();
	}
}
