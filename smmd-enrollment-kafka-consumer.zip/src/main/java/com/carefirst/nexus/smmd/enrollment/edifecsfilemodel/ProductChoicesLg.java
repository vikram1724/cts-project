package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class ProductChoicesLg implements java.io.Serializable{
    @JsonProperty(value = "drugProductData")
    private DrugProductDataLg drugProductDataLg;
    @JsonProperty(value = "pcpSelectionData")
    private PcpSelectionDataLg pcpSelectionDataLg;
    @JsonProperty(value = "dentalProductData")
    private DentalProductDataLg dentalProductDataLg;
    @JsonProperty(value = "visionProductData")
    private VisionProductDataLg visionProductDataLg;
    @JsonProperty(value = "medicalCoverageData")
    private MedicalCoverageDataLg medicalCoverageDataLg;
    
    
    
}
