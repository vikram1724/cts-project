package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class DisabilityDataLg implements java.io.Serializable{
    private String disabilityIndicator;
    private String disabilityEffectiveDate;
}
