package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class DrugProductDataLg implements java.io.Serializable{
    private String drugProductID;
    private String drugGroupNumber;
    private String drugCoverageLevel;
    private String drugCoverageEffectiveDate;
    private String drugCoverageTerminatonDate;
    private String drugCoverageTerminationCode;
    private String drugSubGroupNumberOrPackageCode;
    private String drugContractCodeOrDepartNumberOrClassID;
}
