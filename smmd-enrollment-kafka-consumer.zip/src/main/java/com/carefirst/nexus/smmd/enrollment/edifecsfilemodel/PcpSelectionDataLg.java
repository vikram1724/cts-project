package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class PcpSelectionDataLg implements java.io.Serializable{
    private String pcpNumber;
	private String specialistPCPNumber;
	private String secondChoicePCPNumber;
	private String existingPatientIndicator1;
    private String existingPatientIndicator2;
    private String existingPatientIndicator3;
    private String pcpEffectiveTerminationDate;    
}
