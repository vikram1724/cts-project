package com.carefirst.nexus.smmd.enrollment.service;

import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.membercoverage.gen.api.MemberCoverageBaseApi;
import com.carefirst.nexus.membercoverage.gen.model.MemberCoveragesResponse;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
/**
 * This service is for integration of member-coverage-api. 
 * It will connect with MemberCoverageApi to get the coverage details for the given subscriber id.
 *
 */
public class MemberCoverageApiService {
    private MemberCoverageBaseApi memberCoverageBaseApi;

    public MemberCoverageApiService(MemberCoverageBaseApi memberCoverageBaseApi){
        this.memberCoverageBaseApi = memberCoverageBaseApi;
    }

    public MemberCoveragesResponse getMemberCoverages(String subscriberId) throws UnrecoverableMessageException{
        MemberCoveragesResponse memberCoveragesResponse = null;
        try {
            memberCoveragesResponse = memberCoverageBaseApi.getMemberCoverages(null, subscriberId,
                     null, null, null, null, null, null, null, null, null, null, null, null).block();
            
        } catch (Exception e) {
            log.error("MemberCoverageApiService | exception", e.getMessage());
            throw new UnrecoverableMessageException("error occured while getting membercoverages", e);
        }
        
        return memberCoveragesResponse;
    }
    
}
