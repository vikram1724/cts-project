package com.carefirst.nexus.smmd.enrollment.service;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.cxf.BusFactory;
import org.apache.cxf.common.jaxb.JAXBUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.Status;
import com.carefirst.nexus.smmd.enrollment.helper.MembersProductCoverageRetrieve;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.smmd.enrollment.constants.EdifecsFileConstants;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.ProcessorPayload1;
import com.carefirst.nexus.smmd.enrollment.helper.Custom1350LayoutGenerator;
import com.carefirst.nexus.smmd.enrollment.helper.ProcessorPayloadHelper;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.smmd.enrollment.models.UpdateAE2Transaction;
import com.carefirst.nexus.smmd.enrollment.models.UpdateTransaction;
import com.carefirst.nexus.utils.web.error.AppJSONException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.nimbusds.jose.shaded.gson.Gson;
import com.nimbusds.jose.shaded.gson.GsonBuilder;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import jakarta.xml.bind.PropertyException;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcessorPayloadGeneratorService {

    @Value("${edifecs:true}")
    boolean edifecs;

    private Custom1350LayoutGenerator custom1350LayoutGenerator;

    private ProcessorPayloadHelper processorPayloadHelper;

    private EnrollPortalIntegrationService enrollPortalIntegrationService;

    private MeberEnrollmetApiService meberEnrollmetApiService;
    private EmpiIntegrationService empiIntegrationService;
    private MembersProductCoverageRetrieve membersProductCoverageRetrieve;

    public ProcessorPayloadGeneratorService(Custom1350LayoutGenerator custom1350LayoutGenerator,
            ProcessorPayloadHelper processorPayloadHelper,
            MeberEnrollmetApiService meberEnrollmetApiService,
            EmpiIntegrationService empiIntegrationService,
            MembersProductCoverageRetrieve membersProductCoverageRetrieve,
            EnrollPortalIntegrationService enrollPortalIntegrationService) {
        this.custom1350LayoutGenerator = custom1350LayoutGenerator;
        this.processorPayloadHelper = processorPayloadHelper;
        this.meberEnrollmetApiService = meberEnrollmetApiService;
        this.empiIntegrationService = empiIntegrationService;
        this.membersProductCoverageRetrieve = membersProductCoverageRetrieve;
        this.enrollPortalIntegrationService = enrollPortalIntegrationService;
    }

    public String generateProcessorPaylod(TransactionListenerPayload transactionListenerPayload)
            throws RecoverableMessageException {
        log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | START");
        log.info("ProcessorPayloadGeneratorService | submitterPayLoad : " + transactionListenerPayload);
        String processorPayLoad = null;
        String submitterAppId = transactionListenerPayload.getSubmitterApplicationId();
        String status = transactionListenerPayload.getStatus();
        String submitterPayload = null;
        try {
            submitterPayload = transactionListenerPayload.getSubmitterPayload();
            if (submitterPayload != null && !submitterPayload.isEmpty()) {
                ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                        .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
                MemberEnrollmentApplication transactionSubmitterPayload = mapper.readValue(submitterPayload,
                        MemberEnrollmentApplication.class);
                String givenSubscriberId = transactionSubmitterPayload.getApplication().getSubscriberId();
                log.info("givenSubscriberId from submitter payload is {}", givenSubscriberId);
                Member subscriberMember = transactionSubmitterPayload.getMembers().stream()
                        .filter(m -> Choice.Yes.equals(m.getSubscriberInd())).findAny().orElse(null);
                String generatedSubscriberId = generateSubscriberIdWithEMPI(subscriberMember);
                log.info("generatedSubscriberId from EMPI service is {}", generatedSubscriberId);
                if (!StringUtils.hasText(givenSubscriberId)) {
                    transactionSubmitterPayload.getApplication().setSubscriberId(generatedSubscriberId);
                } else if (!givenSubscriberId.equalsIgnoreCase(generatedSubscriberId)) {
                    meberEnrollmetApiService.updateMemberEnrollment(submitterAppId,
                            processorPayLoad,
                            "Given subscriber id is invalid, Valid id is " + generatedSubscriberId,
                            Status.NOT_SUBMITTED, givenSubscriberId);
                    throw new AppJSONException("Given subscriber id is invalid.");
                }

                membersProductCoverageRetrieve.addExistingProducts(transactionSubmitterPayload);

                log.info("ProcessorPayloadGeneratorService | transactionListenerPayload : ");
                if (edifecs || transactionSubmitterPayload.getApplication().getGroup().getGroupId().length() == 8) {
                    log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | edifecsProcessorPayload : ");
                    processorPayLoad = generateEdifecsProcessorPayload(processorPayLoad, transactionSubmitterPayload);
                } else {
                    processorPayLoad = generateAE2ProcessorPayload(transactionSubmitterPayload);
                }

                log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | processorPayLoad : ");
                if (processorPayLoad != null && !processorPayLoad.isEmpty() && submitterAppId != null
                        && !submitterAppId.isEmpty() && status != null && !status.isEmpty()
                        && status.equalsIgnoreCase(EdifecsFileConstants.STATUS_PENDING)) {
                    meberEnrollmetApiService.updateMemberEnrollment(submitterAppId, processorPayLoad, null,
                            Status.READY_TO_SUBMIT, transactionSubmitterPayload.getApplication().getSubscriberId());

                }
            } else {
                throw new NullPointerException(
                        "ProcessorPayloadGeneratorService | generateProcessorPaylod | submitterPayload : "
                                + submitterPayload + "Should not be Null or Empty. ");
            }
        } catch (Exception e) {
            log.error("ProcessorPayloadGeneratorService | generateProcessorPaylod| exception ", e);
            throw new RecoverableMessageException("Error occured in while generating processing payload ", e);
        }
        log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | Ends");
        return processorPayLoad;
    }

    private String generateEdifecsProcessorPayload(String processorPayLoad,
            MemberEnrollmentApplication transactionSubmitterPayload)
            throws RecoverableMessageException {
        ProcessorPayload1 edifecsProcessorPayload = populateEmployeeTransactionData(
                transactionSubmitterPayload);
        String formated1350SubmitterPayLoad = custom1350LayoutGenerator
                .formatEmplyeeTransactionData(edifecsProcessorPayload);
        log.info("ProcessorPayloadGeneratorService | formatProcessorPayLoadData : ");
        if (formated1350SubmitterPayLoad != null && !formated1350SubmitterPayLoad.isEmpty()) {
            processorPayLoad = getJsonPayLoad(formated1350SubmitterPayLoad);
        }
        return processorPayLoad;
    }

    private String generateAE2ProcessorPayload(MemberEnrollmentApplication transactionSubmitterPayload)
            throws RecoverableMessageException, UnrecoverableMessageException, JAXBException, PropertyException,
            JsonProcessingException {
        String processorPayLoad;
        EnrollmentData ae2Payload = enrollPortalIntegrationService.enrollEmpoyeePortal(transactionSubmitterPayload);
        JAXBContext jaxbContext = JAXBContext.newInstance(EnrollmentData.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
        StringWriter sw = new StringWriter();
        Map<String, String> namespaceMap = new HashMap<>();
        namespaceMap.put(
                "http://www.tibco.com/schemas/cf-ae2-EP-svc/SharedResources/SchemaDefinitions/EmployerPortalSchema/EmployerPortal.xsd",
                "ns0");
        namespaceMap.put("http://www.w3.org/2003/05/soap-envelope", "SOAP-ENV");
        JAXBUtils.setNamespaceMapper(BusFactory.getDefaultBus(), namespaceMap, jaxbMarshaller);
        jaxbMarshaller.marshal(ae2Payload, sw);
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        UpdateAE2Transaction updateAE2Transaction = new UpdateAE2Transaction();
        updateAE2Transaction.setFile834Content(sw.toString());
        processorPayLoad = gson.toJson(updateAE2Transaction);
        return processorPayLoad;
    }

    private String generateSubscriberIdWithEMPI(Member subscriberMember) {
        log.info("ProcessorPayloadGeneratorService | generateSubscriberIdWithEMPI | Ends");
        String subscriberId = null;
        try {
            subscriberId = empiIntegrationService.getSubscriberId(subscriberMember);
            return subscriberId;
        } catch (Exception e) {
            log.info(e.getMessage());
        }
        log.info("ProcessorPayloadGeneratorService | generateSubscriberIdWithEMPI | Ends");
        return subscriberId;
    }

    private String getJsonPayLoad(String formated1350ProcessorPayLoad) throws RecoverableMessageException {
        log.info("ProcessorPayloadGeneratorService | getJsonPayLoad| start ");
        String jsonbData = null;
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        UpdateTransaction updateTransaction = new UpdateTransaction();
        updateTransaction.setFile1350Content(formated1350ProcessorPayLoad);
        jsonbData = gson.toJson(updateTransaction);
        log.info("ProcessorPayloadGeneratorService | getJsonPayLoad| end ");
        return jsonbData;
    }

    private ProcessorPayload1 populateEmployeeTransactionData(
            MemberEnrollmentApplication transactionSubmitterPayload) {
        log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | START");
        int detailsRecordsCount = transactionSubmitterPayload.getMembers().size();
        String detailsRecords = Integer.toString(detailsRecordsCount);
        List<EmployeeTransactionData> empTranDataLst = new ArrayList<>();
        ProcessorPayload1 pcrPayload = new ProcessorPayload1();
        if (transactionSubmitterPayload != null) {
            pcrPayload.setFileHeader(processorPayloadHelper.populateFileHeader(transactionSubmitterPayload));
            pcrPayload.setAccountHeader(processorPayloadHelper.populateAccountHeader(transactionSubmitterPayload));
            empTranDataLst.add(processorPayloadHelper.populteEmpTransactioData(transactionSubmitterPayload));
            pcrPayload.setEmployeeTransactionDatas(empTranDataLst);
            pcrPayload.setAccountTrailer(processorPayloadHelper.populateAccountTrailer(detailsRecords));
            pcrPayload.setFileTrailer(processorPayloadHelper.populteFileTrailer(detailsRecords));
            log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | pcrPayload : " + pcrPayload);
        }
        log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | START");
        return pcrPayload;
    }

}
