package com.carefirst.nexus.smmd.enrollment.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.Status;
import com.carefirst.nexus.smmd.enrollment.constants.EdifecsFileConstants;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.EmployeeTransactionData;
import com.carefirst.nexus.smmd.enrollment.edifecsfilemodel.ProcessorPayload1;
import com.carefirst.nexus.smmd.enrollment.helper.Custom1350LayoutGenerator;
import com.carefirst.nexus.smmd.enrollment.helper.ProcessorPayloadHelper;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;
import com.carefirst.nexus.smmd.enrollment.models.UpdateTransaction;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.module.paramnames.ParameterNamesModule;
import com.nimbusds.jose.shaded.gson.Gson;
import com.nimbusds.jose.shaded.gson.GsonBuilder;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ProcessorPayloadGeneratorService {

    private Custom1350LayoutGenerator custom1350LayoutGenerator;

    private ProcessorPayloadHelper processorPayloadHelper;

    private MeberEnrollmetApiService meberEnrollmetApiService;
    private EmpiIntegrationService empiIntegrationService;

    public ProcessorPayloadGeneratorService(Custom1350LayoutGenerator custom1350LayoutGenerator,
            ProcessorPayloadHelper processorPayloadHelper,
            MeberEnrollmetApiService meberEnrollmetApiService,
            EmpiIntegrationService empiIntegrationService) {
        this.custom1350LayoutGenerator = custom1350LayoutGenerator;
        this.processorPayloadHelper = processorPayloadHelper;
        this.meberEnrollmetApiService = meberEnrollmetApiService;
        this.empiIntegrationService = empiIntegrationService;
    }

    public String generateProcessorPaylod(TransactionListenerPayload transactionListenerPayload)
            throws RecoverableMessageException {
        log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | START");
        log.info("ProcessorPayloadGeneratorService | submitterPayLoad : " + transactionListenerPayload);
        String processorPayLoad = null;
        String submitterAppId = transactionListenerPayload.getSubmitterApplicationId();
        String status = transactionListenerPayload.getStatus();
        String submitterPayload = null;
        try {
            submitterPayload = transactionListenerPayload.getSubmitterPayload();
            if (submitterPayload != null && !submitterPayload.isEmpty()) {
                ObjectMapper mapper = new ObjectMapper().registerModule(new ParameterNamesModule())
                        .registerModule(new Jdk8Module()).registerModule(new JavaTimeModule());
                MemberEnrollmentApplication transactionSubmitterPayload = mapper.readValue(submitterPayload,
                        MemberEnrollmentApplication.class);
                String subscriberId = transactionSubmitterPayload.getApplication().getSubscriberId();
                Member subscriberMember = transactionSubmitterPayload.getMembers().stream()
                        .filter(m -> Choice.Yes.equals(m.getSubscriberInd())).findAny().orElse(null);
                if (null == subscriberId) {
                    generateSubscriberId(transactionSubmitterPayload, subscriberMember);
                }
                log.info("ProcessorPayloadGeneratorService | transactionListenerPayload : ");
                ProcessorPayload1 edifecsProcessorPayload = populateEmployeeTransactionData(
                        transactionSubmitterPayload);
                log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | edifecsProcessorPayload : ");
                String formated1350SubmitterPayLoad = custom1350LayoutGenerator
                        .formatEmplyeeTransactionData(edifecsProcessorPayload);
                log.info("ProcessorPayloadGeneratorService | formatProcessorPayLoadData : ");
                if (formated1350SubmitterPayLoad != null && !formated1350SubmitterPayLoad.isEmpty()) {
                    processorPayLoad = getJsonPayLoad(formated1350SubmitterPayLoad);
                }
                log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | processorPayLoad : ");
                if (processorPayLoad != null && !processorPayLoad.isEmpty() && submitterAppId != null
                        && !submitterAppId.isEmpty() && status != null && !status.isEmpty()
                        && status.equalsIgnoreCase(EdifecsFileConstants.STATUS_PENDING)) {
                    meberEnrollmetApiService.updateMemberEnrollment(submitterAppId, processorPayLoad, null,
                            Status.READY_TO_SUBMIT, transactionSubmitterPayload.getApplication().getSubscriberId());

                }
            } else {
                throw new NullPointerException(
                        "ProcessorPayloadGeneratorService | generateProcessorPaylod | submitterPayload : "
                                + submitterPayload + "Should not be Null or Empty. ");
            }
        } catch (Exception e) {
            log.error("ProcessorPayloadGeneratorService | generateProcessorPaylod| exception ", e);
            throw new RecoverableMessageException("Error occured in while generating processing payload ", e);
        }
        log.info("ProcessorPayloadGeneratorService | generateProcessorPaylod | Ends");
        return processorPayLoad;
    }

    private void generateSubscriberId(MemberEnrollmentApplication transactionSubmitterPayload,
            Member subscriberMember) {
        String subscriberId;
        try {
            subscriberId = empiIntegrationService.getSubscriberId(subscriberMember);
            transactionSubmitterPayload.getApplication().setSubscriberId(subscriberId);
        } catch (Exception e) {
            log.info(e.getMessage());
        }
    }

    private String getJsonPayLoad(String formated1350ProcessorPayLoad) throws RecoverableMessageException {
        log.info("ProcessorPayloadGeneratorService | getJsonPayLoad| start ");
        String jsonbData = null;
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        UpdateTransaction updateTransaction = new UpdateTransaction();
        updateTransaction.setFile1350Content(formated1350ProcessorPayLoad);
        jsonbData = gson.toJson(updateTransaction);
        log.info("ProcessorPayloadGeneratorService | getJsonPayLoad| end ");
        return jsonbData;
    }

    private ProcessorPayload1 populateEmployeeTransactionData(
            MemberEnrollmentApplication transactionSubmitterPayload) {
        log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | START");
        int detailsRecordsCount = transactionSubmitterPayload.getMembers().size();
        String detailsRecords = Integer.toString(detailsRecordsCount);
        List<EmployeeTransactionData> empTranDataLst = new ArrayList<>();
        ProcessorPayload1 pcrPayload = new ProcessorPayload1();
        if (transactionSubmitterPayload != null) {
            pcrPayload.setFileHeader(processorPayloadHelper.populateFileHeader(transactionSubmitterPayload));
            pcrPayload.setAccountHeader(processorPayloadHelper.populateAccountHeader(transactionSubmitterPayload));
            empTranDataLst.add(processorPayloadHelper.populteEmpTransactioData(transactionSubmitterPayload));
            pcrPayload.setEmployeeTransactionDatas(empTranDataLst);
            pcrPayload.setAccountTrailer(processorPayloadHelper.populateAccountTrailer(detailsRecords));
            pcrPayload.setFileTrailer(processorPayloadHelper.populteFileTrailer(detailsRecords));
            log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | pcrPayload : " + pcrPayload);
        }
        log.info("ProcessorPayloadGeneratorService | populateEmployeeTransactionData | START");
        return pcrPayload;
    }

}
