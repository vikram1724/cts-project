package com.carefirst.nexus.smmd.enrollment.constants;

public class EdifecsFileConstants {

    private EdifecsFileConstants() {
    }

public static final String BLOB_SUCCESS ="File uploaded to Blob ";
public static final String BLOB_FAILURE ="File failed in Blob upload";
public static final String LG = "Lg";
public static final String EMPRL = "Employer";
public static final String THIRTEENFIFTY = "1350"; 
public static final String UNDERSCORE = "_";
public static final String TXT = ".txt";
public static final String UPLOAD_CARFIRST_SUCCESS = "BlobFileUtils | fileUploadtoBlobStorage | upload to Carefirst  was successful & File Name : ";
public static final String FILEHEADER="FILEHEADER";
public static final String ACCOUNTHEADER="FILEHEADER";
public static final String FILETRAILER="FILEHEADER";
public static final String ACCONTTRAILER="ACCONTTRAILER";

public static final String HOLDF_FIELD = "X";
public static final String RENEWAL_INDICATOR="N";
public static final String EMPTY_VALUE = "";
public static final String RECORD_TYPE = "recordType";
public static final String NEWLINE = "\n";
public static final String GROUPTYPE_WITH_EMPTY_VALUE= "";
public static final String FILLER_WITH_EMPTY_VALUE= "";
public static final String DEPARTMENTID= "";
public static final String CLIENT_SPECFIC_REPORTING_VALUE= "";

//common fileds sizes
public static final Integer RECORDTYPE_SIZE=2;
public static final Integer HOLDFIELD_SIZE=1;

//file header fields sizes
public static final Integer RELEASE_VERSION_SIZE=3;
public static final Integer CREATEDATE_SIZE=14;
public static final Integer SOURCEID_SIZE=9;
public static final Integer BATCHNUMBER_SIZE=10;
public static final Integer SUBMITTERROLE_SIZE=1;
public static final Integer FILEHEADER_FILLER_SIZE=1310;

//Account header fields sizes
public static final Integer FILETYPE_SIZE=2;
public static final Integer COMPANYNAME_SIZE=25;
public static final Integer UNIQUE_CO_IDENTIFIER_FEB_TAXID_SIZE=15;
public static final Integer CONTACTNAME_SIZE=25;
public static final Integer CONTACT_TELEPHONE_NUMBER_SIZE=10;
public static final Integer DATEFILESUBMITTED_SIZE=8;
public static final Integer MEMBER_TERM_DATE_DEFAULT_SIZE=8;
public static final Integer SALESPERSONNUMBER_SIZE=5;
public static final Integer PCP_INDICATOR_SIZE=1;
public static final Integer RESUBMITTED_FILE_INDICATOR_SIZE=1;
public static final Integer RESUBMITTED_FILE_ORIGINALDATE_SIZE=8;
public static final Integer RENEWAL_INDICATOR_SIZE=1;
public static final Integer GROUP_TYPE_SIZE=1;
public static final Integer ACCOUNTHEADER_FILLER_SIZE=1237;

//Detail record filed sizes
public static final Integer TRANSACTIONCODE_SIZE=2;
public static final Integer DETAILRECORDFILLER1_SIZE=2;
//Key Demographic Data 
public static final Integer EMPLOYEESSN_SIZE=9;
public static final Integer LASTNAME_SIZE=25;
public static final Integer FIRSTNAME_SIZE=20;
public static final Integer MIDDLEINTIAL_SIZE=1;
public static final Integer SUFFIX_SIZE=6;
public static final Integer DATEOFBIRTH_SIZE=8;
public static final Integer SEX_SIZE=1;
public static final Integer RELATIONSHIPCODE_SIZE=1;
public static final Integer DEMOGRAPHIC_DATA_FILLER_SIZE=30;
//Employee Specific Data
public static final Integer EMPLOYEENUMBER_SIZE=20;
public static final Integer EMPLOYEELOCATION_SIZE=10;
public static final Integer EMPLOYEE_SAL_AMOUNT_SIZE=9;
public static final Integer EMPLOYEE_SAL_EFFECTIVE_DATE=8;
public static final Integer EMPLOYEE_HIRE_DATE_SIZE=8;
public static final Integer MARITAL_STARUS_SIZE=1;
public static final Integer MARRIAGE_DATE_SIZE=8;
public static final Integer STATUS_INDICATOR_SIZE=1;
public static final Integer EMPLOYEE_SPECIFIC_DATA_FILLER_SIZE=30;
//Additional Member Information
public static final Integer ADDRESSLINE1_SIZE=30;
public static final Integer ADDRESSLINE2_SIZE=30;
public static final Integer CITY_SIZE=30;
public static final Integer STATE_SIZE=2;
public static final Integer ZIP_SIZE=9;
public static final Integer HOMEPHONE_AREACODE_SIZE=3;
public static final Integer HOMEPHONE_SIZE=7;
public static final Integer WORKPHONE_AREACODE_SIZE=3;
public static final Integer WORKPHONE_SIZE=7;
public static final Integer ADDITIONALMEMBERINFO_FILER_SIZE=30;
public static final Integer MEMBER_SOCIAL_SECURITY_NUMBER_SIZE=9;
//Product Choices
//Medical Coverage Data
public static final Integer MEDICAL_GROUP_NUMBER_SIZE=20;
public static final Integer SUB_GROUP_NUMBER_SIZE=5;
public static final Integer CLASS_CODE_SIZE=9;
public static final Integer MEDICAL_COVERAGE_LEVEL_SIZE=2;
public static final Integer MEDICAL_COVERAGE_EFFECTIVE_DATE_SIZE=8;
public static final Integer MEDICAL_COVERAGE_TERMINATION_CODE_SIZE=5;
public static final Integer MEDICAL_COVERAGE_TERMINATION_DATE_SIZE=8;
public static final Integer HOME_PLAN_CODE_SIZE=3;
public static final Integer CONTROL_PLAN_CODE_SIZE=3;
public static final Integer MEDICAL_PRODUCTID_SIZE=2;
public static final Integer MEDICAL_COVERAGE_DATA_FILLER_SIZE=31;
//pcp selection data
public static final Integer PCP_NUMBER_SIZE=20;
public static final Integer PCP_EEFECTIVE_OR_TERMINATION_DATE_SIZE=8;
public static final Integer PCP_FILLER1_SIZE=8;
public static final Integer EXISTING_PATIENT_INDICATOR1_SIZE=1;
public static final Integer SECOND_CHOICE_PCP_NUMBER_SIZE=20;
public static final Integer EXISTING_PATIENT_INDICATOR2_SIZE=1;
public static final Integer PCP_FILLER2_SIZE=8;
public static final Integer SPECIALIST_PCP_NUMBER_SIZE=20;
public static final Integer EXISTING_PATIENT_INDICATOR3_SIZE=1;
public static final Integer PCP_FILLER3_SIZE=22;
//Dental product data
public static final Integer DENTAL_GROUP_NUMBER_SIZE=20;
public static final Integer DENTAL_SUBGROUP_NUMBER_SIZE=5;
public static final Integer DENTAL_CONTRACT_CODE_OR_CLASSID_SIZE=9;
public static final Integer DENTAL_COVERAGE_LEVEL_SIZE=2;
public static final Integer DENTAL_COVERAGE_EFFECTIVEDATE_SIZE=8;
public static final Integer DENTAL_COVERAGE_TERMINATION_CODE_SIZE=5;
public static final Integer DENTAL_COVERAGE_TERMINATIONDATE_SIZE=8;
public static final Integer DENTAL_PROVIDER_NAME_SIZE=35;
public static final Integer DENTAL_PROVIDER_NUMBER_SIZE=20;
public static final Integer DENTAL_PRODUCTID_SIZE=2;
public static final Integer DENTAL_FILLER_SIZE=37;
//Vision Product Data
public static final Integer VISION_GROUP_NUMBER_SIZE=20;
public static final Integer VISION_SUBGROUP_NUMBER_ORPACKAGE_CODE_SIZE=5;
public static final Integer VISION_CONTRACT_CODE_OR_DEPARTMENTNUMBER_OR_CLASSID_SIZE=9;
public static final Integer VISION_COVERAGE_LEVEL_SIZE=2;
public static final Integer VISION_COVERAGE_EFFECTIVEDATE_SIZE=8;
public static final Integer VISION_COVERAGE_TERMINATION_CODE_SIZE=5;
public static final Integer VISION_COVERAGE_TERMINATIONDATE_SIZE=8;
public static final Integer VISION_PRODUCTID_SIZE=2;
public static final Integer VISION_FILLER_SIZE=37;
//Drug Product Data
public static final Integer DRUG_GROUP_NUMBER_SIZE=20;
public static final Integer DRUG_SUBGROUP_NUMBER_ORPACKAGE_CODE_SIZE=5;
public static final Integer DRUG_CONTRACT_CODE_OR_DEPARTMENTNUMBER_OR_CLASSID_SIZE=9;
public static final Integer DRUG_COVERAGE_LEVEL_SIZE=2;
public static final Integer DRUG_COVERAGE_EFFECTIVEDATE_SIZE=8;
public static final Integer DRUG_COVERAGE_TERMINATION_CODE_SIZE=5;
public static final Integer DRUG_COVERAGE_TERMINATIONDATE_SIZE=8;
public static final Integer DRUG_PRODUCTID_SIZE=2;
public static final Integer DRUG_FILLER_SIZE=37;
//Other Insurance Data
public static final Integer COBINDICATOR_SIZE=1;
//Other Insurance Infomation
public static final Integer COB_INSURANCE_COMPANY_NAME_SIZE=35;
public static final Integer MEMBERS_COB_MEMBERID_SIZE=15;
public static final Integer COB_EFFECTIVEDATE_SIZE=8;
public static final Integer COB_TERMINATIONDATE_SIZE=8;
public static final Integer COB_EMPLOYERNAME_SIZE=25;
public static final Integer COB_POLICYNUMBER_SIZE=15;
public static final Integer COB_POLICYHOLDERNAME_SIZE=35;
public static final Integer COB_POLICYHOLDERDOB_SIZE=8;
public static final Integer COB_POLICYHOLDERID_SIZE=15;
public static final Integer COB_POLICYHOLDERSSN_SIZE=9;
public static final Integer OTHERINSURANCEDATA_FILLER_SIZE=30;
//TEFRA Information
public static final Integer TEFRA_EFFECTIVEDATE_SIZE=8;
public static final Integer TEFRA_TERMINATIONDATE_SIZE=8;
//Medicare Insurance Info
public static final Integer MEDICAR_ELIGIBILITY_INDICATOR_SIZE=1;
public static final Integer HIC_NUMBER_SIZE=12;
public static final Integer MEDICARA_EFFECTIVEDATE_SIZE=8;
public static final Integer MEDICARA_TERMINATIONDATE_SIZE=8;
public static final Integer MEDICARB_EFFECTIVEDATE_SIZE=8;
public static final Integer MEDICARB_TERMINATIONDATE_SIZE=8;
public static final Integer MEDICAREINSURANCEINFO_FILLER1_SIZE=2;
public static final Integer CRASS_REFERENCE_SSN_SIZE=9;
public static final Integer RATE_MODIFIER_SIZE=4;
public static final Integer MEDICAREINSURANCEINFO_FILLER2_SIZE=10;
//Disability Data
public static final Integer DISABILITY_INDICATOR_SIZE=1;
public static final Integer DISABILITY_EFFECTIVEDATE_SIZE=8;
//Student Data
public static final Integer STUDENT_DATA_SIZE=1;
public static final Integer STUDENT_EFFECTIVEDATE_SIZE=8;
public static final Integer STUDENT_TERMINATIONDATE_SIZE=8;
public static final Integer EMAIL_SIZE=43;
public static final Integer DEPARTMENTID_SIZE=10;
public static final Integer CLIENT_SPECIFIC_REPORTING_VALUE_SIZE=25;
public static final Integer STUDENT_FILLER_SIZE=45;
//Account Trailer Field sizes
public static final Integer ACCOUNT_TRAILER_FILE_TYPE_SIZE=2;
public static final Integer TOTAL_NUMBER_OF_RECORDS=10;
public static final Integer ACCOUNT_TRAILER_FILLER=1335;
//File Trailer Field sizes
public static final Integer TOTAL_ACCOUNT_OR_GROUP_COUNT=6;
public static final Integer TOTAL_COUNT=8;
public static final Integer FILE_TRAILER_FILLER=1333;

public static final String STATUS_COMPLETE="COMPLETE";
public static final String STATUS_PENDING="PENDING";

public static final String AUDTUPDTID ="EMPPRTL_BTH_UPDT";

public static final String SPACE_CHAR = " ";


}   