package com.carefirst.nexus.smmd.enrollment.service;

import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.nexus.smmd.enrollment.models.TransactionListenerPayload;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EnrollmentTransactionProcessService {

	private ProcessorPayloadGeneratorService processorPayloadGeneratorService;

	public EnrollmentTransactionProcessService(
			ProcessorPayloadGeneratorService processorPayloadGeneratorService) {
		this.processorPayloadGeneratorService = processorPayloadGeneratorService;

	}

	public void processPayload(TransactionListenerPayload transactionListenerPayload)
			throws RecoverableMessageException {
		log.info("EnrollmentTransactionProcessService | processPayload | START");
		try {
			String submitterappId = transactionListenerPayload.getSubmitterApplicationId();
			if (transactionListenerPayload != null && submitterappId != null && !submitterappId.isEmpty()) {
				processorPayloadGeneratorService.generateProcessorPaylod(transactionListenerPayload);
			} else {
				throw new NullPointerException(
						"The submitterApplicationId : " + submitterappId + " and submitterpayload : "
								+ transactionListenerPayload + " should not be Null.");
			}
		} catch (Exception e) {
			log.error("EnrollmentTransactionProcessService | processPayload| exception ", e);
			throw new RecoverableMessageException("Error occured in while processing submitter payload ", e);
		}
		log.info("EnrollmentTransactionProcessService | processPayload | END");
	}

}
