package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class LgEdfects implements java.io.Serializable{
    private String submitterApplicationId;

    private String source;

    private String status;

    private ProcessorPayload processorPayload;

    private Timestamp audtInsrtTmstp;

    private Timestamp audtUpdtTmstp;
}
