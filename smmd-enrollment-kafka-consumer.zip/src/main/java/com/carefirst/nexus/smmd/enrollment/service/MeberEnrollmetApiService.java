package com.carefirst.nexus.smmd.enrollment.service;

import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.carefirst.nexus.enrollments.gen.api.MemberEnrollmentsApiApi;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentDetailsResponse;
import com.carefirst.nexus.enrollments.gen.model.Status;
import com.carefirst.nexus.enrollments.gen.model.UpdateMemberEnrollmentRequest;
import com.carefirst.nexus.enrollments.gen.model.UpdateMemberEnrollmentResponse;

import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Mono;

@Service
@Slf4j
public class MeberEnrollmetApiService {

	private static final Logger LOG = LogManager.getLogger(MeberEnrollmetApiService.class);

	private MemberEnrollmentsApiApi memberEnrollmentsApi;

	public MeberEnrollmetApiService(MemberEnrollmentsApiApi memberEnrollmentsApi) {
		this.memberEnrollmentsApi = memberEnrollmentsApi;
	}

	public UpdateMemberEnrollmentResponse updateMemberEnrollment(String submitterApplicationId,
			String processorPaylaod,
			String errorMessage, Status status, String subscriberId) {
		LOG.info("MeberEnrollmetApiService | updateMemberEnrollment | start");
		UpdateMemberEnrollmentRequest updateEnrollmetRequest = new UpdateMemberEnrollmentRequest();
		updateEnrollmetRequest.setApplicationId(submitterApplicationId);
		updateEnrollmetRequest.setProcessorApplicationId(submitterApplicationId);
		updateEnrollmetRequest.setProcessorPayload(processorPaylaod);
		updateEnrollmetRequest.setErrorMessage(errorMessage);
		updateEnrollmetRequest.setSubscriberId(subscriberId);
		updateEnrollmetRequest.setStatus(status);
		UpdateMemberEnrollmentResponse updateMemberEnrollmentResponse = null;
		try {
			Mono<UpdateMemberEnrollmentResponse> monoReponse = memberEnrollmentsApi
					.updateMemberEnrollment(updateEnrollmetRequest);
			if (null != monoReponse) {
				updateMemberEnrollmentResponse = monoReponse.block();
			}
			LOG.info("updateMemberEnrollment Retrieval Complete");
		} catch (Exception e) {
			LOG.info("MeberEnrollmetApiService | updateMemberEnrollment | Exception : " + e);
			throw e;
		}
		LOG.info(
				"MeberEnrollmetApiService | updateMemberEnrollment | GroupResp : {} " + updateMemberEnrollmentResponse);
		LOG.info("MeberEnrollmetApiService | updateMemberEnrollment | End ");
		return updateMemberEnrollmentResponse;
	}

	public List<String> getEnrollmentStatus(MemberEnrollmentApplication application) {
		MemberEnrollmentDetailsResponse res = null;
		try {
			Mono<MemberEnrollmentDetailsResponse> monoReponse = memberEnrollmentsApi
					.getMemberEnrollmentDetails(null, application.getApplication().getSubscriberId(), null, null, null);
			if (null != monoReponse) {
				res = monoReponse.block();
				return res.getApplication().stream().map(r -> r.getStatus()).toList();
			}
			LOG.info("getEnrollmentStatus Retrieval Complete");
		} catch (Exception e) {
			LOG.info("MeberEnrollmetApiService | getEnrollmentStatus | Exception : " + e);
			throw e;
		}
		LOG.info(
				"MeberEnrollmetApiService | getEnrollmentStatus | getMemberEnrollmentStatus : {} " + res);
		LOG.info("MeberEnrollmetApiService | getEnrollmentStatus | End ");
		return null;
	}

}