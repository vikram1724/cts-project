package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
public class EmployeeTransactionDataLg implements java.io.Serializable{
    private String recordType="20";
    private String transactionId;
    @JsonProperty(value = "productChoices")
    private ProductChoicesLg  productChoiceslg;
    private String transactionCode;
    @JsonProperty(value = "keyDemographicData")
    private List<KeyDemographicDataLg> keyDemographicDatalg;
    @JsonProperty(value = "otherInsuranceData")
    private OtherInsuranceDataLg otherInsuranceDatalg;
    @JsonProperty(value = "employeeSpecificData")
    private EmployeeSpecificDataLg employeeSpecificDatalg;
    @JsonProperty(value = "additionalMemberInformation")
    private AdditionalMemberInformationLg additionalMemberInformationlg;
    

   
	
    
}
