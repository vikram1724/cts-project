package com.carefirst.nexus.smmd.enrollment.service;

import java.net.ConnectException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Address;
import com.carefirst.nexus.enrollments.gen.model.BenefitStatus;
import com.carefirst.nexus.enrollments.gen.model.Broker;
import com.carefirst.nexus.enrollments.gen.model.COB;
import com.carefirst.nexus.enrollments.gen.model.Choice;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.enrollments.gen.model.MemberEnrollmentApplication;
import com.carefirst.nexus.enrollments.gen.model.MemberTransactionType;
import com.carefirst.nexus.enrollments.gen.model.OtherInfo;
import com.carefirst.nexus.enrollments.gen.model.ProductCoverage;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.CoverageInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.CoverageInformation.BrokerOrTPADetails;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.AddressInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.CobraInformation;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails.CobDetails;
import com.carefirst.nexus.generate.employerportalenrollment.ws.EnrollmentData.PersonalInformation.ProductDetails.PcpDetails;

@Service
public class EnrollPortalIntegrationService {
	static final Log LOG = LogFactory.getLog(EnrollPortalIntegrationService.class);

	static DateTimeFormatter srcDateFormat = DateTimeFormatter.ofPattern("MM/dd/yyyy");
	static DateTimeFormatter localDateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd");
	static DateTimeFormatter reqDateFormat = DateTimeFormatter.ofPattern("yyyyMMdd");

	public EnrollmentData enrollEmpoyeePortal(MemberEnrollmentApplication memberEnrollmentApplication)
			throws RecoverableMessageException, UnrecoverableMessageException {
		LOG.debug("> enrollEmpoyeePortal");
		Member subscriberMember = memberEnrollmentApplication.getMembers().stream()
				.filter(m -> Choice.Yes.equals(m.getSubscriberInd())).findAny().orElse(null);
		try {
			LOG.info("Calling Enroll");
			EnrollmentData enrollmentData = new EnrollmentData();
			CoverageInformation coverageInformation = getCoverageInformation(subscriberMember,
					memberEnrollmentApplication);
			getPersonalInformation(enrollmentData, memberEnrollmentApplication);
			enrollmentData.setCoverageInformation(coverageInformation);
			return enrollmentData;

		} catch (Exception e) {
			handleException(e);
		} finally {
			LOG.debug("< enrollEmpoyeePortal");
		}
		return null;
	}

	private void getPersonalInformation(EnrollmentData enrollmentData,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		for (Member member : memberEnrollmentApplication.getMembers()) {
			PersonalInformation personalInformation = new PersonalInformation();
			if (MemberTransactionType.ADD.equals(member.getTransactionType())) {
				personalInformation.setAddTermReinstateVoidDate(formatDateValue(member.getEffectiveDate()));
			} else if (MemberTransactionType.TERM.equals(member.getTransactionType())) {
				personalInformation.setAddTermReinstateVoidDate(formatDateValue(member.getTerminationDate()));
			} else if (MemberTransactionType.REINSTATE.equals(member.getTransactionType())) {
				personalInformation
						.setAddTermReinstateVoidDate(formatDateString(member.getAddReinstateEffectiveDate()));
			} else {
				personalInformation.setAddTermReinstateVoidDate(formatDateString(member.getAddVoidEffectiveDate()));
			}
			getAddress(member, personalInformation);
			getCobra(personalInformation, member, memberEnrollmentApplication);
			personalInformation.setDateOfBirth(member.getDateOfBirth());
			if (MemberTransactionType.TERM.equals(member.getTransactionType())) {
				personalInformation.setDateOfDeath(formatDateValue(member.getTerminationDate()));
			}
			personalInformation.setDisabilities(member.getDisabilityInd().getValue());
			personalInformation.setEmploymentSalaryDetails(null);
			personalInformation.setFirstName(member.getName().getFirstName());
			personalInformation.setGender(member.getGender().getValue());
			personalInformation.setHandicapIndicator(null);
			personalInformation.setJobTitle(null);
			personalInformation.setLastName(member.getName().getLastName());
			if (MemberTransactionType.TERM.equals(member.getTransactionType())) {
				personalInformation.setMaintenanceReason(null);
			}
			personalInformation.setMaritalStatus(member.getMaritalStatus().getValue());
			personalInformation.setMiddleInitial(member.getName().getMiddleName());
			personalInformation.setNamePrefix(member.getName().getPrefix());
			personalInformation.setNameSuffix(member.getName().getSuffix());
			getProductDetails(personalInformation, member);
			personalInformation.setRaceOrEthnicityCode(member.getRelic().getRace().getCode());
			personalInformation.setRelation(member.getRelationshipCode().getValue());
			personalInformation.setSchoolName(null);
			personalInformation.setSocialSecurityNumber(member.getSocialSecurityNumber());
			personalInformation.setStudentEffectiveDate(null);
			personalInformation.setStudentIndicator(null);
			personalInformation.setStudentTermDate(null);
			personalInformation.setStudentTermReason(null);
			personalInformation.setSubscriberID(memberEnrollmentApplication.getApplication().getSubscriberId());
			personalInformation.setTrxType(member.getTransactionType().getValue());
			personalInformation.setUnionIndicator(null);
			personalInformation.setUnionName(null);
			enrollmentData.getPersonalInformation().add(personalInformation);
		}
	}

	private void getProductDetails(PersonalInformation personalInformation, Member member) {
		for (ProductCoverage productCoverage : member.getProductCoverages()) {
			ProductDetails productDetail = new ProductDetails();
			getCobDetail(productDetail, member, productCoverage);
			getPcpDetail(productDetail, member, productCoverage);
			productDetail.setElectedUnits(null);
			productDetail.setInsuranceLineCode(productCoverage.getProductCategory().getValue());
			productDetail.setProductClassId(productCoverage.getClassId());
			productDetail.setProductStartDate(formatDateValue(productCoverage.getEffectiveDate()));
			productDetail.setProductTermDate(formatDateValue(productCoverage.getTerminationDate()));
			productDetail.setProductTrxType(productCoverage.getTransactionType().getValue());
			personalInformation.getProductDetails().add(productDetail);
		}
	}

	private String formatDateString(String dateValue) {
		try {
			return LocalDate.parse(dateValue, localDateFormat)
					.format(reqDateFormat);
		} catch (Exception e) {
			return dateValue;
		}
	}

	private String formatDateValue(LocalDate date) {
		try {
			return date
					.format(reqDateFormat);
		} catch (Exception e) {
			return null;
		}

	}

	private void getPcpDetail(ProductDetails productDetail, Member member, ProductCoverage productCoverage) {
		if (CollectionUtils.isNotEmpty(productCoverage.getPcp())) {
			PcpDetails pcpDetail = new PcpDetails();
			pcpDetail.setEntityCode(null);
			pcpDetail.setPcpChangeEffDate(null);
			pcpDetail.setPcpChangeReasonCode(null);
			pcpDetail.setPcpID(productCoverage.getPcp().get(0).getProviderId());
			productDetail.setPcpDetails(pcpDetail);
		}
	}

	private void getCobDetail(ProductDetails productDetail, Member member, ProductCoverage productCoverage) {
		for (COB cob : member.getCobs()) {
			if (Choice.Yes.equals(cob.getOtherInsuranceIndicator())) {
				for (OtherInfo otherInfo : cob.getOtherInfo()) {
					CobDetails cobDetail = new CobDetails();
					cobDetail.setBenefitEligDate(null);
					cobDetail.setCobCode(null);
					cobDetail.setFirstName(member.getName().getFirstName());
					cobDetail.setLastName(member.getName().getLastName());
					cobDetail.setPayerSeqNumber(null);
					cobDetail.setPolicyNumber(otherInfo.getPolicyholderNumber());
					cobDetail.setServiceType(null);
					cobDetail.setSsn(member.getSocialSecurityNumber());
					cobDetail.setTrxType(MemberTransactionType.ADD.getValue());
					productDetail.setCobDetails(cobDetail);
				}
			}
		}
	}

	private void getCobra(PersonalInformation personalInformation, Member member,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		if (BenefitStatus.COBRA.equals(member.getBenefitStatus())) {
			CobraInformation cobraInfo = new CobraInformation();
			cobraInfo.setCoverageEffDate(formatDateValue(member.getEffectiveDate()));
			cobraInfo.setCoverageTermDate(formatDateValue(member.getTerminationDate()));
			cobraInfo.setOrignalGroupId(memberEnrollmentApplication.getApplication().getGroup().getGroupId());
			cobraInfo.setOrignalSubGroupId(member.getSubGroupId());
			cobraInfo.setOrignalSubsId(memberEnrollmentApplication.getApplication().getSubscriberId());
			cobraInfo.setSubsCoveredPeriod(null);
			cobraInfo.setSubsDisbltyEffDate(null);
			cobraInfo.setSubsDisbltyIND(null);
			cobraInfo.setSubsTermRsn(null);
			personalInformation.getCobraInformation().add(cobraInfo);
		}
	}

	private void getAddress(Member member, PersonalInformation personalInformation) {
		for (Address addr : member.getAddress()) {
			AddressInformation address = new AddressInformation();
			address.setAddressLine1(addr.getLine1());
			address.setAddressLine2(addr.getLine2());
			address.setCity(addr.getCity());
			address.setConsentFlag(null);
			address.setState(addr.getState());
			address.setWorkStateCode(addr.getStateCode());
			address.setZipCode(addr.getZipCode());
			personalInformation.getAddressInformation().add(address);
		}
	}

	private CoverageInformation getCoverageInformation(Member subscriberMember,
			MemberEnrollmentApplication memberEnrollmentApplication) {
		CoverageInformation coverageInformation = new CoverageInformation();
		coverageInformation.setBenefitStatus(subscriberMember.getBenefitStatus().getValue());
		coverageInformation.setClassID(subscriberMember.getProductCoverages().get(0).getClassId());
		coverageInformation
				.setContractType(subscriberMember.getProductCoverages().get(0).getCoverageLevel().getValue());
		coverageInformation.setEmploymentStatus(subscriberMember.getEmploymentStatus().getValue());
		coverageInformation.setGroupName(memberEnrollmentApplication.getApplication().getGroup().getGroupName());
		coverageInformation
				.setGroupSubGroupNumber(memberEnrollmentApplication.getApplication().getGroup().getGroupId()
						+ subscriberMember.getSubGroupId());
		coverageInformation.setHireDate(formatDateValue(subscriberMember.getHireDate()));
		coverageInformation.setOriginalEffDate(formatDateValue(LocalDate.parse(subscriberMember.getOriginalEffdate())));
		coverageInformation.setTransID(null);
		getBroker(coverageInformation, memberEnrollmentApplication.getAgents());
		return coverageInformation;
	}

	private void getBroker(CoverageInformation coverageInformation, List<Broker> brokers) {
		for (Broker broker : brokers) {
			BrokerOrTPADetails brokerOrTPADetails = new BrokerOrTPADetails();
			brokerOrTPADetails.setBrokerOrTPACode(broker.getTradingPartnerId());
			brokerOrTPADetails.setBrokerOrTPAName(broker.getTradingPartnerName());
			coverageInformation.getBrokerOrTPADetails().add(brokerOrTPADetails);
		}
	}

	private void handleException(Exception e) throws RecoverableMessageException, UnrecoverableMessageException {
		LOG.debug("> handleException");
		if (e instanceof ConnectException) {
			LOG.error("Error in connecting EMPI (Axway) Service: " + e);
			throw new RecoverableMessageException(e.getMessage(), e);
		} else {
			LOG.error("Error occured while getting subscriberId from EMPI: " + e);
			throw new UnrecoverableMessageException(e.getMessage(), e);
		}
	}
	
}
