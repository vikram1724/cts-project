package com.carefirst.nexus.smmd.enrollment.config;

import java.text.DateFormat;
import java.util.TimeZone;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.OAuth2AuthorizedClientManager;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServletOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeStrategies;
import org.springframework.web.reactive.function.client.WebClient;

import com.carefirst.nexus.enrollments.gen.api.MemberEnrollmentsApiApi;
import com.carefirst.nexus.membercoverage.gen.api.MemberCoverageBaseApi;
import com.carefirst.nexus.enrollments.gen.invoker.ApiClient;
import com.carefirst.nexus.enrollments.gen.invoker.RFC3339DateFormat;
import com.carefirst.nexus.group.gen.api.GroupDetailsApi;
import com.carefirst.nexus.utils.web.config.rest.WebUtilsFilter;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class WebClientConfig {
	private static final Logger LOG = LogManager.getLogger(WebClientConfig.class);

	@Value("${oauth2.client.registrationId}")
	String registrationId;

	@Value("${nexus.group.apiclient.basepath}")
	private String groupApiBasepath;

	@Value("${nexus.memberenrollment.apiclient.basepath}")
	private String memberenrollmentApiBasepath;

	@Value("${nexus.membercoverage.apiclient.basepath}")
	private String membercoverageApiBasepath;

	
	OAuth2AuthorizedClientManager authorizedClientServiceManager;

	public WebClientConfig(OAuth2AuthorizedClientManager authorizedClientServiceManager) {
		this.authorizedClientServiceManager = authorizedClientServiceManager;
	}

	WebUtilsFilter webUtil = new WebUtilsFilter(authorizedClientServiceManager, registrationId);

	@Bean
	WebClient webClient1(OAuth2AuthorizedClientManager authorizedClientManager) {
		ServletOAuth2AuthorizedClientExchangeFilterFunction oauth2Client = new ServletOAuth2AuthorizedClientExchangeFilterFunction(
				authorizedClientManager);
		oauth2Client.setDefaultClientRegistrationId(registrationId);
		return WebClient.builder().filter(webUtil.guidFilter())
				.exchangeStrategies(ExchangeStrategies.builder()
						.codecs(configurer -> configurer.defaultCodecs().maxInMemorySize(16 * 1024 * 1024)).build())
				.apply(oauth2Client.oauth2Configuration())
				.build();
	}

	public DateFormat createDefaultDateFormat() {
		DateFormat dateFormat = new RFC3339DateFormat();
		dateFormat.setTimeZone(TimeZone.getTimeZone("EST"));
		return dateFormat;
	}

	@Bean
	public GroupDetailsApi groupOperationsApi(WebClient webClient1) {
		LOG.debug("groupApiBasepath: {}", groupApiBasepath);
		com.carefirst.nexus.group.gen.invoker.ApiClient apiClient = new com.carefirst.nexus.group.gen.invoker.ApiClient(
				webClient1, new ObjectMapper(), createDefaultDateFormat());
		apiClient.setBasePath(groupApiBasepath);
		return new GroupDetailsApi(apiClient);
	}

	@Bean
	public MemberEnrollmentsApiApi memberEnrollment(WebClient webClient1) {
		LOG.debug("groupApiBasepath: {}", groupApiBasepath);
		ApiClient apiClient = new ApiClient(
				webClient1, new ObjectMapper(), createDefaultDateFormat());
		apiClient.setBasePath(memberenrollmentApiBasepath);
		return new MemberEnrollmentsApiApi(apiClient);
	}

	@Bean
	public MemberCoverageBaseApi memberCoverage(WebClient webClient1) {
		LOG.debug("membercoverageApiBasepath: {}", membercoverageApiBasepath);
		com.carefirst.nexus.membercoverage.gen.invoker.ApiClient apiClient = new com.carefirst.nexus.membercoverage.gen.invoker.ApiClient(
				webClient1, new ObjectMapper(), createDefaultDateFormat());
		apiClient.setBasePath(membercoverageApiBasepath);
		return new MemberCoverageBaseApi(apiClient);
	}

}