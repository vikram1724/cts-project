package com.carefirst.nexus.smmd.enrollment.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationProvider;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;
import org.springframework.security.web.SecurityFilterChain;

import com.carefirst.nexus.utils.web.config.token.AuthNMultiKeyHelper;

@Configuration
@EnableWebSecurity
public class ResourceServerConfig {
	private static final String[] AUTH_WHITELIST = { "/swagger-resources", "/swagger-resources/**", "/configuration/ui",
			"/configuration/security", "/swagger-ui.html", "/webjars/**",
			// -- Swagger UI v3 (OpenAPI)
			"/v3/api-docs/**", "/swagger-ui/**",
			// other public endpoints of your API may be appended to this array
			"/pub/**", "**/v1/**", "/actuator/**"
	};

	@Bean
	public SecurityFilterChain filterChain(HttpSecurity http, AuthNMultiKeyHelper oauthhelper) throws Exception {
		JwtAuthenticationConverter jwtAuthenticationConverter = new JwtAuthenticationConverter();
		jwtAuthenticationConverter.setJwtGrantedAuthoritiesConverter(new JwtGrantedAuthoritiesConverter());
		http.authorizeHttpRequests(
				requests -> requests.requestMatchers(AUTH_WHITELIST).permitAll().anyRequest().authenticated())
				.oauth2ResourceServer(server -> server.authenticationManagerResolver(
						request -> {
							JwtAuthenticationProvider authenticationProvider = new JwtAuthenticationProvider(
									oauthhelper.jwtDecoder(request.getHeader("Authorization")));
							authenticationProvider.setJwtAuthenticationConverter(jwtAuthenticationConverter);
							return authenticationProvider::authenticate;
						}));
		return http.build();
	}
}
