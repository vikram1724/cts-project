package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;

import lombok.Data;

@Data
public class TefraInformationLg implements java.io.Serializable{
    private String tefraEffectiveDate;
    private String tefraTerminationDate;
}
