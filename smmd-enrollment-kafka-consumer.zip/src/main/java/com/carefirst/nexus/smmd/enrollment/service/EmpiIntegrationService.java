package com.carefirst.nexus.smmd.enrollment.service;

import java.net.ConnectException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.enrollments.gen.model.Member;
import com.carefirst.nexus.generate.ws.EmpiPort;
import com.carefirst.nexus.generate.ws.EmpiResponse;
import com.carefirst.nexus.generate.ws.RegisterMemberRequest;
import com.carefirst.nexus.generate.ws.ResponseMember;
import com.carefirst.nexus.smmd.enrollment.helper.EmpiRequestMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class EmpiIntegrationService {
	@Value("${application.wsclient.empi.username}")
	private String username;
	EmpiPort empiPort;

	public EmpiIntegrationService(EmpiPort empiPort) {
		this.empiPort = empiPort;
	}

	public String getSubscriberId(Member member)
			throws RecoverableMessageException, UnrecoverableMessageException {
		log.debug("> getSubscriberId");
		String subscriberId = null;
		EmpiRequestMapper empiRequestMapper = new EmpiRequestMapper();
		try {
			RegisterMemberRequest registerMemberRequest = empiRequestMapper.createEmpiRequest(member);
			if (registerMemberRequest != null) {
				registerMemberRequest.setUserId(username);
				log.info("Calling Empi to get subscriber id with request {}",
						new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(registerMemberRequest));
				EmpiResponse responseMember = empiPort.empiRegisterMember(registerMemberRequest);
				log.info("EMPI service response {}",
						new ObjectMapper().writerWithDefaultPrettyPrinter().writeValueAsString(responseMember));
				subscriberId = empiResponseMapper(responseMember);
				if (subscriberId == null) {
					throw new UnrecoverableMessageException(
							"SubscriberId is not generated for the Member, please check data", new RuntimeException());
				}
			}

		} catch (Exception e) {
			log.error("Error in EMPI Service for " + member.getName().getFirstName() + ": " + e);
			handleException(e);
		} finally {
			log.debug("< getSubscriberId");
		}
		return subscriberId;
	}

	private String empiResponseMapper(EmpiResponse empiResponse) throws UnrecoverableMessageException {
		log.debug("> empiResponseMapper");
		if (!CollectionUtils.isEmpty(empiResponse.getResponseMember())) {
			ResponseMember responseMember = empiResponse.getResponseMember().get(0);
			if (responseMember.getStatus() != null && responseMember.getStatus().getCode().equals("0000")) {
				return responseMember.getMember().getSubscriberId();
			} else {
				log.error("Response from EMPI Service is "
						+ empiResponse.getResponseMember().get(0).getStatus().getDescription());
				throw new UnrecoverableMessageException(responseMember.getStatus().getDescription(),
						new RuntimeException());
			}
		}
		return null;
	}

	private void handleException(Exception e) throws RecoverableMessageException, UnrecoverableMessageException {
		log.debug("> handleException");
		if (e instanceof ConnectException) {
			log.error("Error in connecting EMPI (Axway) Service: " + e);
			throw new RecoverableMessageException(e.getMessage(), e);
		} else {
			log.error("Error occured while getting subscriberId from EMPI: " + e);
			throw new UnrecoverableMessageException(e.getMessage(), e);
		}
	}
}
