package com.carefirst.nexus.smmd.enrollment.service;

import java.net.ConnectException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.generate.ws.EmpiPort;
import com.carefirst.nexus.generate.ws.EmpiResponse;
import com.carefirst.nexus.generate.ws.RegisterMemberRequest;
import com.carefirst.nexus.generate.ws.ResponseMember;
import com.carefirst.nexus.smmd.enrollment.helper.EmpiRequestMapper;
import com.carefirst.nexus.enrollments.gen.model.Member;

@Service
public class EmpiIntegrationService {
    @Value("${application.wsclient.empi.username}")
	private String username;
    static final Log LOG = LogFactory.getLog(EmpiIntegrationService.class);
    EmpiPort empiPort;

    public EmpiIntegrationService(EmpiPort empiPort) {
        this.empiPort = empiPort;
    }

    public String getSubscriberId(Member member)
			throws RecoverableMessageException, UnrecoverableMessageException {
		LOG.debug("> getSubscriberId");
		String subscriberId = null;
		EmpiRequestMapper empiRequestMapper = new EmpiRequestMapper();
		try {
			RegisterMemberRequest registerMemberRequest = empiRequestMapper.createEmpiRequest(member);
			if (registerMemberRequest != null) {
				registerMemberRequest.setUserId(username);
				LOG.info("Calling Empi to get subscriber id");
				EmpiResponse responseMember = empiPort.empiRegisterMember(registerMemberRequest);
				subscriberId = empiResponseMapper(responseMember);
				if (subscriberId == null) {
					throw new UnrecoverableMessageException(
							"SubscriberId is not generated for the Member, please check data", new RuntimeException());
				}
			}

		} catch (Exception e) {
			LOG.error("Error in EMPI Service for " + member.getName().getFirstName() + ": " + e);
			handleException(e);
		} finally {
			LOG.debug("< getSubscriberId");
		}
		return subscriberId;
	}

	private String empiResponseMapper(EmpiResponse empiResponse) throws UnrecoverableMessageException {
		LOG.debug("> empiResponseMapper");
		if (!CollectionUtils.isEmpty(empiResponse.getResponseMember())) {
			ResponseMember responseMember = empiResponse.getResponseMember().get(0);
			if (responseMember.getStatus() != null && responseMember.getStatus().getCode().equals("0000")) {
				return responseMember.getMember().getSubscriberId();
			} else {
				LOG.error("Response from EMPI Service is "
						+ empiResponse.getResponseMember().get(0).getStatus().getDescription());
				throw new UnrecoverableMessageException(responseMember.getStatus().getDescription(),
						new RuntimeException());
			}
		}
		return null;
	}

	private void handleException(Exception e) throws RecoverableMessageException, UnrecoverableMessageException {
		LOG.debug("> handleException");
		if (e instanceof ConnectException) {
			LOG.error("Error in connecting EMPI (Axway) Service: " + e);
			throw new RecoverableMessageException(e.getMessage(), e);
		} else {
			LOG.error("Error occured while getting subscriberId from EMPI: " + e);
			throw new UnrecoverableMessageException(e.getMessage(), e);
		}
	}
}
