package com.carefirst.nexus.smmd.enrollment.helper;

import org.springframework.stereotype.Component;

import com.carefirst.nexus.enrollments.gen.model.CoverageLevel;
import com.carefirst.nexus.smmd.enrollment.constants.EnrollmentConstants;

@Component
public class EnrollmentUtil {
    public String getCoverageLevelByCoverageType(CoverageLevel coverageLevel) {
        if (coverageLevel != null) {
            if (CoverageLevel.EMPLOYEE.equals(coverageLevel)) {
                return EnrollmentConstants.COVERAGETYPE_EMP_CODE;
            } else if (CoverageLevel.EMPLOYEE_SPOUSE.equals(coverageLevel)) {
                return EnrollmentConstants.COVERAGETYPE_ESP_CODE;
            } else if (CoverageLevel.FAMILY.equals(coverageLevel)) {
                return EnrollmentConstants.COVERAGETYPE_FAM_CODE;
            } else if (CoverageLevel.EMPLOYEE_DOMESTIC_PARTNER.equals(coverageLevel)) {
                return EnrollmentConstants.COVERAGETYPE_EDP_CODE;
            } else if (CoverageLevel.EMPLOYEE_ONE_CHILD.equals(coverageLevel) || CoverageLevel.EMPLOYEE_CHILDREN.equals(coverageLevel)) {
                return EnrollmentConstants.COVERAGETYPE_E1D_CODE;
            } else {
                return null;
            }
        }
        return null;
    }
}
