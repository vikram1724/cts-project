package com.carefirst.nexus.smmd.enrollment;

/**
 * @author carefirst
 *
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@ComponentScan({ "com.carefirst.kafka.consumer", "com.carefirst.nexus.smmd.enrollment",
		"com.carefirst.nexus.utils.web.config.token", "com.carefirst.nexus.utils.web.error",
		"com.carefirst.nexus.utils.web.config.rest" })
@EnableKafka
@SpringBootApplication
@RestController
public class SmmdEnrollmentKafkaConsumerApplication {

	@GetMapping("/pub/healthcheck")
	public String healthCheck() {
		return "OK";
	}

	public static void main(String[] args) {
		SpringApplication.run(SmmdEnrollmentKafkaConsumerApplication.class, args);
	}
}
