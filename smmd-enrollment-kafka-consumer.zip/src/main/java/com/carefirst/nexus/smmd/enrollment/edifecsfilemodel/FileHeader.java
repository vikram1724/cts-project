package com.carefirst.nexus.smmd.enrollment.edifecsfilemodel;


import lombok.Data;

@Data
public class FileHeader implements java.io.Serializable{
    private String sourceId;
	private String holdField;
	private String recordType;
	private String createdDate;
    private String submitterRole;
}
