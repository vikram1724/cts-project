/* package com.carefirst.nexus.smmd.enrollment.service;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.carefirst.kafka.consumer.error.exception.RecoverableMessageException;
import com.carefirst.kafka.consumer.error.exception.UnrecoverableMessageException;
import com.carefirst.nexus.smmd.enrollment.model.TransactionListenerPayload;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class ConsumerService {

	private EnrollmentTransactionProcessService enrollmentTransactionProcessService;

	public ConsumerService(EnrollmentTransactionProcessService enrollmentTransactionProcessService) {
		this.enrollmentTransactionProcessService = enrollmentTransactionProcessService;
	}

	@KafkaListener(id = "transactions", topics = {
			"${application.kafka.listeners.transactions.consumer.topic}" }, groupId = "${application.kafka.listeners.transactions.consumer.properties.group.id}", containerFactory = "transactions_ContainerFactory")
	public void lgTransactionListener(@Payload ConsumerRecord<String, TransactionListenerPayload> consumerRecord,
			Acknowledgment ack) throws RecoverableMessageException {
		boolean errorFlag = false;
		log.info("LgTransactionsListener | lgTransactionListener | Message received:{} ", consumerRecord.value());
		if (consumerRecord.value() != null) {
			enrollmentTransactionProcessService.processPayload(consumerRecord.value());
		}
		if (errorFlag) {
			throw new RecoverableMessageException(
					"Exception caught while consuming data from kafka and generating as a edifecs processor payload",
					new RuntimeException("edifecs processor payload not generating and not updating in DDS"));
		}
		log.info("lgTransactionListener : End ");
		ack.acknowledge();
	}

	@KafkaListener(id = "transactions-retry-1", topics = {
			"${application.kafka.listeners.transactions-retry-1.consumer.topic}" }, groupId = "${application.kafka.listeners.transactions-retry-1.consumer.properties.group.id}", containerFactory = "transactions-retry-1_ContainerFactory", autoStartup = "false")
	public void lgTransactionListenerRetry1(@Payload ConsumerRecord<String, TransactionListenerPayload> consumerRecord,
			Acknowledgment ack) throws UnrecoverableMessageException {
		log.info("LgTransactionsListener | lgTransactionListenerRetry1 | Message received:{} ",
				consumerRecord.value());
		try {
			if (consumerRecord.value() != null) {
				enrollmentTransactionProcessService.processPayload(consumerRecord.value());
			}
		} catch (Exception e) {
			throw new UnrecoverableMessageException(
					"Exception caught while consuming data from kafka and generating as a edifecs processor payload",
					new RuntimeException("edifecs processor payload not generating and not updating in DDS"));
		}
		log.info("lgTransactionListenerRetry1 : End ");
		ack.acknowledge();
	}

} */