# smmd-enrollment-kafka-consumer  

1.	<B>Title:</B> smmd-enrollment-kafka-consumer

2.	<B>Description:</B> This is carefirst smmd-enrollment-kafka-consumer consumer used to update the processor paylaod. smmd-enrollment-kafka-consumer will consume the submitter payload from Kafka topic based on KSQL QUERY Condition.
        KSQL QUERY : SELECT * FROM ENROLL_DOMAIN_APPL_LANDING_STREAM where UCASE(SOURCE)='EMPPORTAL' AND UCASE(STATUS)='PENDING' AND ((PROCESSOR_APPLICATION_ID = '') OR (PROCESSOR_APPLICATION_ID is null)). <br>
		After consuming the submitter payload Kafka app will perform below operations.<br>
			a. Json to java Object conversion<br>
			b. mapping the fields to 1350 objects <br>
			c. Format the submitter payload as per 1350 file standard <br>
			d. Formatted 1350 file payload object to Json(processor payload) conversion <br>
			e. status checking if status = "PENDING” Then update teh status to "READY TO SUBMIT" and processor payload in DB. <br>

3.	<B>Documentation:</B> <br>
    a.	Kafka Definitions: <br>
			Topic:
			DEVA : member.enrollment.domaincdc.deva.application <br>
			SITA : member.enrollment.domaincdc.sita.application <br>
			PIT : member.enrollment.domaincdc.pit.application <br>
			UAT : member.enrollment.domaincdc.uat.application <br>       
    b.	Share point: <a href="#"> Reference </a><br>
	c.	Jira <a href="https://carefirst.atlassian.net/browse/NCT-3740">Reference : NCT-3740</a>  <br>
	d.	[Documents](S:\Shared Processing\MyAccountApplicationDetails\NEXUS) <br>
	e.	Backing systems:
		
		1. Internal Services:
			<a href="https://dev.azure.com/CareFirstCloud/nexus-enrollment/_git/member-enrollments-api">Nexus Api: member-enrollments-api</a> <br>
			<a href="https://dev.azure.com/CareFirstCloud/nexus-member-coverage/_git/member-group-api">Nexus Api: member-group-api</a> <br>


4.	<B>Setup and Configuration:</B> 
                SpringBoot Maven Project with all dependencies added in Nexus parent Project.
        
5. <B>Solution Manager: </B> Agarwal, Archana <Archana.Agarwal@carefirst.com>

6. <B>System Architect: </B> Mahadevappa, Chethan <Chethan.Mahadevappa@carefirst.com>  

7. <B>Domain SME: </B> Andhavarapu, Srinivasa <Srinivasa.Andhavarapu@carefirst.com>

8. <B>Developer Lead: </B> Prema, Alamelu <Alamelu.Prema@carefirst.com>

9. <B> Supporting DL:  </B> Nexus Catalyst Team <Nexus.Catalyst.Team@carefirst.com>